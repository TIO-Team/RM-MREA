function [POP, objVal, CV, bestInd_feasible, bestObj,Gen] =OptimizerDE(Lower,Upper,obj,consG,consH,NP,MaxGen,FPool, CRPool,StopWhenNoImprovement,RepairType,MuteType,EnvSelType,toleranceG,toleranceH,CVType,maxStagCount)
% obj, consg, consh are function handles of objective, inequality
% constraints, equality constraints, respectively
%% Check
if nargin<4 || isempty(consG)
    consG={};
end
if nargin<5 || isempty(consH)
    consH={};
end
if nargin<6 || isempty(NP)
    NP=100;
end
if nargin<7 || isempty(MaxGen)
    MaxGen=100;
end
if nargin<8 || isempty(FPool)
    FPool=1;
end
if nargin<9 || isempty(CRPool)
    CRPool=0.9;
end
if nargin<10 || isempty(StopWhenNoImprovement)
    StopWhenNoImprovement=true;
end
if nargin<11 || isempty(RepairType)
    RepairType=1;
end
if nargin<12 || isempty(MuteType)
    MuteType=5;
end
if nargin<13 || isempty(EnvSelType)
    EnvSelType=1; % 1v1 or compaire all
end
if nargin<14 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<15 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<16 || isempty(CVType)
    CVType=1;
end
if nargin<17 || isempty(maxStagCount)
    maxStagCount=50;
end
warning off;
%% Initialize
Dim=length(Lower);
Lower0=ones(NP,1)*Lower;
Upper0=ones(NP,1)*Upper;
POP=Lower0+(Upper0-Lower0).*lhsdesign(NP,Dim,'criterion','maximin','iterations',5000);
[objVal,consGVal,consHVal]=evaluateIndividual(POP,obj,consG,consH);
[bestInd, bestObjCV,bestIndRow,feasibility,CV,minCV]=findBest(POP,objVal,consGVal,consHVal,toleranceG,toleranceH,CVType);
if feasibility
    bestInd_feasible=bestInd;% Best feasible individual
    bestObj=bestObjCV;% Objective value of the best feasible individual
else
    bestInd_feasible=[];
    bestObj=inf;
end
%% Optimize
Gen=1;
stagCount=0;
num_localSearch=2;
maxFunEva_localSearch=300;
maxFunEva_localSearch_final=300;
algorithmLocalSeach='sqp';

LocalSearchStag=floor(linspace(1,maxStagCount,num_localSearch));
LocalSearchStag=unique(LocalSearchStag,'stable');
while Gen < MaxGen
    Gen=Gen+1;
    Offspring=ReproduceDE(POP,Lower,Upper, MuteType,FPool,CRPool, RepairType, bestInd); 
    [objVal_Offspring,consGVal_Offspring,consHVal_Offspring]=evaluateIndividual(Offspring,obj,consG,consH);
    CV_Offspring=CVCal0(consGVal_Offspring, consHVal_Offspring, toleranceG,toleranceH,CVType);
    %% ==============added part 1
    if any(stagCount==LocalSearchStag)
        if feasibility % Improve the objective based on a constrained problem
            [xTemp,xObj,xCV]=LocalSearch(bestInd,obj,consG,consH,Lower,Upper,maxFunEva_localSearch,toleranceG,toleranceH,algorithmLocalSeach,CVType);
            [bestInd, bestObjCV0,~]=updateBest(bestInd,bestObjCV,feasibility,xTemp,xObj,xCV);
            POP(bestIndRow,:)=bestInd;
            objVal(bestIndRow,:)=bestObjCV0;
            CV(bestIndRow,:)=0;
        else % Improve constraints violation
            CVobj=@(x) CVCal(x,obj,consG,consH,toleranceG,toleranceH,CVType);
            [xTemp,xCV,~]=LocalSearch(bestInd,CVobj,[],[],Lower,Upper,maxFunEva_localSearch,toleranceG,toleranceH,algorithmLocalSeach,CVType);
            if xCV < minCV
                [objValTemp,~,~]=evaluateIndividual(xTemp,obj,consG,consH);
                bestInd=xTemp;
                POP(bestIndRow,:)=xTemp;
                objVal(bestIndRow,:)=objValTemp;
                CV(bestIndRow,:)=xCV;
            end
        end
    end
    %% ==============added part 2
    % here is the stagCount, so, if the stop in advance criterion is false, then this part will not be executed
    if (stagCount> 0 && (stagCount<=20 || stagCount>= maxStagCount-20  )) || (~StopWhenNoImprovement && Gen > 0.8*MaxGen)
        if rand<0.5
            Offspring1=ReproduceDE(POP,Lower,Upper, 3,0.5,0.5, RepairType, bestInd);
        else
            Offspring1=ReproduceDE(POP,Lower,Upper, 2,0.5,0.5, RepairType, bestInd);
        end
        
        [objVal_Offspring1,consGVal_Offspring1,consHVal_Offspring1]=evaluateIndividual(Offspring1,obj,consG,consH);
        CV_Offspring1=CVCal0(consGVal_Offspring1, consHVal_Offspring1, toleranceG,toleranceH,CVType);
        replace=  (CV_Offspring==CV_Offspring1) & (objVal_Offspring >  objVal_Offspring1) ;
        replace0= (CV_Offspring > CV_Offspring1);
        replace= replace | replace0;
        
        Offspring(replace,:)=Offspring1(replace,:);
        objVal_Offspring(replace)=objVal_Offspring1(replace);
        CV_Offspring(replace)= CV_Offspring1(replace);
    end
    %% Main
    % Environmental selection
    switch EnvSelType
        case {1,'1V1'}
            % feasiblity rule
            replace=  (CV==CV_Offspring) & (objVal >  objVal_Offspring) ;
            replace0= (CV > CV_Offspring);
            replace= replace | replace0;
            POP(replace,:)=Offspring(replace,:); 
            objVal(replace)=objVal_Offspring(replace);
            CV(replace)= CV_Offspring(replace);
            % Update the best
            [bestInd, bestObjCV,feasibility]=updateBest(bestInd,bestObjCV,feasibility,POP,objVal,CV);
            if feasibility
                bestObj0=bestObjCV;
                bestInd_feasible0=bestInd;
                minCV0=0;
                feasibile= CV==0;
                bestIndexTemp=(objVal==bestObjCV) & feasibile;
                bestIndexRowTemp=find(bestIndexTemp);
                bestIndRow=bestIndexRowTemp(randi(sum(bestIndexTemp)));
            else
                bestObj0=inf;
                bestInd_feasible0=[];
                minCV0=bestObjCV;
                bestIndexTemp=(CV==bestObjCV);
                bestIndexRowTemp=find(bestIndexTemp);
                bestIndRow=bestIndexRowTemp(randi(sum(bestIndexTemp)));
            end
        case {2,'AllCompaire'}
    end
    % Stop Optimizing in advance
    if StopWhenNoImprovement
        if bestObj~=inf
            objImprovent=bestObj-bestObj0;
            epsilon_delta=objImprovent/(abs(bestObj)+1e-8);
            if epsilon_delta < 1e-6
                stagCount=stagCount+1;
            else
                stagCount=0;
            end
        elseif bestObj0~=inf
            stagCount=0;
        else
            CVImprovement=minCV-minCV0;
            if CVImprovement>1e-6
                stagCount=0;
            else        
                stagCount=stagCount+1;
            end
        end
    end
    
    bestInd_feasible=bestInd_feasible0;
    bestObj=bestObj0;
    minCV=minCV0;
    
    if (StopWhenNoImprovement && stagCount== maxStagCount) || Gen==MaxGen
        if feasibility % Improve the objective based on a constrained problem
            [xTemp,xObj,xCV]=LocalSearch(bestInd,obj,consG,consH,Lower,Upper,maxFunEva_localSearch_final,toleranceG,toleranceH,algorithmLocalSeach,CVType);
            [bestInd, bestObjCV0,feasibility]=updateBest(bestInd,bestObjCV,feasibility,xTemp,xObj,xCV);
            POP(bestIndRow,:)=bestInd;
            objVal(bestIndRow,:)=bestObjCV0;
            CV(bestIndRow,:)=0;
            
            bestInd_feasible=bestInd;
            bestObj=bestObjCV0;
        else % Improve constraints violation
            CVobj=@(x) CVCal(x,obj,consG,consH,toleranceG,toleranceH,CVType);
            [xTemp,xCV,~]=LocalSearch(bestInd,CVobj,[],[],Lower,Upper,maxFunEva_localSearch_final,toleranceG,toleranceH,algorithmLocalSeach,CVType);
            if xCV < minCV
                [objValTemp,~,~]=evaluateIndividual(xTemp,obj,consG,consH);
                bestInd=xTemp;
                POP(bestIndRow,:)=xTemp;
                objVal(bestIndRow,:)=objValTemp;
                CV(bestIndRow,:)=xCV;
                if xCV==0
                    bestInd_feasible=xTemp;
                    bestObj=objValTemp;
                    feasibility=true;
                end
            end
        end
        
        break;
    end
end
end

%% Utility functions
% #---1
function [values ]=funcAll(functionHandles,x)

numFunc=length(functionHandles);
if numFunc==0
    values=zeros(size(x,1),1);
elseif numFunc==1 && ~isa(functionHandles,'cell')
    values=functionHandles(x);
else
    values=zeros(size(x,1),numFunc);
    parfor ii=1:numFunc
        values(:,ii)=functionHandles{ii}(x);
    end
end
end
% #---2
function [objVal,consGVal,consHVal]=evaluateIndividual(POP,obj,consG,consH)
% consG and consH are cell of function handles or function handle
% If consG and consH are numerical, obj will encompass all the functions

NP=size(POP,1);
if isnumeric(consG) && isnumeric(consH)
    [objVal,consGVal,consHVal]=obj(POP);
    if isempty(consGVal)
        consGVal=zeros(NP,1);
    end
    if isempty(consHVal)
        consHVal=zeros(NP,1);
    end
else
    objVal=obj(POP);
    consGVal=funcAll(consG,POP);
    consHVal=funcAll(consH,POP);
end
end
% #---3
function [xTemp,objVal,CV]=LocalSearch(x,obj,consG,consH,Lower,Upper,maxFunEva,toleranceG,toleranceH,algorithmLocalSeach,CVType)

if nargin<7 || isempty(maxFunEva)
    maxFunEva=300;
end
if nargin<8 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<9 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<10 || isempty(algorithmLocalSeach)
    algorithmLocalSeach='sqp'; % 'interior-point';  'sqp'; 'trust-region-reflective';
end
if nargin<11 || isempty(CVType)
    CVType=1;
end
nonlcons=@(x) consCal(x,obj,consG,consH,toleranceG,toleranceH,CVType);
options = optimset('Algorithm', algorithmLocalSeach, 'MaxFunEvals', maxFunEva, 'Display', 'off');
[xTemp,objVal]=fmincon(obj,x,[],[],[],[],Lower,Upper,nonlcons,options);
if any(xTemp< Lower) || any(xTemp > Upper)
    xTemp(xTemp < Lower) = Lower(xTemp <Lower);
    xTemp(xTemp > Upper) = Upper(xTemp > Upper);
    objVal = obj(xTemp);
end
CV=CVCal(xTemp,obj,consG,consH,toleranceG,toleranceH,CVType);
end

% ---6
function [consGVal,consHVal]=consCal(POP,obj,consG,consH,toleranceG,toleranceH,CVType)
if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end

NP=size(POP,1);
if isnumeric(consG) && isnumeric(consH)
    [~,consGVal,consHVal]=obj(POP);
    if isempty(consGVal)
        consGVal=zeros(NP,1);
    end
    if isempty(consHVal)
        consHVal=zeros(NP,1);
    end
else
    consGVal=funcAll(consG,POP);
    consHVal=funcAll(consH,POP);
end
consGVal(consGVal == -inf) = 0;
% No recomendation for the following
% if nargin>4
%     CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
%     consGVal(CV==0,:)=0;
%     consHVal(CV==0,:)=0;
% end
% if nargin>4 && CVType==2
%     consGVal=consGVal-toleranceG;
%     consHVal=sign(consHVal).*(abs(consHVal)-toleranceH);
% elseif nargin>4 && CVType==1% approximate
%     num_cons=length(consGVal(1,:))+length(consHVal(1,:));
%     consGVal=consGVal-toleranceG/num_cons;
%     consHVal=sign(consHVal).*(abs(consHVal)-toleranceG/num_cons);
% end
end

% ---7
function [CV,consGVal_virtual,consHVal_virtual]=CVCal(POP,obj,consG,consH,toleranceG,toleranceH,CVType)

if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end
[consGVal,consHVal]=consCal(POP,obj,consG,consH);
CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
% for setting CVCal as an objective function
consGVal_virtual=zeros(length(CV),0);
consHVal_virtual=zeros(length(CV),0);
end

% ---8
function CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType)

if nargin<3 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<4 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<5 || isempty(CVType)
    CVType=1;
end
switch CVType
    case{1}
        CV=max((sum(max(consGVal,0),2)+sum(max(abs(consHVal)-toleranceH,0),2))-toleranceG,0);
    case{2}
        CV=sum(max(consGVal-toleranceG,0),2)+sum(max(abs(consHVal)-toleranceH,0),2);
end
end

% #--1
function [bestIndOutput, bestObjCVOutput,bestIndIndexRow,feasibility,CV,minCV]=findBest(POP,objVal,consGVal,consHVal,toleranceG,toleranceH,CVType)
[NP,~]=size(POP);

if nargin<3 || isempty(consGVal)
    consGVal=zeros(NP,1);
end
if nargin<4 || isempty(consHVal)
    consHVal=zeros(NP,1);
end
if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end
CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
feasible= CV==0;
% Record the best
if any(feasible)
    minObjValFeasible=min(objVal(feasible));
    minCV=0;
    bestIndIndex= objVal== minObjValFeasible;
    bestIndIndex(~feasible)=false;
    bestInd=POP(bestIndIndex,:);
    numBestIndIndex=sum(bestIndIndex);
    randBestIndex=randi(numBestIndIndex);
    bestIndOutput=bestInd(randBestIndex,:);% Best feasible individual
    bestObjCVOutput=minObjValFeasible;% Objective value of the best feasible individual
    feasibility=true;
else
    minCV=min(CV);
    bestIndIndex= CV== minCV;
    bestInd=POP(bestIndIndex,:);
    numBestIndIndex=sum(bestIndIndex);
    randBestIndex=randi(numBestIndIndex);
    bestIndOutput=bestInd(randBestIndex,:);% Best infeasible individual
    bestObjCVOutput=minCV;% Constraint violation value of the best infeasible individual
    feasibility=false;
end
bestIndIndexRowTemp=find(bestIndIndex);
bestIndIndexRow=bestIndIndexRowTemp(randBestIndex);
end

function [bestIndNew, bestObjCVNew,feasibility]=updateBest(bestIndOld,bestObjCVOld,feasibilityOld,POPNew,objValNew,CVNew)

feasible= CVNew==0;
if feasibilityOld % Best to date is feasible
    feasibility=true;
    if any(feasible)
        minObjValFeasible=min(objValNew(feasible));
        if minObjValFeasible<bestObjCVOld
            bestIndIndex= objValNew== minObjValFeasible;
            bestIndIndex(~feasible)=false;
            bestInd=POPNew(bestIndIndex,:);
            numBestIndIndex=sum(bestIndIndex);
            randBestIndex=randi(numBestIndIndex);
            bestIndNew=bestInd(randBestIndex,:);% Best feasible individual
            bestObjCVNew=minObjValFeasible;% Objective value of the best feasible individual
        else
            bestIndNew=bestIndOld;
            bestObjCVNew=bestObjCVOld;
        end
    else
        bestIndNew=bestIndOld;
        bestObjCVNew=bestObjCVOld;
    end
else % Best to date is infeasible
    if any(feasible)
        feasibility=true;
        minObjValFeasible=min(objValNew(feasible));
        bestIndIndex= objValNew== minObjValFeasible;
        bestIndIndex(~feasible)=false;
        bestInd=POPNew(bestIndIndex,:);
        numBestIndIndex=sum(bestIndIndex);
        randBestIndex=randi(numBestIndIndex);
        bestIndNew=bestInd(randBestIndex,:);% Best feasible individual
        bestObjCVNew=minObjValFeasible;% Objective value of the best feasible individual
    else
        feasibility=false;
        minCVNew=min(CVNew);
        if minCVNew < bestObjCVOld
            bestIndIndex= CVNew== minCVNew;
            bestInd=POPNew(bestIndIndex,:);
            numBestIndIndex=sum(bestIndIndex);
            randBestIndex=randi(numBestIndIndex);
            bestIndNew=bestInd(randBestIndex,:);% Best infeasible individual
            bestObjCVNew=minCVNew;% Constraint violation value of the best infeasible individual
        else
            bestIndNew=bestIndOld;
            bestObjCVNew=bestObjCVOld;
        end
    end
end
end