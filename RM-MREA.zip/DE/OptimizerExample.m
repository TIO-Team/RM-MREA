clear;close;clc;
addpath(genpath('..'))
% Optimize Example
suite=@CEC2006;
fnum=5;
Dim=0;
toleranceG=1e-5;
toleranceH=1e-5;

%%
[Dim0,num_g,num_h,upperB,lowerB,x_best,f_best,problem]=get_ProblemInfo(fnum,Dim,suite);
MuteType=6; RepairType=1; StopWhenNoImprovement=false; FPool=[0.2,0.4,0.6]; CRPool=[0.2,0.4,0.6]; NP=100; MaxGen=1000; EnvSelType=1; CVType=1; maxStagCount=100;
problem=@(x)suite(x,fnum);
runNum=1;
runExp=2;

DEParameters={lowerB,upperB,problem,num_g,num_h,NP,MaxGen,FPool, CRPool,StopWhenNoImprovement,RepairType,MuteType,EnvSelType,toleranceG,toleranceH,CVType, maxStagCount};
for run=1:runExp
%     [POP, objVal, CV, bestInd_feasible, bestObj,Gen]=multipleRunDE(DEParameters,runNum);
[POP, objVal, CV, bestInd_feasible, bestObj,Gen]=OptimizerDE(lowerB,upperB,...
    problem,num_g,num_h,NP,MaxGen,FPool, CRPool,StopWhenNoImprovement,RepairType,MuteType,EnvSelType,toleranceG,toleranceH);
%     [POP, objVal, CV, bestInd_feasible, bestObj,Gen] =OptimizerDE(lowerB,upperB,problem,0,0,NP,MaxGen,toleranceG,toleranceH,CVType);
%%
    
    fprintf('TotalGen: %d; ObtainedOpti: %f; Optimum: %f;\n',Gen,bestObj,f_best);
    %% Improve
    nonlcon=@(x) nonlcon0(x,problem);
    numLocalSearch=300;
    algorithmLocalSeach='sqp'; % 'interior-point';  'sqp'; 'trust-region-reflective';
    options = optimset('Algorithm', algorithmLocalSeach, 'MaxFunEvals', numLocalSearch, 'Display', 'off');
    [bestInd_feasible0,bestObj0]=fmincon(problem,bestInd_feasible,[],[],[],[],lowerB,upperB,nonlcon,options);

    fprintf('LocalSearch: %d; ObtainedOpti: %f; Optimum: %f;\n',numLocalSearch,bestObj0,f_best);
    fprintf('ObtainedOpti: %.15f; ObtainedOpti0: %.15f; Improvement: %.15f;  Optimum: %f;\n',bestObj,bestObj0,bestObj-bestObj0,f_best);
end
rmpath(genpath('..'));
%%
function [iecons,econs]=nonlcon0(x,problem)
[~,iecons,econs]=problem(x);
end
