% Experiment_Main
clear; close; clc;
diary('output.txt')
diary on
% xlswrite('1.xlsx',feasibilityCurrent);xlswrite('1.xlsx',bestObjCVCurrent,'sheet2')
tempPath=mfilename('fullpath');
tempPath=fileparts(tempPath);
resultsDir=fullfile(tempPath,'Results');
if ~exist(resultsDir,'dir')
    mkdir(resultsDir);
end
addpath(genpath('.'));
warning off;
%% Experiment setting
totalRun                =1;
suite                   = @CEC2020; % ExampleProblem CEC2006
Dim                     = 0; % 0, 10, 20, 30 50 100
CVType                  = 2;
toleranceG              = 0e-50;
toleranceH              = 1e-4;
maxFEs                  = 1000;
%EquaProblem             = false;
EquaProblem             = true;
compareAlgoName         = 'RM_MREA';%'MEALR'; % SADECGOV4
switch compareAlgoName 
    case {'GloSADE','MPMLS','SACCDE'}
        AlgoFuncName                = str2func([compareAlgoName,'_Exe']);
    otherwise
        AlgoFuncName                = str2func(compareAlgoName);
end

switch func2str(suite)
    case 'CEC2006' 
        % no G20 G22
        if EquaProblem
%             fnum = [3 5 11 13 14 15 17 20, 21, 22, 23]; % All
            fnum = [3 5 11 13 14 15 17 21 23];            % No: G20 G22
        else
            fnum = [1, 2, 4, 6, 7, 8, 9, 10, 12, 16, 18, 19, 24];  % All
            % fnum = 4;
        end
        
    case 'CEC2010'
        if EquaProblem
            fnum = [2, 3, 4, 5, 6, 9, 10, 11, 12, 16, 17, 18]; % All
        else
            fnum = [1, 7, 8, 13, 14, 15];                      % All
        end
    case 'CEC2017'
        if EquaProblem
            fnum = [3, 6, 7, 8, 9, 10, 11, 14, 15, 16, 17, 18, 23, 24, 25, 26, 27]; % All
        else
%             fnum = [1, 2, 4, 5, 12, 13, 19, 20, 21, 22, 28]; % All
            fnum = [1, 2, 4, 5, 13, 19, 20, 22, 28];           % No: 12, 21
        end
    case 'CEC2020'
        if EquaProblem
            % fnum = [2]; % All
            fnum=[1,3:33,45:57];%1,3:33,45:57
        end
end

%% Experiment
for ii = fnum
    %% PreProcessing
    [Dim0,num_g,num_h,upperB,lowerB,x_best,f_best,problem]=get_ProblemInfo(ii,Dim,suite);
    % Sample Size Setting
    switch compareAlgoName
        case 'GloSADE'
            num_initSample = 80;
        case 'MPMLS'
            num_initSample = 60;
        case 'SACCDE'
            num_initSample = 15;
        case 'MEALR'
            num_initSample = min(5*Dim0,60);
        case 'RM_MREA'
            num_initSample = 100;
        case 'MGRLR'
            num_initSample = min(5*Dim0,60);
        otherwise
            if Dim0 <= 30
                num_initSample = 100;
            else
                num_initSample = 100;
            end
    end
    %--------------------------------
    % if ii==55
    %    run_start=18;
    % else
    %    run_start=1; 
    % end
    enableVisualization=1;
    % 指定某些问题的运行次数（如10号问题跑5次，24号问题跑30次）
    specialRuns = containers.Map([29,3,49], [25,25,25]);
    if isKey(specialRuns, ii)
            runTimes = specialRuns(ii);
    else
            runTimes = totalRun;
    end

    for run = 1:runTimes
        global initial_flag
        initial_flag = 0;
        [DATA{ii,run},UpdateDATA{ii,run},bestObjCVCurrent{ii,run},feasibilityCurrent{ii,run},timeConsumed{ii,run}] = AlgoFuncName(suite,ii,Dim,num_initSample,maxFEs,toleranceG,toleranceH,CVType);
        fprintf('Suite: %s; Fnum: %2d; Run: %2d; bestObjCV: %5.2E; Feasible: %1d \n\n',...
            func2str(problem),ii,run,bestObjCVCurrent{ii,run},feasibilityCurrent{ii,run});
        xlswrite('result.xlsx',feasibilityCurrent);xlswrite('result.xlsx',bestObjCVCurrent,'sheet2');
        % save MGRLR_DATA DATA
        % save MGRLR_RunningTime timeConsumed
        % t1 = cell2table(feasibilityCurrent);t2 = cell2table(bestObjCVCurrent);writetable(t1, '2.xlsx', 'Sheet', 1); writetable(t2, '2.xlsx', 'Sheet', 2);
    end
end
suiteName    = func2str(suite);
if EquaProblem
   consType = 'Equal';
else
   consType = 'Inequal';
end
dataFileName = sprintf('%s_%s_%d_DATA_%s',suiteName,consType,Dim,compareAlgoName);
save(dataFileName);
% save(dataFileName,'DATA','-append','-nocompression');

