clc;
clear;
format short e

% the known optimal objective function value
fbias=[1.8931162966E+02,7.0490369540E+03,-4.5291197395E+03,-3.8826043623E-01,-4.0000560000E+02,1.8638304088E+00, 1.5670451000E+00,...
     2.0000000000E+00, 2.5576545740E+00,1.0765430833E+00,9.9238463653E+01, 2.9248305537E+00,2.6887000000E+04,5.3638942722E+04,...
     2.9944244658E+03,3.2213000814E-02,1.2665232788E-02,5.8853327736E+03,1.6702177263E+00,2.6389584338E+02,2.3524245790E-01,...
     5.2576870748E-01,1.6069868725E+01,2.5287918415E+00,1.6161197651E+03,3.5359231973E+01,5.2445076066E+02,1.4614135715E+04,...
     2.9648954173E+06,2.6138840583E+00,0.0000000000E+00,-3.0665538672E+04,2.6393464970E+00,...
     0.0000000000E+00,7.9963854000E-02,4.7733529000E-02,1.8593563000E-02,2.7139366000E+00,2.7515909000E+00,0.0000000000E+00,0.0000000000E+00,...
     7.7027102000E-02,7.9835970000E-02,-6.2731715000E+03,...
     3.0739360000E-02,2.0240335000E-02,1.2783068000E-02,1.6787535766E-02,9.3118741800E-03,1.5051470000E-02,...
     4.5508511497E+03,3.3489821493E+03,4.9976069290E+03,4.2405482538E+03,6.6964145128E+03,1.4746580000E+04,3.2132917019E+03];

load MGRLR_DATA

problemSet=[1:57];
for problemIndex=1:57
    problem=problemSet(problemIndex);
    par=Cal_par(problem);
    noindex=[2,34:44];
    if  ~ismember(problem,noindex)
        for time=1:25
            data=DATA{problem,time};
            info=data.y;
            f=info(:,1);
            f=f-fbias(problem);
            if par.g~=0
               g=info(:,2:par.g+1);
            else
               g=[];
            end
            if par.h~=0
               h=info(:,par.g+1+1:end);
            else
               h=[];
            end
            conv=[max(0,g),max(abs(h)-0.0001,0)];
            conv=sum(conv,2);
            convbest(1,time)=conv(1);
            if convbest(1,time)~=0
               fbest(1,time)=NaN;
            else
               fbest(1,time)=f(1);
            end
            for FES=2:1000
                if conv(FES)<=convbest(FES-1,time)
                    convbest(FES,time)=conv(FES);
                else
                    convbest(FES,time)= convbest(FES-1,time);
                end
                if conv(FES)~=0
                    fbest(FES,time)=fbest(FES-1,time);
                else
                    if isnan(fbest(FES-1,time))
                       fbest(FES,time)=f(FES);
                    else
                        if f(FES)<=fbest(FES-1,time)
                           fbest(FES,time)=f(FES);
                        else
                            fbest(FES,time)=fbest(FES-1,time);
                        end
                    end
                end
            end
            f_outcome(time,problemIndex)=fbest(end,time);
            conv_outcome(time,problemIndex)=convbest(end,time);
        end
        Fbest{problemIndex}=fbest;
        CVbest{problemIndex}=convbest;
    else
        for time=1:25
             f_outcome(time,problemIndex)=NaN;
             conv_outcome(time,problemIndex)=NaN;
        end
        Fbest{problemIndex}=[];
        CVbest{problemIndex}=[];
    end     
end




CV=[mean(conv_outcome);std(conv_outcome)];
f_outcome(f_outcome<10e-08)=0;

for i=1:57
    outcome=f_outcome(:,i);
    index=find(~isnan(outcome));
    length(index);
    if ~isempty(index)
       Obj(1,i)=mean(outcome(index));
       Obj(2,i)=std(outcome(index));
    else
       Obj(1,i)=NaN;
       Obj(2,i)=NaN; 
    end
    FR(i)=length(index)/25;
end
Result=[Obj;FR;CV]
