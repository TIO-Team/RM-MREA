function [f,g,h]=ATF1(x)
% constrained Rastrigin function
% the optimum solution is a interior point in the feasible region
x2=x.^2;
f=sum(x2,2)-sum(10*cos(2*pi*x),2)+10;
g=x2(:,1)/4+x2(:,2)/9-1;
h=[];