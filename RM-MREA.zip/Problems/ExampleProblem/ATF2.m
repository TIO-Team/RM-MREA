function [f,g,h]=ATF2(x)
% constrained Rastrigin function
% the optimum solution is on the boundary of the feasible region
x2=x.^2;
f=sum(x2,2)-sum(10*cos(2*pi*x),2)+10;
g=3*(x(:,1)+9).^2+x(:,2).^2-2;
h=[];