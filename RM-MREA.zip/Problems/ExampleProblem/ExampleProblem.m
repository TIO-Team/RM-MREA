function [f,g,h]=ExampleProblem(x,fnum)

% [popSize,Dim]=size(x);

switch fnum
    case {1,'cons3_2D_Sasena_1'}
        [f,g,h]=cons3_2D_Sasena_1(x);
    case {2,'ATF1'}
        [f,g,h]=ATF1(x);
    case {3,'ATF2'}
        [f,g,h]=ATF2(x);
    case {4,'ShangFeng_1D_Cons'}
        A = 1;
        B = 4/2*pi;
        C = -0/2*pi;
%         x = (-3:0.01:3)';
        f = shanfeng_1D(x,0);
        g = shanfeng_1D(x,-1) + (A.*sin(B.*x-C));
        h = [];
    case {5,'ShangFeng_1D_Cons_2'}
        A = 1;
        B = 4/2*pi;
        C = -0/2*pi;
        %         x = (-3:0.01:3)';
        f   = shanfeng_1D(x,0);
        x_g = x-0.2;
        g = shanfeng_1D(x_g,-1) + (A.*sin(B.*x_g-C));
        h = [];
        
end
