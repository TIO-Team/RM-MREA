function obj = Rastrigin(x)
%------------------------------------------------
% Branin Test Function for Nonlinear Optimization
% Taken from "Towards Global Optimisation 2",edited by L.C.W. Dixon and G.P.
% Szego, North-Holland Publishing Company, 1978. ISBN 0 444 85171 2
%
% -3 <= x1 <= 3                  
%  -3 <= x2 <= 3                  
% fmin = -6.5466
%---------------------------------------------------------
[N,D] = size(x);
obj=10*D+sum(x(:,1:D).^2-10*cos(2*pi*x(:,1:D)),2);