function [f,g,h]=cons3_2D_Sasena_1(x)

% x [0,1]
% Sasena, Michael James. 2002. 'Flexibility and efficiency enhancements for
% constrained global design optimization with kriging approximations', University of Michigan Ann Arbor.

f=-(x(:,1)-1).^2-(x(:,2)-0.5).^2;
g(:,1)=((x(:,1)-3).^2+(x(:,2)+2).^2).*exp(-x(:,2).^7)-12;
g(:,2)=10*(x(:,1))+x(:,2)-7;
g(:,3)=(x(:,1)-0.5).^2+(x(:,2)-0.5).^2-0.2;
h=[];
