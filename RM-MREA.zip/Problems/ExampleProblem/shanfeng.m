function obj = shanfeng(x)
%------------------------------------------------
% Branin Test Function for Nonlinear Optimization
% Taken from "Towards Global Optimisation 2",edited by L.C.W. Dixon and G.P.
% Szego, North-Holland Publishing Company, 1978. ISBN 0 444 85171 2
%
% -3 <= x1 <= 3                  
%  -3 <= x2 <= 3                  
% fmin = -6.5466
%---------------------------------------------------------
x1 = x(:,1);
x2 = x(:,2);
obj=3*(1-x1).^2.*exp(-(x1.^2) - (x2+1).^2) ...
    - 10*(x1/5 - x1.^3 - x2.^5).*exp(-x1.^2-x2.^2) ...
    - 1/3*exp(-(x1+1).^2 - x2.^2) ;
