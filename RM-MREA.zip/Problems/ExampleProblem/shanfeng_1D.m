function obj = shanfeng_1D(x,Para1)
%------------------------------------------------
% Branin Test Function for Nonlinear Optimization
% Taken from "Towards Global Optimisation 2",edited by L.C.W. Dixon and G.P.
% Szego, North-Holland Publishing Company, 1978. ISBN 0 444 85171 2
%
% -3 <= x1 <= 3                  
%  -3 <= x2 <= 3                  
% fmin = -6.5466
%---------------------------------------------------------
if nargin < 2 || isempty(Para1)
    Para1 = 0;
end
x1 = x(:,1);
x2 = Para1*ones(size(x1));
obj=3*(1-x1).^2.*exp(-(x1.^2) - (x2+1).^2) ...
    - 10*(x1/5 - x1.^3 - x2.^5).*exp(-x1.^2-x2.^2) ...
    - 1/3*exp(-(x1+1).^2 - x2.^2) ;
