function obj = zhengxian(x)
%----------------------------------------------------------
% Goldstein-Price Test Function for Nonlinear Optimization
% Taken from "Towards Global Optimisation 2",edited by L.C.W. Dixon and G.P.
% Szego, North-Holland Publishing Company, 1978. ISBN 0 444 85171 2
%
% -2 <= x1 <= 2
% -2 <= x2 <= 2
% fmin = 3
% xmin =[ 0, -1]
%      
% http://www4.ncsu.edu/~definkel/research/index.html
%---------------------------------------------------------
x1 = x(:,1);
obj =sin(x1)+5*sin(4*x1)-0.2*sin(0.2*x1)+30*sin(20*x1)-20*sin(10*x1);