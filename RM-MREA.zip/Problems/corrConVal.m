function  [consGVal,consHVal] = corrConVal(consGVal,consHVal,num_g,num_h)
if num_g==0
    consGVal=[];
end
if num_h==0
    consHVal=[];
end
if nargout <= 1
    consGVal = [consGVal,consHVal];
end