clear; close all; clc;
suite   =@ExampleProblem; % @complexProblems;
Dim     = 1;
fnum    = 5;


%% complexProblems
%   1 ========= 'Ackley'
%   2 ========= Rastrigin
%   3 ========= Griewank
%   4 ========= Rosenbrock
%   5 ========= Ellipsoid
%% ExampleProblem
%   1 ========= cons3_2D_Sasena_1
%   2 ========= ATF1
%   3 ========= ATF2
%   4 ========= 
%   5 ========= 
%   1 ========= 
%   1 ========= 
%   1 ========= 
% close;
x = (-3:0.01:3)';
[f,g,h] = suite(x,fnum);
MaxF    = max(f);
MinF    = min(f);
MaxG    = max(g);
MinG    = min(g);
MaxY    = max(MaxF,MaxG);
MinY    = min(MinF,MinG);
% A = 1;
% B = 4/2*pi;
% C = -0/2*pi;
% x = (-3:0.01:3)';
% f = shanfeng_1D(x,0);
% g = shanfeng_1D(x,-1) + (A.*sin(B.*x-C));
% g = f.*(A.*sin(B.*x-C));
% g  = Rastrigin(x);
Feasible = (g<=0);
% f_feasible = f;
% f_feasible(~Feasible) = 0;
MarginExR = 20;
AreaF               = MaxY.*ones(size(f))+(MaxY - MinY)/MarginExR;
AreaF(~Feasible)    = MinY-(MaxY - MinY)/MarginExR;

% area(x,f_feasible);
hold on;
area(x,AreaF,'linestyle','none','FaceColor',[0 0 0],'BaseValue', MinY-(MaxY - MinY)/MarginExR,'EdgeColor','none','FaceAlpha',0.3);
% fill(x,-AreaF,[0.7 0.7 0.7],'FaceAlpha',0.5,'LineStyle','none');
plot(x,f,'b-',LineWidth=1);

plot(x,g,'r-',LineWidth=1);
plot(x,zeros(size(x)),'--',LineWidth=1);
ylim([ MinY-(MaxY - MinY)/MarginExR, MaxY+(MaxY - MinY)/MarginExR]);
% alpha = 0;
% xticklabels(xticks);
figure;
% subplot(2,1,1);
[ha,hpos] = tight_subplot(2,1,0.05);
axes(ha(1));
hold on;
area(x,AreaF,'linestyle','none','FaceColor',[0 0 0],'BaseValue', MinY-(MaxY - MinY)/MarginExR,'EdgeColor','none','FaceAlpha',0.3);
plot(x,f,'b-',LineWidth=1);
ylim([ MinY-(MaxY - MinY)/MarginExR, MaxY+(MaxY - MinY)/MarginExR]);
xlim([-3,3]);
xticks([]);
% xticklabels;
yticklabels('auto');

% subplot(2,1,2);
axes(ha(2));
hold on;
area(x,AreaF,'linestyle','none','FaceColor',[0 0 0],'BaseValue', MinY-(MaxY - MinY)/MarginExR,'EdgeColor','none','FaceAlpha',0.3);
plot(x,g,'r-',LineWidth=1);
plot(x,zeros(size(x)),'m--',LineWidth=1);
ylim([ MinY-(MaxY - MinY)/MarginExR, MaxY+(MaxY - MinY)/MarginExR]);
xlim([-3,3]);
xticks(-3:1:3);
xticklabels(-3:1:3);
yticklabels('auto');




% saveas(gcf,fullfile(SolutionsPlotPath_FIG,Problem_jj),'fig');
% exportgraphics(gcf,strcat(num2str(0.2),'.tif'),'Resolution',300);
% exportgraphics(gcf,strcat(fullfile(SolutionsPlotPath_PDF,Problem_jj),'.pdf'),'ContentType','vector');
% exportgraphics(gcf,strcat(fullfile(SolutionsPlotPath_EPS,Problem_jj),'.eps'),'ContentType','vector');
% exportgraphics(gcf,strcat(fullfile(SolutionsPlotPath_EMF,Problem_jj),'.emf'),'Resolution',100);


%%
% [Dim,num_g,num_h,upperB,lowerB,x_best,f_best,problem]   =  get_ProblemInfo(fnum,Dim,suite);
% ub = upperB;
% lb = lowerB;
% % Plot set
% PlotContour             = true;
% LineWidth               = 2;
% toleranceH              = 1e-10;
% showFInFeasibleRegion   = false;
% numFLevels              = 10;
% plotEachEqualityCons    = false;
% isgray                  = true;
% contourAdapt            = true;
% switch Dim
%     case 1
%        precision    =   (ub-lb) /2000;
%        x            =   (lb:precision:ub)';
%        [f,g,h]      =   problem(x,fnum);
%        ffig         =   plot(x,f,'k-','LineWidth',LineWidth);
%        hold on;
%        for ii=1:num_g
%            gfig=plot(x,g(:,ii),'b-','LineWidth',LineWidth);
%        end
%        for ii=1:num_h
%            hfig=plot(x, h(:,ii),'r-','LineWidth',LineWidth);
%        end
%        if num_g~=0 && num_h~=0
%            legend([ffig,gfig,hfig],'Objective','Inequality Constraints','Equality Constraints');
%        elseif num_g~=0 && num_h==0
%            legend([ffig,gfig],'Objective','Inequality Constraints');
%        elseif num_g==0 && num_h~=0
%            legend([ffig,gfig,hfig],'Objective' ,'Equality Constraints');
%        else
%            legend('Objective');
%        end
%        xlim([lowerB,upperB]);
%        hold off;
%     case 2
%         if PlotContour
%             precision=max(ub-lb) /2000;
%             x1=lb(1):precision:ub(1);
%             x2=lb(2):precision:ub(2);
%             [X,Y]=meshgrid(x1,x2);
%             [f,g,h]=problem([X(:),Y(:)],fnum);
%             F=reshape(f,size(X));
%             if num_g~=0%===============================Inequality Constraints
%                 g_lessThan0= g<=0;
%                 FeasibleG=all(g_lessThan0,2);
%             else
%                 FeasibleG=true(length(f),1);
%             end
%             if num_h~=0%===========================Equality Constraints
%                 h_lessThanToleranceH=abs(h)<=toleranceH;
%                 FeasibleH=all(h_lessThanToleranceH,2);
%             else
%                 FeasibleH=true(length(f),1);
%             end
%             feasible=FeasibleG & FeasibleH;
%             Feasible=reshape(feasible,size(X));
%             if showFInFeasibleRegion
%                 lbLocal=[min(X(Feasible),[],'all'),min(Y(Feasible),[],'all')];
%                 ubLocal=[max(X(Feasible),[],'all'),max(Y(Feasible),[],'all')];
%                 precisionLocal=max(ubLocal-lbLocal) /2000;
%                 x1Local=lbLocal(1):precisionLocal:ubLocal(1);
%                 x2Local=lbLocal(2):precisionLocal:ubLocal(2);
%                 [XLocal,YLocal]=meshgrid(x1Local,x2Local);
%                 [fLocal,gLocal,hLocal]=problem([XLocal(:),YLocal(:)],fnum);
%                 FLocal=reshape(fLocal,size(XLocal));
%                 if num_g~=0%===============================Inequality Constraints
%                     g_lessThan0Local= gLocal<=0;
%                     FeasibleGLocal=all(g_lessThan0Local,2);
%                 else
%                     FeasibleGLocal=true(length(fLocal),1);
%                 end
%                 if num_h~=0%===========================Equality Constraints
%                     h_lessThanToleranceHLocal=abs(hLocal)<=toleranceH;
%                     FeasibleHLocal=all(h_lessThanToleranceHLocal,2);
%                 else
%                     FeasibleHLocal=true(length(fLocal),1);
%                 end
%                 hold on;
%                 if num_g ~=0 || num_h~=0
%                     feasibleLocal=FeasibleGLocal & FeasibleHLocal;
%                     FeasibleLocal=reshape(feasibleLocal,size(XLocal));
%                     if num_h~=0
%                         dotsColor=[1,0,0];
%                         contour(XLocal,YLocal,FLocal,numFLevels*5,'ShowText','off','LineWidth',LineWidth);%============================Objective
%                         plot(XLocal(FeasibleLocal),YLocal(FeasibleLocal),'.','Color',dotsColor);
%                     else
%                         dotsColor=[0.5,0.5,0.5];
%                         plot(XLocal(FeasibleLocal),YLocal(FeasibleLocal),'.','Color',dotsColor);
%                         contour(XLocal,YLocal,FLocal,numFLevels*5,'ShowText','off','LineWidth',LineWidth);%============================Objective
%                     end
%                 else
%                     contourf(XLocal,YLocal,FLocal,numFLevels*5,'ShowText','off','LineWidth',LineWidth*0.5);%============================Objective
%                     if isgray
%                         colormap gray;
%                         cmap = colormap;
%                         cmap=cmap*2;
%                         ccmap=(mapminmax(cmap',0.35,1))';
%                         colormap(ccmap);
%                     end
%                 end
%                 if plotEachEqualityCons && num_h~=0
%                     for ii=1:num_h
%                         HLocal=reshape(hLocal(:,ii),size(XLocal));
%                         contour(XLocal,YLocal,HLocal,[0,0],'r--','LineWidth',LineWidth);
%                     end
%                 end
%                 %        colormap('gray');
%                 colorbar;
%                 hold off;
%             else
%                 %% Figure: full Space
%                 if num_g ~=0 || num_h~=0
%                     hold on;
%                     if num_h~=0
%                         dotsColor=[1,0,0];
%                         contour(X,Y,F,numFLevels*2,'ShowText','off','LineWidth',LineWidth);%============================Objective
%                         plot(X(Feasible),Y(Feasible),'.','Color',dotsColor);
%                     else
%                         dotsColor=[0.5,0.5,0.5];
%                         plot(X(Feasible),Y(Feasible),'.','Color',dotsColor);
%                         contour(X,Y,F,numFLevels*2,'ShowText','off','LineWidth',LineWidth);%============================Objective
%                     end
%                     %            scatter(X(ifFeasible),Y(ifFeasible),1,[0.5,0.5,0.5],'filled','Marker','o');% the points on the boundary will exceed
%                     %            alpha(0.1);
%                 else
%                     specificNumFLevels=floor(numFLevels*1.5);
%                     if contourAdapt
%                         % more contour should be placed in the minimum
%                         minf=min(f);
%                         fRange=max(f)-minf;
%                         levelSpecific=minf+fRange*(linspace(0,1,specificNumFLevels)).^1.25;
%                     else
%                         levelSpecific=linspace(min(f),max(f),specificNumFLevels);
%                     end
%                     contourf(X,Y,F,levelSpecific,'ShowText','off','LineWidth',LineWidth*0.5);%============================Objective
%                     if isgray
%                         colormap gray;
%                         cmap = colormap;
%                         cmap=cmap*2;
%                         ccmap=(mapminmax(cmap',0.35,1))';
%                         colormap(ccmap);
%                     end
%                 end
%                 if plotEachEqualityCons && num_h~=0
%                     for ii=1:num_h
%                         H=reshape(h(:,ii),size(X));
%                         contour(X,Y,H,[0,0],'r-','LineWidth',LineWidth);
%                     end
%                 end
%                 %        colormap('gray');
%                 colorbar;
%                 hold off;
%             end
%         end
%         fig2 = figure(2);
%         ax2  = axes(fig2);
%         precision=max(ub-lb) /200;
%         x1=lb(1):precision:ub(1);
%         x2=lb(2):precision:ub(2);
%         [X,Y]=meshgrid(x1,x2);
%         [f,g,h]=problem([X(:),Y(:)],fnum);
%         F=reshape(f,size(X));
%         surfObj = surf(ax2,X,Y,F);
%         surfObj.EdgeColor = "interp";
%         colormap('turbo'); %'parula' 'winter' 'turbo'     
% end