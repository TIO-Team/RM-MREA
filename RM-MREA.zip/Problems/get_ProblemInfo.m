function [dim,num_g,num_h,ub,lb,x_best,f_best,problem]=get_ProblemInfo(fnum,dim_scalable,suite)
% get the information of the test function
% ---------------------------------------------------------------------
% if there are two inputs, the test problem is scalable over the dimension of
% the design space
% CEC2006 is the default test problem suite
% ---------------------------------------------------------------------
% Input:
% fnum         - the test problem
% dim_scalable - the design dimension of a scalable problem if the
%                   parameter is given
% suite        - problem suite: CEC2006(default), CEC2010, CEC2017,
%                   ExampleProblem, WangHanding
%
% Output:
% dim            - the number of the dimensions in the design space
% ---------------------------------------------------------------------
if nargin<3
    problem=@CEC2006; % default setting
    suite='CEC2006';
else
    if isa(suite,'function_handle') % isa(suite,'function_handle')
        problem=suite;
        suite=func2str(suite);
    elseif ischar(suite) || isa(suite,'string')
        problem=str2func(suite);
    else, error('problem should be specified as a function handle or a string scalar or a char vector');
    end
end
scalable= nargin>1 && ~isempty(dim_scalable) && dim_scalable~=0;
%%
switch suite
    %% CEC2006
    case {'CEC2006','cec2006'}
        switch fnum
            case 1
                dim=13;
                if scalable, dim=dim_scalable; end
                num_g=9;
                num_h=0;
                lb=zeros(1,dim);
                ub=[1,1,1,1,1,1,1,1,1,100,100,100,1];
                x_best=[1,1,1,1,1,1,1,1,1,3,3,3,1];
                f_best=-15;
            case 2
                dim=20;% Original: 20 Scalable
                if scalable, dim=dim_scalable; end
                num_g=2;
                num_h=0;
                lb=zeros(1,dim);
                ub=10.*ones(1,dim);
                x_best=[3.16246061572185,3.12833142812967, 3.09479212988791, 3.06145059523469, 3.02792915885555, 2.99382606701730,2.95866871765285, 2.92184227312450, 0.49482511456933, 0.48835711005490, 0.48231642711865,0.47664475092742, 0.47129550835493, 0.46623099264167, 0.46142004984199, 0.45683664767217,0.45245876903267, 0.44826762241853, 0.44424700958760, 0.44038285956317];
                f_best=-0.80361910412559;%-0.40; %  -0.80361910412559
%             case 2
%                 dim=10;% Modified: dim, objective, constraints
%                 if scalable, dim=dim_scalable; end
%                 num_g=2;
%                 num_h=0;
%                 lb=zeros(1,dim);
%                 ub=10.*ones(1,dim);
%                 x_best=[3.16246061572185,3.12833142812967, 3.09479212988791, 3.06145059523469, 3.02792915885555, 2.99382606701730,2.95866871765285, 2.92184227312450, 0.49482511456933, 0.48835711005490, 0.48231642711865,0.47664475092742, 0.47129550835493, 0.46623099264167, 0.46142004984199, 0.45683664767217,0.45245876903267, 0.44826762241853, 0.44424700958760, 0.44038285956317];
%                 f_best=-0.80361910412559;

            case 3
                dim=10; % Original: 10 Scalable
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=1;
                lb=zeros(1,dim);
                ub=ones(1,dim);
                x_best=[0.31624357647283069,0.316243577414338339,0.316243578012345927,0.316243575664017895,0.316243578205526066,0.31624357738855069,0.316243575472949512,0.316243577164883938,0.316243578155920302,0.316243576147374916];
                f_best=-1.00050010001;
            case 4
                dim=5;
                if scalable, dim=dim_scalable; end
                num_g=6;
                num_h=0;
                lb=[78,33,27,27,27];
                ub=[102,45,45,45,45];
                x_best=[78,33,29.9952560256815985,45,36.7758129057882073];
                f_best=-3.066553867178332e4;%-31025.56; % Original -3.066553867178332e4;
            case 5
                dim=4;
                if scalable, dim=dim_scalable; end
                num_g=2; % Original 2
                num_h=3;% Original 3
                lb=[0,0,-0.55,-0.55];
                ub=[1200,1200,0.55,0.55];
                x_best=[679.945148297028709, 1026.06697600004691, 0.118876369094410433,0.39623348521517826];
                f_best=5126.4967140071;%5126.50;%Original 5126.4967140071
            case 6
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=2;
                num_h=0;
                lb=[13,0]; % -1
                ub=[100,100];% 1
                x_best=[14.09500000000000064,0.8429607892154795668];
                f_best=-6961.81387558015;
            case 7
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=8;
                num_h=0;
                lb=-10.*ones(1,dim);
                ub=10.*ones(1,dim);
                x_best=[2.17199634142692, 2.3636830416034,8.77392573913157, 5.09598443745173, 0.990654756560493, 1.43057392853463, 1.32164415364306,9.82872576524495, 8.2800915887356, 8.3759266477347];
                f_best=24.30620906818;
            case 8
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=2;
                num_h=0;
                lb=[0,0];
                ub=[10,10];
                x_best=[1.22797135260752599, 4.24537336612274885];
                f_best=-0.0958250414180359;
            case 9
                dim=7;
                if scalable, dim=dim_scalable; end
                num_g=4;
                num_h=0;
                lb=-10.*ones(1,dim);
                ub=10.*ones(1,dim);
                x_best=[2.33049935147405174,1.95137236847114592,-0.477541399510615805,4.36572624923625874,-0.624486959100388983,1.03813099410962173,1.5942266780671519];
                f_best=680.630057374402;
            case 10
                dim=8;
                if scalable, dim=dim_scalable; end
                num_g=6;
                num_h=0;
                lb=[100,1000,1000,10.*ones(1,5)];
                ub=[10000,10000,10000,1000.*ones(1,5)];
                x_best=[579.306685017979589, 1359.97067807935605, 5109.97065743133317, 182.01769963061534,295.601173702746792, 217.982300369384632, 286.41652592786852, 395.601173702746735];
                f_best=7049.24802052867;
            case 11
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=1;
                lb=-1.*ones(1,dim);
                ub=ones(1,dim);
                x_best=[0.707036070037170616,0.500000004333606807];
                f_best=0.7499;
            case 12
                dim=3;
                if scalable, dim=dim_scalable; end
                num_g=1;
                num_h=0;
                lb=zeros(1,dim);
                ub=10.*ones(1,dim);
                x_best=[5,5,5];
                f_best=-1;
            case 13
                dim=5;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=3;
                lb=zeros(1,dim)+[-2.3,-2.3,-3.2,-3.2,-3.2];
                ub=-lb;
                x_best=[-1.71714224003; 1.59572124049468; 1.8272502406271;-0.763659881912867;-0.76365986736498];
                f_best=0.053941514041898;
            case 14
                dim     = 10;
                if scalable, dim = dim_scalable; end
                num_g   = 0;
                num_h   = 3;
                lb      = zeros(1,dim)+1e-50;
                ub      = 10.*ones(1,dim);
                x_best  = [0.0406684113216282, 0.147721240492452, 0.783205732104114,...
                    0.00141433931889084, 0.485293636780388, 0.000693183051556082, 0.0274052040687766,...
                    0.0179509660214818, 0.0373268186859717, 0.0968844604336845];
                f_best  = -47.7648884594915;
            case 15
                dim     = 3;
                if scalable, dim = dim_scalable; end
                num_g   = 0;
                num_h   = 2;
                lb      = zeros(1,dim);
                ub      = 10.*ones(1,dim);
                x_best  = [3.51212812611795133, 0.216987510429556135, 3.55217854929179921];
                f_best  = 961.715022289961;
            case 16
                dim=5;
                num_g=38;
                num_h=0;
                lb=[704.4148,68.6,0,193,25];
                ub=[906.3855,288.88,134.75,287.0966,84.1988];
                x_best=[705.174537070090537,68.5999999999999943,102.899999999999991,282.324931593660324,37.5841164258054832];
                f_best=-1.90515525853479;
            case 17
                dim     = 6;
                if scalable, dim = dim_scalable; end
                num_g   = 0;
                num_h   = 4;
                lb      = [0, 0, 340,340,-1000,0];
                ub      = [400, 1000, 420,420,1000,0.5236];
                x_best  = [201.784467214523659, 99.9999999999999005,383.071034852773266,...
                    420,-10.9076584514292652, 0.0731482312084287128];
                f_best  = 8853.53967480648;
            case 18
                dim=9;
                num_g=13;
                num_h=0;
                lb=[-10.*ones(1,8),0];
                ub=[10.*ones(1,8),20];
                x_best=[-0.657776192427943163,-0.153418773482438542, 0.323413871675240938,-0.946257611651304398,-0.657776194376798906,-0.753213434632691414,0.323413874123576972,-0.346462947962331735,0.59979466285217542];
                f_best=-0.866025403784439;
            case 19
                dim=15;
                num_g=5;
                num_h=0;
                lb = zeros(1,dim);
                ub = 10.*ones(1,dim);
                x_best = [1.66991341326291344e-17,3.95378229282456509e-16,3.94599045143233784,1.06036597479721211e-16,3.2831773458454161,9.99999999999999822,1.12829414671605333e-17,1.2026194599794709e-17,2.50706276000769697e-15,2.24624122987970677e-15,0.370764847417013987,0.278456024942955571,0.523838487672241171,0.388620152510322781,0.298156764974678579];
                f_best = 32.6555929502463;
            case 20
                dim     = 24;
                num_g   = 6;
                num_h   = 14;
                lb      = zeros(1,dim)+1e-50;
                ub      = 10.*ones(1,dim);
                x_best  = [];
                f_best  = [];
            case 21
                dim     = 7;
                num_g   = 1;
                num_h   = 5;
                lb      = [0, 0, 0, 100, 6.3, 5.9, 4.5];
                ub      = [1000, 40,40,300,6.7,6.4,6.25];
                x_best  = [193.724510070034967, 5.56944131553368433e-27, ...
                    17.3191887294084914, 100.047897801386839, 6.68445185362377892,...
                    5.99168428444264833,6.21451648886070451];
                f_best  = 193.724510070035;
            case 22
                dim     = 22;
                num_g   = 1;
                num_h   = 19;
                lb      = zeros(1,dim);
                lb(8:12)   = 100; lb(8) = 100.01; lb(15) = 500; lb(16:17) = 0.01; lb(18:22) = -4.7;

                ub      = zeros(1,dim);
                ub(1)   = 2e4; ub(2:4) =1e6; ub(5:7) =4e7; ub(8) =299.99; ub(9) =399.99; ub(10) =300; ub(11) =400;
                ub(12)  = 600; ub(13:15) = 500;  ub(16) = 300; ub(17) = 400; ub(18:22) = 6.25;

                x_best  = [236.430975504001054, 135.82847151732463, 204.818152544824585, 6446.54654059436416,...
                    3007540.83940215595, 4074188.65771341929, 32918270.5028952882, 130.075408394314167,...
                    170.817294970528621, 299.924591605478554, 399.258113423595205, 330.817294971142758,...
                    184.51831230897065, 248.64670239647424, 127.658546694545862, 269.182627528746707,...
                    160.000016724090955, 5.29788288102680571, 5.13529735903945728, 5.59531526444068827,...
                    5.43444479314453499, 5.07517453535834395];
                f_best  = 236.430975504001;
            case 23
                dim     = 9;
                num_g   = 2;
                num_h   = 4;
                lb      = zeros(1,dim); lb(9) = 0.01;
                ub      = zeros(1,dim); ub([1 2 6])   = 300; ub([3 5 7])   = 100;  ub([4 8])   = 200;  ub(9)   = 0.03;


                x_best  = [0.00510000000000259465, 99.9947000000000514,...
                    9.01920162996045897e-18, 99.9999000000000535, 0.000100000000027086086,...
                    2.75700683389584542e-14, 99.9999999999999574, 200, 0.0100000100000100008];
                f_best  = -400.055099999999584;

            case 24
                dim=2;
                num_g=2;
                num_h=0;
                lb=[0,0];
                ub=[3,4];
                x_best=[2.32952019747762,3.17849307411774];
                f_best=-5.50801327159536;
            case 25 %IBEAM
                dim=4;
                num_g=2;
                num_h=0;
                lb=[10,10,0.9,0.9];
                ub=[80,50,5,5];
                x_best=[];
                f_best=0.0131;
            case 26 %HESSE
                dim=6;
                num_g=6;
                num_h=0;
                lb=[0,0,1,0,1,0];
                ub=[5,4,5,6,5,10];
                x_best=[];
                f_best=-310.00;
            case 27 %BR
                dim=2;
                num_g=1;
                num_h=0;
                lb=[-5,0];
                ub=[10,15];
                x_best=[];
                f_best=0.398;
            case 28 %SE
                dim=2;
                num_g=1;
                num_h=0;
                lb=[0,0];
                ub=[5,5];
                x_best=[];
                f_best=-1.174;
            case 29 %GO
                dim=2;
                num_g=1;
                num_h=0;
                lb=[-0.5,-1];
                ub=[0.5,0];
                x_best=[];
                f_best=-0.97;
            case 30 %TSD
                dim=3;
                num_g=4;
                num_h=0;
                lb=[0.05,0.25,2];
                ub=[2,1.3,15];
                x_best=[];
                f_best=0.0128;
            case 31 %WBD
                dim=4;
                num_g=7;
                num_h=0;
                lb=[0.1,0.1,0.1,0.1];
                ub=[2,10,10,2];
                x_best=[];
                f_best=1.8;
            case 32 %PVD
                dim=4;
                num_g=4;
                num_h=0;
                lb=[0.0625,0.0625,10,10];
                ub=[6.1875,6.1875,200,200];
                x_best=[];
                f_best=5885.33;
            case 33 %SRD
                dim=7;
                num_g=11;
                num_h=0;
                lb=[2.6,0.7,17,7.3,7.3,2.9,5];
                ub=[3.6,0.8,28,8.3,8.3,3.9,5.5];
                x_best=[];
                f_best=2994.42;
            case 34 % SCBD
                dim=10;
                num_g=11;
                num_h=0;
                lb=[2,35,2,35,2,35,2,35,2,35];
                ub=[3.5,60,3.5,60,3.5,60,3.5,60,3.5,60];
                x_best=[];
                f_best=65000;
        end
        %% WangHanDing
    case {'complexProblems','WangHanding'}
        switch fnum
            case 1 % Ackley
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=0;
                lb=-32.768*ones(1,dim);
                ub=32.768*ones(1,dim);
                x_best=zeros(1,dim);
                f_best=0;
            case 2 % Rastrigin
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=0;
                lb=-5.12*ones(1,dim);
                ub=5.12*ones(1,dim);
                x_best=zeros(1,dim);
                f_best=0;
            case 3 % Griewank
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=0;
                lb=-600*ones(1,dim);
                ub=600*ones(1,dim);
                x_best=zeros(1,dim);
                f_best=0;
            case 4 % Rosenbrock
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=0;
                lb=-2.048*ones(1,dim); % 2.048/5.12/32/30...maybe used
                ub=2.048*ones(1,dim);
                x_best=ones(1,dim);
                f_best=0;
            case 5 % Ellipsoid
                dim=10;
                if scalable, dim=dim_scalable; end
                num_g=0;
                num_h=0;
                lb=-5.12*ones(1,dim);% 5.12/100...maybe used
                ub=5.12*ones(1,dim);
                x_best=zeros(1,dim);
                f_best=0;
        end
        %% CEC2010
    case {'CEC2010','cec2010'}
        switch fnum
            case 1
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=2;
                num_h=0;
                lb=zeros(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 2
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=2;
                num_h=1;
                lb=-5.12*ones(1,dim);
                ub=5.12*ones(1,dim);
                x_best=[];
                f_best=[];
            case 3
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=0;
                num_h=1;
                lb=-1000*ones(1,dim);
                ub=1000*ones(1,dim);
                x_best=[];
                f_best=[];
            case 4
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=0;
                num_h=4;
                lb=-50*ones(1,dim);
                ub=50*ones(1,dim);
                x_best=[];
                f_best=[];
            case 5
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=0;
                num_h=2;
                lb=-600*ones(1,dim);
                ub=600*ones(1,dim);
                x_best=[];
                f_best=[];
            case 6
                dim=10;
                if scalable, dim=dim_scalable; end % below 30: 10,30
                num_g=0;
                num_h=2;
                lb=-600*ones(1,dim);
                ub=600*ones(1,dim);
                x_best=[];
                f_best=[];
            case 7
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=1;
                num_h=0;
                lb=-140*ones(1,dim);
                ub=140*ones(1,dim);
                x_best=[];
                f_best=[];
            case 8
                dim=10;
                if scalable, dim=dim_scalable; end % below 30: 10,30
                num_g=1;
                num_h=0;
                lb=-140*ones(1,dim);
                ub=140*ones(1,dim);
                x_best=[];
                f_best=[];
            case 9
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=0;
                num_h=1;
                lb=-500*ones(1,dim);
                ub=500*ones(1,dim);
                x_best=[];
                f_best=[];
            case 10
                dim=10;
                if scalable, dim=dim_scalable; end % below 30 {10,30}
                num_g=0;
                num_h=1;
                lb=-500*ones(1,dim);
                ub=500*ones(1,dim);
                x_best=[];
                f_best=[];
            case 11
                dim=10;
                if scalable, dim=dim_scalable; end % below 30 {10,30}
                num_g=0;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 12
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=1;
                num_h=1;
                lb=-1000*ones(1,dim);
                ub=1000*ones(1,dim);
                x_best=[];
                f_best=[];
            case 13
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=3;
                num_h=0;
                lb=-500*ones(1,dim);
                ub=500*ones(1,dim);
                x_best=[];
                f_best=[];
            case 14
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=3;
                num_h=0;
                lb=-1000*ones(1,dim);
                ub=1000*ones(1,dim);
                x_best=[];
                f_best=[];
            case 15
                dim=10;
                if scalable, dim=dim_scalable; end % below 30, {10,30}
                num_g=3;
                num_h=0;
                lb=-1000*ones(1,dim);
                ub=1000*ones(1,dim);
                x_best=[];
                f_best=[];
            case 16
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=2;
                num_h=2;
                lb=-10*ones(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 17
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=2;
                num_h=1;
                lb=-10*ones(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 18
                dim=10;
                if scalable, dim=dim_scalable; end % below 30
                num_g=1;
                num_h=1;
                lb=-50*ones(1,dim);
                ub=50*ones(1,dim);
                x_best=[];
                f_best=[];
        end
        %% CEC2017
    case {'CEC2017','cec2017'}
        switch fnum
            case 1
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 2
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=1;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 3
                dim=30;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 4
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=2;
                num_h=0;
                lb=-10*ones(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 5
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=2;
                num_h=0;
                lb=-10*ones(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 6
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=0;
                num_h=6;
                lb=-20*ones(1,dim);
                ub=20*ones(1,dim);
                x_best=[];
                f_best=[];
            case 7
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=0;
                num_h=2;
                lb=-50*ones(1,dim);
                ub=50*ones(1,dim);
                x_best=[];
                f_best=[];
            case 8
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 even
                num_g=0;
                num_h=2;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 9
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 even
                num_g=1;
                num_h=1;
                lb=-10*ones(1,dim);
                ub=10*ones(1,dim);
                x_best=[];
                f_best=[];
            case 10
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=0;
                num_h=2;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 11
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 12
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=2;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 13
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=3;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 14
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 15
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 16
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 17
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 18
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=2;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 19
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=2;
                num_h=0;
                lb=-50*ones(1,dim);
                ub=50*ones(1,dim);
                x_best=[];
                f_best=[];
            case 20
                dim=10;
                if scalable, dim=dim_scalable; end % below 100
                num_g=2;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 21
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=2;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 22
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=3;
                num_h=0;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 23
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 24
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 25
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 26
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=1;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 27
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=2;
                num_h=1;
                lb=-100*ones(1,dim);
                ub=100*ones(1,dim);
                x_best=[];
                f_best=[];
            case 28
                dim=10;
                if scalable, dim=dim_scalable; end % below 100 {10,30,50,100}
                num_g=2;
                num_h=0;
                lb=-50*ones(1,dim);
                ub=50*ones(1,dim);
                x_best=[];
                f_best=[];
        end
        %% CEC2020
    case {'CEC2020','cec2020'}
        addpath('./CEC2020/');
        Par     = Cal_par(fnum);
        dim     = Par.n;
        num_g   = Par.g;
        num_h   = Par.h;
        lb      = Par.xmin;
        ub      = Par.xmax;
        x_best  = [];
        f_best  = [];
        %% Example
    case {'ExampleProblem'}
        switch fnum
            case {1,'cons3_2D_Sasena_1'}
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=3;
                num_h=0;
                lb=-0*ones(1,dim);
                ub=1*ones(1,dim);
                x_best=[0.2017, 0.8332];
                f_best=-0.7483;
            case {2,'ATF1'}
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=1;
                num_h=0;
                lb=[-10,-5];
                ub=5*ones(1,dim);
                x_best=[];
                f_best=[];
            case {3,'ATF2'}
                dim=2;
                if scalable, dim=dim_scalable; end
                num_g=1;
                num_h=0;
                lb=[-10,-5];
                ub=5*ones(1,dim);
                x_best=[];
                f_best=[];
            case {5,'ShangFeng_1D_Cons_2'}
                dim=1;
                if scalable, dim=dim_scalable; end
                num_g=1;
                num_h=0;
                lb=-3;
                ub=3;
                x_best=[];
                f_best=[];
                
                
            otherwise
                error('No such example problem has been defined');
        end
    otherwise
        error('Undefined test suite');
end
