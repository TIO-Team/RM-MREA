close;clear;clc;
x=0:0.01:pi/2;
y1=cos(x');
y2=sin(x');
A=[x',y1];
B=[x',y2];
C=[A;B];
unique(C,'rows');
plot(x,y1,x,y2);
% hold on;
plot(C(:,1),C(:,2))
% hold off
patchForArbtData(A,B)