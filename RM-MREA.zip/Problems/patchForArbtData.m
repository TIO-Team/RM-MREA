function patchForArbtData(A,B)
% pachth the region surrounded by all points from A (and B)

% A     -  All points (or points from one of the parts partioned by the line)
% B     -  Points from one of the parts partioned by the line when the
% parameter is given

% note: the data should be given in the same range regarding x. The cusp is
% the closest points

% Considering the errors, Unique command cannot be employed

% fill or patch

if nargin==1 % all the points are given in disorder
    C=sortrows(A);
    node1=(C(1,:)+C(2,:))/2;
    node2=(C(end,:)+C(end-1,:))/2;
else
    [a,ia]=sort(A(:,1));
    [b,ib]=sort(B(:,1),'descend');
    x=[a;b];
    y=[A(ia,2);B(ib,2)];
    patch(x,y,[0.5,0.5,0.5],'FaceAlpha',0.5);
%     fill(x,y,[0.5,0.5,0.5],'FaceAlpha',0.5);
    
end

