%  Test functions
%% CEC2006
problems  = [1, 2, 4, 6, 7, 8, 9, 10, 12, 16, 18, 19, 24];  % GloSADE
problems1 = [3 5 11 13 14 15 17 21 23];                     % NSADE-E
problems2 = [4 6 8 9 12 24];                                % NSADE-IE
problems  = sort([problems1, problems2]);                   % NSADE-ALL
problems  = [1, 2, 4, 6, 7, 8, 9, 10, 12, 16, 18, 19, 24];  % SACCDE
problems  = [1, 2, 4, 6, 7, 8, 9, 10, 12, 16, 18, 19, 24];  % MPMLS

% problems classification
problems_All = 1:24;
problems_IE  = [1, 2, 4, 6, 7, 8, 9, 10, 12, 16, 18, 19, 24];
 % G20: No feasible solution is found and 6IE + 14E; 
 % G22: 19 equality constraints and 1 inequality constraint
problems_E          = setdiff(problems_All,problems_IE);
problems_E_test     = setdiff(problems_E,[20 22]);

% Testable
problems_All = 1:24;
a = setdiff(problems_All,problems);
b = setdiff(a,problems)

%% CEC2010
problems = [1, 7, 8, 13, 14, 15];                           % GloSADE 10D, 30D
problems = [1, 7, 8, 13, 15];                               % SACCDE  30D
problems = [1, 7, 8, 13, 14, 15];                           % MPMLS 10D, 30D

% Testable
problems_All = 1:18; %
problems_E   = [2, 3, 4, 5, 6, 9, 10, 11, 12, 16, 17, 18];

%% CEC2017
problems = [1, 2, 4, 5, 13, 19, 20, 22, 28];                % GloSADE 10D, 30D
problems = [1, 2, 4, 5, 13, 20, 28];                        % SACCDE  30D
problems = [1, 2, 4, 5, 13, 19, 20, 22, 28];                % MPMLS 10D, 30D 不包含C12/C21/

%% CEC2020
