clear; close; clc;

addpath(genpath('.'));
suite   = @ExampleProblem; % ExampleProblem CEC2006
fnum    = 5; %fnum = [3 5 11 13 14 15 17 21 23  ] hard: 8, 13
Dim     = 0;

[Dim,num_g,num_h,upperB,lowerB,x_best,f_best,problem]   =  get_ProblemInfo(fnum,Dim,suite);
CVType          = 2;
toleranceG      = 0e-50;
toleranceH      = 1e-4;
maxFEs          = 100;%50*Dim;50*Dim;%max(50*Dim,1000);% ===========================================================
num_initSample  = 10; % 50;5*Dim;%5*Dim;%5*Dim;%5*Dim;%min(maxFEs/5,max(5*Dim,100)); % ===========================================================

FEs             = num_initSample;
init_samplePlan = 'lhs';
kernel          = 'tpSpline'; % cubic; tpSpline; gaussian1; gaussian2;


DoEX                        =   initialize_pop(num_initSample,Dim,lowerB,upperB,init_samplePlan);
[objVal,consGVal,consHVal]  =   problem(DoEX,fnum);
[consGVal,consHVal]         =   corrConVal(consGVal,consHVal,num_g,num_h);
DoEY                        =   [objVal,consGVal,consHVal];

% Show Plot
close all;
[fig,p]=showExample(fnum,1,suite);
close;
legend off;

% Samples
% Dmodel
Model     = RBFCreate(DoEX, DoEY, kernel,lowerB,upperB);
xTest       = (lowerB:0.1:upperB)';
y_hat       = RBFInterp(xTest, Model);

hold on;
plot(xTest,y_hat(:,1),'--m','LineWidth',2)
plot(xTest,y_hat(:,2),'--g','LineWidth',2)

