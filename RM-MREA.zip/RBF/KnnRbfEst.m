function [sigma2] = KnnRbfEst(x, DataBase)
DB.x = DataBase.x(1:DataBase.l, :);
DB.y = DataBase.y(1:DataBase.l, :);
DB.c = DataBase.c(1:DataBase.l);
DB.l = DataBase.l;
K = 100;
sigma2 = zeros(size(x, 1), 1);
[ind, ~] = knnsearch(DB.x, x, 'k', K);
for i = 1:size(x, 1)
   index = ind(i, :);
   para = RBFCreate(DB.x(index, :), DB.y(index, :), 'cubic');
   [sigma2(i)] = RBFInterpWithError(x(i, :), para);
end
end