function para = RBFCreate(ax, ay, kernel,xmin,xmax)
[N, D] = size(ax);
% % Normlization
if nargin == 3
    xmin = min(ax, [], 1);
    xmax = max(ax, [], 1);
end
ymin = min(ay, [], 1);
ymax = max(ay, [], 1);
% ax = 2./(repmat(xmax - xmin, N, 1)) .* (ax - repmat(xmin, N, 1)) - 1;
% ay = 2./(repmat(ymax - ymin, N, 1)) .* (ay - repmat(ymin, N, 1)) - 1;

for i = 1 : length(xmin)
   if xmin(i) ~= xmax(i)
       
       ax(:, i) = 2 ./ (repmat(xmax(i) - xmin(i), N, 1)) .* (ax(:, i) - repmat(xmin(i), N, 1)) - 1;
   end
end

for i = 1 : length(ymin)
   if ymin(i) ~= ymax(i)
       ay(:, i) = 2./(repmat(ymax(i) - ymin(i), N, 1)) .* (ay(:, i) - repmat(ymin(i), N, 1)) - 1;
   end
end

r = dist(ax, ax');
switch kernel
    case 'gaussian1'
        Phi = radbas(sqrt(-log(.5))*r);
    case 'gaussian2'
        sigmas  = mean(mean(r,2));
        betas   = 1 ./ (2 .* sigmas .^ 2);
        Phi = exp((-r.^2).*betas);


%         sigmas  = mean(r,2);
%         betas   = 1 ./ (2 .* sigmas .^ 2);
%         betas2  = betas*ones(1,N);
%         Phi = exp((-r.^2).*betas2);

    case 'cubic'
        Phi = r.^3;
    case 'tpSpline'
        r(r == 0) = 1e-10;
        Phi = (r.^2).*log(r);
end
P = [ones(N, 1), ax];
A = [Phi, P; P' zeros(D + 1, D + 1)];
b = [ay; zeros(D + 1, size(ay, 2))];


% theta = A \ b;
theta = pinv(A)*b;

para.alpha = theta(1 : N, :); % coefficient before phi(x)
para.beta = theta(N + 1 : end, :); % coefficient in linear polynomial

para.xmin = xmin;
para.xmax = xmax;
para.ymin = ymin;
para.ymax = ymax;
para.nodes = ax;    % normlization
para.kernel = kernel;
para.Phi = Phi;
if strcmp(kernel, 'gaussian2')
    para.betas = betas;
end
end