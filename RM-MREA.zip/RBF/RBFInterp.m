function y = RBFInterp(x, para)
ax = para.nodes;
nx = size(x, 1);
np = size(ax, 1);    % np: the size of data set

xmin = para.xmin;
xmax = para.xmax;
ymin = para.ymin;
ymax = para.ymax;
% normalization
% x = 2./(repmat(xmax - xmin, nx, 1)) .* (x - repmat(xmin, nx, 1)) - 1;
for i = 1 : length(xmin)
   if xmin(i) ~= xmax(i)
       x(:, i) = 2 ./ (repmat(xmax(i) - xmin(i), nx, 1)) .* (x(:, i) - repmat(xmin(i), nx, 1)) - 1;
   end
end

r = dist(x, ax');
switch para.kernel
    case 'gaussian1'
        Phi = radbas(sqrt(-log(.5))*r);
    case 'gaussian2'
        betas  = para.betas;

        Phi = exp((-r.^2).*betas);

        % sigmas  = mean(r,2);
        % betas   = 1 ./ (2 .* sigmas .^ 2);
        % betas2  = betas*ones(1,N);
%         betas2  = para.betas2;
%         betas22 = betas2';
%         bests22Row = betas22(1,:);
%         bests2EachPoint = ones(nx, 1)*bests22Row;
% 
%         Phi = exp((-r.^2).*bests2EachPoint);

    case 'cubic'
        Phi = r.^3;
    case 'tpSpline'
        r(r == 0) = 1e-10;
        Phi = (r.^2).*log(r);
end

y = Phi * para.alpha + [ones(nx, 1), x] * para.beta;
% renormalization
% y = repmat(ymax - ymin, nx, 1)./2 .* (y + 1) + repmat(ymin, nx, 1);
for i = 1 : length(ymin)
   if ymin(i) ~= ymax(i)
       y(:, i) = repmat(ymax(i) - ymin(i), nx, 1)./2 .* (y(:, i) + 1) + repmat(ymin(i), nx, 1);
   end
end
end