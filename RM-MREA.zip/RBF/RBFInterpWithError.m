function [sigma2] = RBFInterpWithError(x, para)
ax = para.nodes;
nx = size(x, 1);
np = size(ax, 1);    % np: the size of data set

xmin = para.xmin;
xmax = para.xmax;
ymin = para.ymin;
ymax = para.ymax;
% normalization
x = 2./(repmat(xmax - xmin, nx, 1)) .* (x - repmat(xmin, nx, 1)) - 1;

% r = sqrt(abs(repmat(diag(ax * ax')', nx, 1) + repmat(diag(x * x'), 1, np) - 2 * (x * ax')));
r = dist(x, ax');
switch para.kernel
    case 'gaussian'
        Phi = radbas(sqrt(-log(.5))*r);
    case 'cubic'
        Phi = r.^3;
end

switch para.kernel
    case 'gaussian'
        sigma2 = 1 / sqrt(2 * pi) - Phi*(para.Phi\(Phi'));
    case 'cubic'
        sigma2 =  - Phi*(para.Phi\(Phi'));
end
sigma2 = abs(diag(sigma2));

end