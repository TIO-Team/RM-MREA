function [DATA,UpdateDATA,bestObjCVCurrent,feasibilityCurrent,timeConsumed] = RM_MREA(suite,fnum,Dim,num_initSample,maxFEs,toleranceG,toleranceH,CVType)
warning off;
rng("shuffle");

%% Promblem set
[Dim,num_g,num_h,upperB,lowerB,x_best,f_best,problem]=get_ProblemInfo(fnum,Dim,suite);

FEs             = num_initSample;
init_samplePlan = 'lhs';
kernel          = 'cubic';

%% Initialize 数据的存储，fbest需要index记录和val记录，原始DATA包含x,normx,y(obj),CVval，CVsum，CVmax，normDist
DATA.x                      =   inf(maxFEs,Dim);
DATA.normx                  =   DATA.x;
DATA.y                      =   inf(maxFEs,num_g+num_h+1);
UpdateDATA.bestSitesLog     =   inf(maxFEs-num_initSample+1,Dim);
UpdateDATA.bestValLog       =   inf(maxFEs-num_initSample+1,2);
DATA.CVsum                  =   inf(maxFEs,1);
DATA.CVGH                   =   inf(maxFEs,num_g+num_h);
% DATA.Models                 =   cell(maxFEs,2);
DATA.CVmax                  =   inf(maxFEs,1);
DATA.normDist               =   inf(maxFEs,1);
%做实验，拉丁之后problem取obj,cv
DoEX                        =   initialize_pop(num_initSample,Dim,lowerB,upperB,init_samplePlan);
[objVal,consGVal,consHVal]  =   problem(DoEX,fnum);
[consGVal,consHVal]         =   corrConVal(consGVal,consHVal,num_g,num_h);
DoEY                        =   [objVal,consGVal,consHVal];

[bestIndCurrent, bestObjCVCurrent,bestIndRowCurrent,feasibilityCurrent,CV,minCVCurrent] = findBest(DoEX,objVal,consGVal,consHVal,toleranceG,toleranceH,CVType);

% 记录初始样本的最优解
bestPointer                   =   1;
CVGH                          =   calMaxCV(DoEY(:,2:end),num_g,num_h,toleranceG, toleranceH);
DATA.x(1:num_initSample,:)    =   DoEX;
DATA.y(1:num_initSample,:)    =   DoEY;
UpdateDATA.bestSitesLog(1,:)  =   bestIndCurrent;
UpdateDATA.bestValLog(1,:)    =   [bestObjCVCurrent,feasibilityCurrent];
DATA.CVGH(1:num_initSample,:) =   CVGH;
DATA.CVsum(1:FEs,:)           =   sum(CVGH,2);
DATA.CVmax(1:FEs,:)           =   max(CVGH,[],2);
DATA.normx(1:FEs,:)           =   normalizeVar(DoEX,lowerB,upperB);
Dist                          =   pdist2(DATA.normx(1:FEs,:),DATA.normx(1:FEs,:),'euclidean','Smallest',2)';
DATA.normDist(1:FEs,:)        =   Dist(:,2);


%% Algorithm Parameter Set


SelectMethodForCV   =   6;

% DE: initialization
isInitial           =   true;
isInitialCons       =   true;
NP                  =   num_initSample;
F                   =   0.2:0.2:1;
CR                  =   0.4:0.2:1;

%DE: Environmental selection
feasibilityRule     =   false;
EnvSelNearest       =   false;
DX2EnvSelType       =   2;
NMinBetterObj       =   floor(0.5*NP);
DATAInfill          =   cell(6,2);
MaxCV2Log           =   [];
MaxDY2Log           =   [];
AddRandomness       =   [];
ClusterCriterion    =   1;

% DE: Prescreen· RM-F
NPMax                      =30 ;%%%%%%%%%%%%%%%%%%%%TODO 200
Block1                          =1;%1:relation;0:rbf(ori)
Block2                          =1;%1:relation;0:rbf(ori)
Block3                          =2;%2:relation;1:rbf 0:ori
rewardunfeasible                = false;
ImproveStrategy                 =1;
ModelFeasibleRatio_Feasible     = 0.5;
ModelBetterRatio_Better         = 0.5;
ModelBetterRatio_Cons           = 0.5;
MixedBetterRatio                = 0.5;
FeasibleUncertainParent         = 1;
UnconstrainOptParent            = 2;
NPresceen                       = 500;
TypeNOFF                        = 2;
ExploreUncertainRatio           = 0.3;
w1                              = 0;
w2                              = 0.2;
w3                              = 0.2;
w4                              = 1-w1-w2-w3;
NMinExploreUncertain            = 0;
pBestRatio                      = 0.1;
consInfill                      = 1;

% Local search
algorithmLocalSearch    = 'sqp';
maxFEsLocal             =  300;
Knearest                = max(min(5*Dim,100),5);
minLocalRange           = 2e-10;
TypeLocalOffspring      = [1 4 6];
NTransferRatioMax       = 0.5;
TransferDATASource      = 2;
BetterRatio             = 0.5;
RewardSearch            = true;

% Adaptive local region
ExtendLocalRegion   =   true;
BoundaryTolerance   =   1e-5;
BoundaryTolerRatio  =   0.1;
NExtendLimit        =   1;
NBoundaryPoints     =   0;
NExtendLocalRegion  =   0;
ExtendRatio         =   0.5;
BestOnTheBoundary   =   true;

%% Optimize
tic;
while FEs < maxFEs
    DX  = DATA.x(1:FEs,:);
    DY  = DATA.y(1:FEs,:);
    %% Determine the initial populations
    if FEs <= NP
        DX1     = DX; % Global Exploration population
        DY1     = DY;
        CV1     = DATA.CVsum(1:FEs,:);
        DX1norm = DATA.normx(1:FEs,:);
        DX2     = DX; % Global constrained population
        DY2     = DY;
        CV2     = DATA.CVsum(1:FEs,:);
        DX2norm = DATA.normx(1:FEs,:);

        Archive1.x     = DX1;
        Archive1.y     = DY1;
        Archive1.normx = DX1norm; % Diversity archive
        Archive1.CVsum = CV1;
        Dist           = pdist2(DATA.normx(1:FEs,:),Archive1.normx,'euclidean','Smallest',2)';
        Archive1.dist  = Dist(:,2);
    elseif isInitial
        [~,Rank1] = sort(DY(:,1));% Global Exploration population
        DX1       = DX(Rank1(1:NP),:);
        DY1       = DY(Rank1(1:NP),:);
        CV1       = DATA.CVsum(Rank1(1:NP),:);
        DX1norm   = DATA.normx(Rank1(1:NP),:);
        [~,Rank2] = sortrows([DATA.CVsum,DY(:,1)]);% Global constrained population
        DX2       = DX(Rank2(1:NP),:);
        DY2       = DY(Rank2(1:NP),:);
        CV2       = DATA.CVsum(Rank2(1:NP),:);
        DX2norm   = DATA.normx(Rank2(1:NP),:);

        Archive1.x     = DX1;
        Archive1.y     = DY1;
        Archive1.normx = DX1norm; % Diversity archive
        Archive1.CVsum = CV1;
        Dist           = pdist2(DATA.normx(1:FEs,:),Archive1.normx,'euclidean','Smallest',2)';
        Archive1.dist  = Dist(:,2);
    end
    isInitial = false;

    %% Explore
    % ====================================================================
    DATA_ADD            = [];
    CVs_ADD             = [];
    norm_xs_ADD         = [];
    NP = min(5*Dim,NPMax);
    NGlobalMax = NP *2;
    % Determine the resource allocation:
    % 1: The most uncertain points in the entire search space
    NP01 = max(NMinExploreUncertain,floor(NP*w1));
    % 2: The most uncertain points in the feasible region
    NP02 = max(NMinExploreUncertain,floor(NP*w2));
    % 3: Better objective Explore
    if w4 ~=0
        NP03 = max(NMinExploreUncertain,floor(NP*w3));
    else
        NP03 = NP - NP01 - NP02;
    end
    % 4: Constrained optimization
    NP04 = NP - NP01 - NP02 - NP03;

    %     if feasibilityCurrent
    %         if sum(DATA.y(:,1) < bestObjCVCurrent) < NP
    %             NP01 = 0; NP02=0; NP03 = NP; NP04 = 0;
    %         end
    %     end
    % =====================================================================
    for ii = 1:NP
        if ii<=NP01 %NP01=0，故不会执行，explore全部最uncertain
            ExploreType = 1;
        elseif ii<= NP01+NP02
            ExploreType = 2;
        elseif ii<= NP01+NP02+NP03
            ExploreType = 3;
        elseif ii<= NP01+NP02+NP03+NP04
            ExploreType = 4;
        end
        %% 选择种群POPx
        switch ExploreType
            case 1
                % 1: Explore the most uncertain points in the entire search space
                [DistSort, RankDist] = sort(DATA.normDist(1:FEs,:),'descend');
                POPx                 = DATA.x(RankDist(1:NP),:);
                TypeOffspring        = [1,3,4];
                xBest                = [];
                xTopPBest            = [];
            case 2
                % 2: Explore the most uncertain points in the feasible search space
                if FeasibleUncertainParent == 1
                    CVLimit     = 0;
                    Feasible    = DATA.CVsum(1:FEs,:) <= CVLimit;
                    NFeasible   = sum(Feasible);
                    if NFeasible > NP
                        [DistSort, RankDist] = sort(DATA.normDist(Feasible,:),'descend');
                        RowFeasible          = find(Feasible);
                        POPx                 = DATA.x(RowFeasible(RankDist(1:NP)),:);
                        TypeOffspring        = [1,3,4];
                        xBest           = POPx(1,:);
                         xTopPBest       = POPx(1:ceil(NP*pBestRatio),:);
                    else
                        [~, RankCVs]    = sortrows([DATA.CVsum(1:FEs,:),DATA.y(1:FEs,1)],[1,2]);
                        POPx            = DATA.x(RankCVs(1:NP),:);
                        TypeOffspring   = [1,4,6];
                        xBest           = POPx(1,:);
                        xTopPBest       = POPx(1:ceil(NP*pBestRatio),:);
                    end
                else
                    % Extend the exploring feasible space: [TODO]!!!!
                    % maximize Dist and restricted by relaxed CV
                    CVLimit     = 10;
                    Feasible    = DATA.CVsum(1:FEs,:) <= CVLimit;
                    Infeasible  = ~Feasible;
                    NFeasible   = sum(Feasible);
                    NInfeasible = FEs - NFeasible;
                    TypeOffspring        = [1,2,3];
                end
            case 3

                if UnconstrainOptParent == 1
                    POPx                 = DX1;
                    POPy                 = DY1;
                    TypeOffspring        = [1,2,3];
                    if any(TypeOffspring == 5)
                        [~,RankObj] = sort(POPy(:,1));
                        POPx        = POPx(RankObj,:);
                        POPy        = POPy(RankObj,:);
                    end
                else
                    % Restricted by best feasible objective value
                    if feasibilityCurrent
                        ObjLimit    = bestObjCVCurrent;
                        IDBetterObj = DATA.y(1:FEs,1) < bestObjCVCurrent;
                        NBetterObj  = sum(IDBetterObj);
                        if NBetterObj > NP
                            [DistSort, RankDist] = sort(DATA.normDist(IDBetterObj,:),'descend');
                            RowBetterObj         = find(IDBetterObj);
                            POPx                 = DATA.x(RowBetterObj(RankDist(1:NP)),:);
                            TypeOffspring        = [1,3,4];
                        else
                            % [TODO]
                            % 3: Unconstrained optimization ---- Selected
                            [~, RankObj]    = sort(DATA.y(1:FEs,1));
                            POPx            = DATA.x(RankObj(1:NP),:);
                            TypeOffspring   = [1,4,6];
                            xBest           = POPx(1,:);
                            xTopPBest       = POPx(1:ceil(NP*pBestRatio),:);
                        end
                    else
                        ObjLimit    = inf;
                        % [TODO]
                        % 1: Feasible Uncertainty
                        % 2: Contrained optimization
                        % 3: Unconstrained optimization ---- Selected
                        [~, RankObj]    = sort(DATA.y(1:FEs,1));
                        POPx            = DATA.x(RankObj(1:NP),:);
                        TypeOffspring   = [1,4,6];
                        xBest           = POPx(1,:);
                        xTopPBest       = POPx(1:ceil(NP*pBestRatio),:);
                    end
                end
            case 4
                % 4: Explore by Global Constrained optimization
                % To Improve
                if feasibilityCurrent
                    IDBetterObj   = DATA.y(1:FEs,1) < bestObjCVCurrent;
                    IDWorseObj    = ~IDBetterObj;
                    NBetterObj    = sum(IDBetterObj);
                    NWorseObj     = sum(IDWorseObj);
                    RowBetter     = find(IDBetterObj);
                    RowWorse      = find(IDWorseObj);
                    [~,RankBetter]   = sort(DATA.CVsum(RowBetter,1));
                    [~,RankWorse]    = sort(DATA.y(RowWorse,1));

                    % Feasible Solutions (Modified Feasibility Rule)
                    % [~,RankCVObj]   = sortrows([CV2,DY2(:,1)],[1,2]);
                    if NWorseObj >= NP
                        RowF        = RowWorse(RankWorse(1:NP));
                    else
                        NRemain     = NP - NWorseObj;
                        RowF1       = RowWorse(RankWorse);
                        RowF2       = RowBetter(RankBetter(1:NRemain));
                        RowF        = [RowF1;RowF2];
                    end
                    POPx_F = DATA.x(RowF,:);
                    POPy_F = DATA.y(RowF,:);

                    %只是为了求xBest
                    xBest_F         = POPx_F(1,:);%最优可行解
                    xTopPBest_F     = POPx_F(1:ceil(NP*pBestRatio),:);

                    % Better Solutions
                    if NBetterObj > NP%onlyfitness
                        POPx_B          = DATA.x(RowBetter(RankBetter(1:NP)),:);
                        POPy_B          = DATA.y(RowBetter(RankBetter(1:NP)),:);
                        %只是为了求xBest
                        xBest_B         = POPx_B(1,:);
                        xTopPBest_B     = POPx_B(1:ceil(NP*pBestRatio),:);
                    elseif NBetterObj > 0 %FR
                        POPx_B          = DATA.x(IDBetterObj,:);
                        POPy_B          = DATA.y(IDBetterObj,:);
                        CV_B            = DATA.CVsum(IDBetterObj,:);
                        [~,RankCVObj]   = sortrows([CV_B,POPy_B(:,1)],[1,2]);
                        POPx_B          = POPx_B(RankCVObj,:);
                        POPy_B          = POPy_B(RankCVObj,:);
                        %只是为了求xBest
                        xBest_B         = POPx_B(1,:);
                        xTopPBest_B     = POPx_B(1:min(ceil(NP*pBestRatio),NBetterObj),:);
                    else
                        POPx_B          = [];
                        POPy_B          = [];
                        %只是为了求xBest
                        xBest_B         = [];
                        xTopPBest_B     = [];
                    end

                    % Mixed Solutions:
                    NBetterInM = min(NBetterObj, ceil(NP * MixedBetterRatio));
                    NWorseInM  = min(NWorseObj,NP-NBetterInM);
                    NBetterInM = NP-NWorseInM;

                    % Original
                    Feasible    = DATA.CVsum(1:FEs,:) <= 0;
                    Infeasible  = ~Feasible;
                    NFeasible   = sum(Feasible);
                    NInfeasible = FEs - NFeasible;        
                    RowFeasible = find(Feasible);
                    RowInfeasible = find(Infeasible);
                    if NFeasible > NP
                        [~,RankFR] = sort(DATA.y(RowFeasible,1));
                        Row_M = RowFeasible(RankFR(1:NP));
                    elseif  NFeasible > 0
                        [~,RankFR] = sort(DATA.CVsum(RowInfeasible,1));
                        NRemain = NP-NFeasible;
                        Row_M = [RowFeasible;RowInfeasible(RankFR(1:NRemain))];
                    end
                    

                    POPx_M          = DATA.x(Row_M,:);
                    POPy_M          = DATA.y(Row_M,:);
                    CV_M            = DATA.CVsum(Row_M,:);
                    if NBetterObj > 0
                        xBest_M         = [xBest_F; xBest_B];
                        xTopPBest_M     = [xTopPBest_F; xTopPBest_B];
                    else
                        xBest_M         = xBest_F;
                        xTopPBest_M     = xTopPBest_F;
                    end
                    % Save
                    POPx        = {POPx_M,POPx_M,POPx_M};
                    POPy        = {POPy_M,POPy_M,POPy_M};
                    xBest       = {xBest_M,xBest_M,xBest_M};
                    xTopPBest   = {xTopPBest_M,xTopPBest_M,xTopPBest_M};
                    TypeOffspring        = [1,4,6];
                else
                    ObjLimit        = inf;

                    [~,RankCV]      = sort(DATA.CVsum(1:FEs,:));
                    POPx            = DATA.x(RankCV(1:NP),:);
                    POPy            = DATA.y(RankCV(1:NP),:);
     
                    TypeOffspring   = [1,4,6];
                    xBest           = POPx(1,:);
                    xTopPBest       = POPx(1:ceil(NP*pBestRatio),:);
                end
        end
        %% ======== Global: Generate Offspring as candidates================
        %生成子代
        if iscell(POPx)
            kk = 3;
            TypeOffspring = [1,4,6];
            OFFxii = generateOFF(POPx{kk},NPresceen,F,CR,TypeOffspring,TypeNOFF,{xBest{kk},xTopPBest{kk}});
        else
            OFFxii = generateOFF(POPx,NPresceen,F,CR,TypeOffspring,TypeNOFF,{xBest,xTopPBest});
        end
        OFFxii = Repair(OFFxii,lowerB,upperB);
        %% ======== Global: Prescreen individual for expensive evaluation=== relation model
        % 选训练对象来建模，然后进行pre评估，选择需要expensive evaluation的解
        switch ExploreType
            case 1
                % 1: Explore the most uncertain points in the entire search space
                xCandidate     = OFFxii;
                yCandidate     = [];
                xCandidateNorm = normalizeVar(xCandidate,lowerB,upperB);
                distCandidate  = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1);
                [maxDistNorm,IDSelect] =max(distCandidate);
                InfillMethod           = 'Global_Uncertain';
                
            case 2 %% 可行稀疏
                if Block1
                    % 2: Explore the most uncertain points in the feasible search space
                    % maximum sparsity is selected ,If no offspring is predicted to be feasible, minimum predicted CV is chosen instead
                    InfillMethod       = 'Global_FeasibleUncertain';
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                        usetype     = 1; 
                    else
                        IDTrain             = zeros(NGlobalMax,1);
                        NFeasibleTrainMax   = 0.5*NGlobalMax;
                        NInfeasibleTrainMax = NGlobalMax - NFeasibleTrainMax;
                        Feasible            = DATA.CVsum(1:FEs,:)<=0;
                        NFeasible           = sum(Feasible);
                        NInfeasible         = FEs - NFeasible;
                        if NFeasible <= NFeasibleTrainMax
                            [~,RankCVs] = sort(DATA.CVsum(1:FEs,:));

                            % IDTrain(1:NFeasibleTrainMax)     = RankCVs(1:NFeasibleTrainMax);
                            % [cv_, RankCV]   = sort(DATA.CVsum(1:FEs,1),'descend');
                            % IDTrain(NFeasibleTrainMax+1:end) = RankCV(1:NInfeasibleTrainMax);
                            IDTrain     = RankCVs(1:NGlobalMax);
                            IDTrain     = unique(IDTrain,'stable');
                            usetype     = 1; 
                        elseif NInfeasible <= NInfeasibleTrainMax
                            IDTrain(1:NInfeasible) = find(~Feasible);
                            % The most sparse points left are added into Training
                            NRemain         = NGlobalMax - NInfeasible;
                            RowRemain       = find(Feasible);
                            [~, RankDist]   = sort(DATA.normDist(RowRemain,:),'descend');
                            IDTrain(end-NRemain+1:end) = RowRemain(RankDist(1:NRemain));

                            IDTrain = unique(IDTrain,'stable');
                            usetype = 2;

                        else
                            Row1            = find(Feasible);
                            [~, RankDist]   = sort(DATA.normDist(Row1,:),'descend');
                            IDTrain(1:NFeasibleTrainMax) = Row1(RankDist(1:NFeasibleTrainMax));
                            Row2            = find(~Feasible);
                            % [~, RankDist]   = sort(DATA.normDist(Row2,:),'descend');
                            % IDTrain(NFeasibleTrainMax+1:end) = Row2(RankDist(1:NInfeasibleTrainMax));
                            [cv_, RankCV]   = sort(DATA.CVsum(Row2,1),'descend');
                            IDTrain(NFeasibleTrainMax+1:end) = Row2(RankCV(1:NInfeasibleTrainMax));
                            IDTrain = unique(IDTrain,'stable');
                            usetype = 2;
                            
                        end
                    end
                    %% 使用relation model，完成data preparation，model training

                    % data preparation
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);%选取了用来构建模型的解
                    xTraindist=[];
                    [Xs,Ys] = FitnessCriteriaGenerator_withoutDist(xTrain,yTrain,DATA.CVsum(IDTrain,1),ExploreType,xTraindist);
                    
                    % model training

                    % surrogate     = Trainer_CNN(Xs,Ys);
                    % 使用SVM替换CNN模型
                    SVMModel = fitcecoc(Xs, Ys, ...
                        'Learners', templateSVM('KernelFunction', 'rbf', 'Standardize', true), ...
                        'Coding', 'onevsone'); % 或者 'onevsall'，根据需求选择编码方式
                    surrogate = SVMModel;

                    %% predict offspring quality
                    % [candidateIndex,scores]=FitnessCriteriaUser(surrogate,OFFxii,xTrain);
                    % catalog=DATA.CVsum(IDTrain,1)<=0;
                    [candidateIndex,scores]=SVMUser(surrogate,OFFxii,xTrain,usetype);

                    %% Select points for evaluation
                    xCandidate      = OFFxii(candidateIndex,:);%TODO
                    IDSelect = 1:size(candidateIndex,1);
                    xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                    distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                    [maxDistNorm,IDSelect]   = max(distCandidate);
                        
               

                    % IDCandidate = CV_hat <= 0;
                    % if sum(IDCandidate) == 0%没可行解
                    %     [~,RankCV_hat]  = sort(CV_hat);
                    %     NRelax          = ceil(size(IDCandidate,1)*0.1);
                    %     IDCandidate(RankCV_hat(1:NRelax)) = true;
                    % end
                    % xCandidate      = OFFxii(IDCandidate,:);
                    % yCandidate      = y_hat(IDCandidate,:);%根本用不到，不用管
                    % CVCandidate     = CV_hat(IDCandidate,:);%用不到
                    % xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                    % distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                    % [maxDistNorm,IDSelect]   = max(distCandidate);
                else
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                    else
                        IDTrain             = zeros(NGlobalMax,1);
                        NFeasibleTrainMax   = ceil(NGlobalMax*ModelFeasibleRatio_Feasible);
                        NInfeasibleTrainMax = NGlobalMax - NFeasibleTrainMax;
                        Feasible            = DATA.CVsum(1:FEs,:) <= 0;
                        NFeasible           = sum(Feasible);
                        NInfeasible         = FEs - NFeasible;
                        if NFeasible == 0
                            [~, RankCVs]               = sort(DATA.CVsum(1:FEs,:));
                            IDTrain(1:NGlobalMax)      = RankCVs(1:NGlobalMax);
                            IDTrain     = unique(IDTrain,'stable');

                        elseif NFeasible <= NFeasibleTrainMax
                            [~, RankCVs]                      = sort(DATA.CVsum(1:FEs,:));
                            IDTrain(1:NFeasibleTrainMax)      = RankCVs(1:NFeasibleTrainMax);

                            % The most sparse points left are added into Training
                            % set: NInfeasible is larger than needed
                            NRemain       = NGlobalMax - NFeasibleTrainMax;
                            IDCandidate   = true(FEs,1);
                            IDCandidate(IDTrain(1:NFeasibleTrainMax)) = false;
                            RowRemain     = find(IDCandidate);
                            [~, RankDist]   = sort(DATA.normDist(RowRemain,:),'descend');
                            IDTrain(end-NRemain+1:end) = RowRemain(RankDist(1:NRemain));

                            IDTrain       = unique(IDTrain,'stable');
                        elseif NInfeasible <= NInfeasibleTrainMax
                            IDTrain(1:NInfeasible) = find(~Feasible);
                            % The most sparse points left are added into Training
                            % set: NFeasible is larger than needed
                            NRemain         = NGlobalMax - NInfeasible;
                            RowRemain       = find(Feasible);
                            [~, RankDist]   = sort(DATA.normDist(RowRemain,:),'descend');
                            IDTrain(end-NRemain+1:end) = RowRemain(RankDist(1:NRemain));

                            IDTrain = unique(IDTrain,'stable');
                        else
                            Row1            = find(Feasible);
                            [~, RankDist]   = sort(DATA.normDist(Row1,:),'descend');
                            IDTrain(1:NFeasibleTrainMax) = Row1(RankDist(1:NFeasibleTrainMax));
                            Row2            = find(~Feasible);
                            [~, RankDist]   = sort(DATA.normDist(Row2,:),'descend');
                            IDTrain(NFeasibleTrainMax+1:end) = Row2(RankDist(1:NInfeasibleTrainMax));

                            IDTrain = unique(IDTrain,'stable');
                        end
                    end

                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);

                    % model training
                    modelii     = RBFCreate(xTrain, yTrain, kernel,lowerB,upperB);
                    InfillMethod       = 'Global_FeasibleUncertain';

                    % Predict the values of the Offspring
                    [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                        = predictCal(OFFxii,modelii,num_g,num_h,toleranceG,toleranceH,CVType);
                    % Select points for evaluation
                    IDCandidate = CV_hat <= 0;
                    if sum(IDCandidate) == 0
                        % Type 1
                        [~,RankCV_hat]  = sort(CV_hat);
                        NRelax          = ceil(size(IDCandidate,1)*0.1);
                        IDCandidate(RankCV_hat(1:NRelax)) = true;
                        % Type 2
                        %                     IDCandidate = true(size(IDCandidate));
                        % Type 3
                        %                     [~,IDminCV_hat] = min(CV_hat);
                        %                     IDCandidate(IDminCV_hat) = true;
                    end
                    xCandidate      = OFFxii(IDCandidate,:);
                    yCandidate      = y_hat(IDCandidate,:);
                    CVCandidate     = CV_hat(IDCandidate,:);
                    xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                    distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                    [maxDistNorm,IDSelect]   = max(distCandidate);
                end



            case 3
                if Block2
                    % 3: Explore the most uncertain points in the better-objective search space
                    InfillMethod       = 'Global_BetterUncertain';
                    
                    if FEs <= NGlobalMax    
                        IDTrain     = 1:FEs;
                        usetype     = 1; 
                    else
                        NBetterTrain  = 0.5*NGlobalMax; % 1/2 of NGlobalMax
                        if feasibilityCurrent
                            IDBetterObj = DATA.y(1:FEs,1)< bestObjCVCurrent;
                        else
                            IDBetterObj = false(size(DATA.y(1:FEs,1)));
                        end
                        NBetterObj = sum(IDBetterObj);
                        if NBetterObj <=NBetterTrain % 不够n1,就选N个最优的
                            [~,IDTrain] = sort(DATA.y(1:FEs,1));
                            IDTrain     = IDTrain(1:NGlobalMax);
                            usetype = 1;
                        else%数据集平衡
                            IDTrain         = zeros(NGlobalMax,1);
                            IDWorseObj      = ~IDBetterObj;
                            NWorseObj       = sum(IDWorseObj);
                            NWorseTrain     = min(NWorseObj,NGlobalMax-NBetterTrain);%不够n2个的话就有多少取多少，n2=ng-n1
                            RowWorseObj     = find(IDWorseObj);
                            [~,RankObj]     = sort(DATA.y(IDWorseObj,1));
                            IDTrain(1:NWorseTrain) = RowWorseObj(RankObj(1:NWorseTrain));
                            NBetterTrain    = NGlobalMax - NWorseTrain;% 因为nw+nb=fes,这个条件下fes是大于Ng的，所以nw+nb>Ng
                            RowBetterObj    = find(IDBetterObj);
                            [~, RankDist]   = sort(DATA.normDist(IDBetterObj,:),'descend');
                            IDTrain(NWorseTrain+1:end) = RowBetterObj(RankDist(1:NBetterTrain));
                            IDTrain = unique(IDTrain,'stable');
                            usetype = 2;
                        end
                    end
                    %relation_model
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);

                    % data preparation

                    % 计算 xTrain的稀疏度
                    xTrainNorm      =   normalizeVar(xTrain,lowerB,upperB);
                    xTraindist = pdist2(DATA.normx(1:FEs,:), xTrainNorm, 'euclidean', 'Smallest',2)';
                    xTraindist = xTraindist(:, 2);
                   
                    % 记录哪些xTrain对应的yTrain < bestObjCVCurrent
                    IDBetterThanCurrent = yTrain(:,1) < bestObjCVCurrent;

                    % data preparation
                    [Xs,Ys] = FitnessCriteriaGenerator_withoutDist(xTrain,yTrain,DATA.CVsum(IDTrain,1),ExploreType,xTraindist,IDBetterThanCurrent);

                    % surrogate     = Trainer_CNN(Xs,Ys);


                    % Predict the values of the Offspring
                    % [candidateIndex,scores]=FitnessCriteriaUser(surrogate,OFFxii,xTrain);

                    % 使用SVM替换CNN模型
                    % training
                    SVMModel = fitcecoc(Xs, Ys, ...
                        'Learners', templateSVM('KernelFunction', 'rbf', 'Standardize', true), ...
                        'Coding', 'onevsone'); % 或者 'onevsall'，根据需求选择编码方式
                    surrogate = SVMModel;
                    % predict
                
                    [candidateIndex,scores]=SVMUser(surrogate,OFFxii,xTrain,1);

                    % Select points for evaluation
                    xCandidate      = OFFxii(candidateIndex,:);%TODO
                    IDSelect = 1:size(candidateIndex,1);
                    xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                    distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                    [maxDistNorm,IDSelect]   = max(distCandidate);
                else
                    % 3: Explore the most uncertain points in the better-objective search space
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                    else
                        NBetterTrain  = ceil(NGlobalMax*ModelBetterRatio_Better);
                        if feasibilityCurrent
                            IDBetterObj   = DATA.y(1:FEs,1) < bestObjCVCurrent;
                        else
                            IDBetterObj   = false(size(DATA.y(1:FEs,1)));
                        end
                        NBetterObj    = sum(IDBetterObj);
                        if NBetterObj <= NBetterTrain%数据集不平衡
                            [~,IDTrain] = sort(DATA.y(1:FEs,1));
                            IDTrain     = IDTrain(1:NGlobalMax);
                        else
                            IDTrain         = zeros(NGlobalMax,1);
                            IDWorseObj      = ~IDBetterObj;
                            NWorseObj       = sum(IDWorseObj);
                            NWorseTrain     = min(NWorseObj,NGlobalMax-NBetterTrain);%不够n2个的话就有多少取多少，n2=ng-n1
                            RowWorseObj     = find(IDWorseObj);
                            [~,RankObj]     = sort(DATA.y(IDWorseObj,1));
                            IDTrain(1:NWorseTrain) = RowWorseObj(RankObj(1:NWorseTrain));
                            NBetterTrain    = NGlobalMax - NWorseTrain;% 因为nw+nb=fes,这个条件下fes是大于Ng的，所以nw+nb>Ng
                            RowBetterObj    = find(IDBetterObj);
                            [~, RankDist]   = sort(DATA.normDist(IDBetterObj,:),'descend');
                            IDTrain(NWorseTrain+1:end) = RowBetterObj(RankDist(1:NBetterTrain));
                            IDTrain = unique(IDTrain,'stable');
                        end
                    end
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);
                    modelii     = RBFCreate(xTrain, yTrain, kernel,lowerB,upperB);
                    %                 DATA.Models{FEs,1} =  modelii;
                    %                 DATA.Models{FEs,2} = 'Global_BetterUncertain';
                    InfillMethod       = 'Global_BetterUncertain';

                    % Predict the values of the Offspring
                    [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                        = predictCal(OFFxii,modelii,num_g,num_h,toleranceG,toleranceH,CVType);
                    % Select points for evaluation
                    if feasibilityCurrent
                        NBetterObj = sum(DATA.y(1:FEs,1) < bestObjCVCurrent);
                    else
                        NBetterObj = 0;
                    end
                    if NBetterObj <= 0
                        xCandidate      = OFFxii;
                        yCandidate      = y_hat;
                        CVCandidate     = CV_hat;
                        [~,IDSelect]    = min(y_hat(:,1));
                    else
                        IDCandidate = y_hat(:,1) <= ObjLimit;
                        if sum(IDCandidate) == 0
                            % Type 1
                            [~,RankObj_hat]  = sort(y_hat(:,1));
                            NRelax           = ceil(size(IDCandidate,1)*0.1);
                            IDCandidate(RankObj_hat(1:NRelax)) = true;
                            % Type 2
                            % IDCandidate = true(size(IDCandidate));
                            % Type 3
                            % [~,IDminObj_hat] = min(y_hat(:,1));
                            % IDCandidate(IDminObj_hat) = true;
                        end
                        xCandidate      = OFFxii(IDCandidate,:);
                        yCandidate      = y_hat(IDCandidate,:);
                        CVCandidate     = CV_hat(IDCandidate,:);
                        xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                        distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                        [maxDistNorm,IDSelect]   = max(distCandidate);
                    end
                end
            case 4
                InfillMethod       = 'Global_ConstrainedOptimize';
                if Block3==1
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                    else
                        if ~feasibilityCurrent
                            [~,RankCV] = sort(DATA.CVsum(1:FEs,1));
                            IDTrain     = RankCV(1:NGlobalMax);
                        else
                            IDBetterObj   = DATA.y(1:FEs,1) < bestObjCVCurrent;
                            NBetterObj    = sum(IDBetterObj);
                            NBetterTrain  = ceil(NGlobalMax*ModelBetterRatio_Cons);
                            if NBetterObj <= NBetterTrain %n1不够
                                [~,IDTrain] = sort(DATA.y(1:FEs,1));
                                IDTrain     = IDTrain(1:NGlobalMax);
                            else
                                IDTrain         = zeros(NGlobalMax,1);
                                IDWorseObj      = ~IDBetterObj;
                                NWorseObj       = sum(IDWorseObj);
                                NWorseTrain     = min(NWorseObj,NGlobalMax-NBetterTrain);
                                RowWorseObj     = find(IDWorseObj);
                                [~,RankObj]     = sort(DATA.y(IDWorseObj,1));
                                IDTrain(1:NWorseTrain) = RowWorseObj(RankObj(1:NWorseTrain));

                                NBetterTrain    = NGlobalMax - NWorseTrain;
                                RowBetterObj    = find(IDBetterObj);
                                [~, RankDist]   = sort(DATA.CVsum(IDBetterObj,:));
                                IDTrain(NWorseTrain+1:end) = RowBetterObj(RankDist(1:NBetterTrain));

                            end
                        end
                    end
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);

                    %% 替换3
                    %model training%
                    modelii     = RBFCreate(xTrain, yTrain, kernel,lowerB,upperB);
                    

                    % Predict the values of the Offspring
                    [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                        = predictCal(OFFxii,modelii,num_g,num_h,toleranceG,toleranceH,CVType);

                    % Select points for evaluation
                    xCandidate     = OFFxii;
                    yCandidate     = y_hat;
                    CVCandidate    = CV_hat;
                    [~,IDSelect]   = sortrows([CV_hat,y_hat(:,1)],[2,1]);
                    
                elseif Block3==0
                    % 4: Explore by Global Constrained optimization
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                    else
                        % IDTrain       = zeros(NGlobalMax,1);
                        if ~feasibilityCurrent
                            [~,RankCV] = sort(DATA.CVsum(1:FEs,1));
                            IDTrain    = RankCV(1:NGlobalMax);

                        else
                            IDBetterObj   = DATA.y(1:FEs,1) < bestObjCVCurrent;
                            NBetterObj    = sum(IDBetterObj);
                            NBetterTrain  = ceil(NGlobalMax*ModelBetterRatio_Cons);
                            if NBetterObj <= NBetterTrain
                                [~,IDTrain] = sort(DATA.y(1:FEs,1));
                                IDTrain     = IDTrain(1:NGlobalMax);
                            else
                                IDTrain         = zeros(NGlobalMax,1);
                                IDWorseObj      = ~IDBetterObj;
                                NWorseObj       = sum(IDWorseObj);
                                NWorseTrain     = min(NWorseObj,NGlobalMax-NBetterTrain);
                                RowWorseObj     = find(IDWorseObj);
                                [~,RankObj]     = sort(DATA.y(IDWorseObj,1));
                                IDTrain(1:NWorseTrain) = RowWorseObj(RankObj(1:NWorseTrain));

                                NBetterTrain    = NGlobalMax - NWorseTrain;
                                RowBetterObj    = find(IDBetterObj);

                                [~, RankDist]   = sort(DATA.CVsum(IDBetterObj,:));
                                IDTrain(NWorseTrain+1:end) = RowBetterObj(RankDist(1:NBetterTrain));

                            end
                        end
                    end
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);
                    modelii     = RBFCreate(xTrain, yTrain, kernel,lowerB,upperB);
                    %                 DATA.Models{FEs,1} =  modelii;
                    %                 DATA.Models{FEs,2} = 'Global_ConstrainedOptimize';
                    InfillMethod       = 'Global_ConstrainedOptimize';

                    % Predict the values of the Offspring
                    [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                        = predictCal(OFFxii,modelii,num_g,num_h,toleranceG,toleranceH,CVType);
                    % Select points for evaluation
                    xCandidate     = OFFxii;
                    yCandidate     = y_hat;
                    CVCandidate    = CV_hat;

                    if feasibilityRule ||  (~feasibilityCurrent && rand < 1)
                        [~,IDSelect]   = sortrows([CV_hat,y_hat(:,1)],[1,2]);
                    elseif ~feasibilityCurrent
                        [~,IDSelect]   = sortrows([CV_hat,y_hat(:,1)],[2,1]);
                    else
                        NBetterObj     = sum(DATA.y(1:FEs,1) < bestObjCVCurrent);
                        NBetterObj_hat = sum(y_hat(:,1) < bestObjCVCurrent);
                        if NBetterObj <= 0 || NBetterObj_hat <= 0
                            if NBetterObj_hat > 0
                                [~,IDSelect] = sort(y_hat(:,1));
                            else
                                if rand < 0.5
                                    [~,IDSelect] = sort(y_hat(:,1));
                                else
                                    xCandidateNorm = normalizeVar(xCandidate,lowerB,upperB);
                                    distCandidate  = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                                    [~,IDSelect]   = max(distCandidate);
                                end
                            end
                        else
                            [~,IDSelect]   = sortrows([CV_hat,y_hat(:,1)],[1,2]);
                        end
                    end
                elseif Block3==2
                    if FEs <= NGlobalMax
                        IDTrain     = 1:FEs;
                    else
                        [~, RankFR]    = sortrows([DATA.CVsum(1:FEs,:),DATA.y(1:FEs,1)],[1,2]);
                        IDTrain            = RankFR(1:NGlobalMax);
                        
                    end
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);
                    [Xs,Ys] = FitnessCriteriaGenerator_withoutDist(xTrain,yTrain,DATA.CVsum(IDTrain,1),ExploreType);
                    % surrogate     = Trainer_CNN(Xs,Ys);
                    % [candidateIndex,scores]=FitnessCriteriaUser(surrogate,OFFxii,xTrain);
                    % 使用SVM替换CNN模型
                    SVMModel = fitcsvm(Xs, Ys, 'KernelFunction', 'rbf', 'Standardize', true);
                    surrogate = SVMModel;
                    
                   
                    [candidateIndex,scores]=SVMUser(surrogate,OFFxii,xTrain,2);



                    
                    % Select points for evaluation
                    xCandidate      = OFFxii(candidateIndex,:);%TODO
                    IDSelect = 1:size(candidateIndex,1);
                    xCandidateNorm  = normalizeVar(xCandidate,lowerB,upperB);
                    distCandidate   = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1)';
                    [maxDistNorm,IDSelect]   = max(distCandidate);
                end

        end
        %=========Global: Expensive evaluation=============================
        x_add       = xCandidate(IDSelect(1),:);
        dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
        if dist_add <= 0 % 如果重合
            if ClusterCriterion == 1
                dist_OFFxii         = pdist2(DATA.x(1:FEs,:),xCandidate,'euclidean','Smallest',1);
                [dist_add,IDSelect] = max(dist_OFFxii);
                x_add               = xCandidate(IDSelect(1),:);
                if dist_add <= 0
                    while true
                        x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                        IDSelect    = 1;
                        dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                        if dist_add > 0
                            break;
                        end
                    end
                end
            else
                dist_OFFxii         = pdist2(DATA.x(1:FEs,:),xCandidate,'euclidean','Smallest',1);
                IDDifferent         = find(dist_OFFxii > 0);
                if isempty(IDDifferent)
                    while true
                        x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                        IDSelect    = 1;
                        dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                        if dist_add > 0
                            break;
                        end
                    end
                else
                    [~, IDSelect]       = min(yCandidate(IDDifferent,1));
                    IDSelect            = IDDifferent(IDSelect(1));
                    x_add               = xCandidate(IDSelect(1),:);
                end
            end
        end
        norm_x_add = normalizeVar(x_add,lowerB,upperB);

        [objVal_add,consGVal_add,consHVal_add]  =   problem(x_add,fnum);
        [consGVal_add,consHVal_add]             =   corrConVal(consGVal_add,consHVal_add,num_g,num_h);
        CV_add                                  =   CVCal0(consGVal_add, consHVal_add, toleranceG,toleranceH,CVType);
        FEs                                     =   FEs + 1;
        y_add                                   =   [objVal_add,consGVal_add,consHVal_add];

        DATA_ADD                                =   [DATA_ADD;[x_add,y_add]];
        CVs_ADD                                 =   [CVs_ADD; CV_add];
        norm_xs_ADD                             =   [norm_xs_ADD; norm_x_add];
        DATAInfill{ExploreType,1} = [DATAInfill{ExploreType,1}; [x_add,y_add]];
        DATAInfill{ExploreType,2} = [DATAInfill{ExploreType,2}; InfillMethod];

        %========Global: Update Database===================================
        [bestIndCurrent, bestObjCVCurrent,feasibilityCurrent]  = updateBest(bestIndCurrent,bestObjCVCurrent,feasibilityCurrent,x_add,objVal_add,CV_add);
        
        bestPointer                                            = bestPointer + 1;
        UpdateDATA.bestSitesLog(bestPointer,:)                 = bestIndCurrent;
        UpdateDATA.bestValLog(bestPointer,:)                   = [bestObjCVCurrent,feasibilityCurrent];
        
        % 检查是否找到最优解，如果是则直接结束
        if checkOptimalSolution(fnum, bestObjCVCurrent, feasibilityCurrent)
            FEs = maxFEs;  % 直接设置FEs为最大值以结束算法
            fprintf('找到最优解！FEs设置为%d，算法结束。\n', maxFEs);
        end
        DATA.x(FEs,:)                                          = x_add;
        DATA.y(FEs,:)                                          = y_add;
        DATA.CVsum(FEs,:)                                      = CV_add;
        DATA.normx(FEs,:)                                      = norm_x_add;

        newDist                     = pdist2(DATA.normx(1:FEs-1,:),norm_x_add);
        replace                     = newDist < DATA.normDist(1:FEs-1,:);
        DATA.normDist(replace,:)    = newDist(replace,:);
        DATA.normDist(FEs,:)        = min(newDist);
        if ~isempty(f_best) && feasibilityCurrent
            FuncERROR = bestObjCVCurrent - f_best;
        else
            FuncERROR = inf;
        end
        fprintf('FEs: %6d; bestObjCV: %.15e; fbest: %5.2e; funcERROR: %5.2e; Feasibility: %d; Infill(%s): %s\n',...
            FEs,bestObjCVCurrent,f_best, FuncERROR, feasibilityCurrent, 'Exploit',InfillMethod);
        %=========Global: Update the Population DX1 and DX2================
        % DX1
        if EnvSelNearest
            IDCompare = knnsearch(DX1norm,norm_x_add,'K',1);
        else
            [~, IDCompare] = max(DY1(:,1));
        end
        if y_add(1,1) < DY1(IDCompare,1)
            DX1(IDCompare,:) = x_add;
            DY1(IDCompare,:) = y_add;
            CV1(IDCompare,:) = CV_add;
            DX1norm(IDCompare,:) = norm_x_add;
        end
        % DX2
        if EnvSelNearest
            IDCompare       = knnsearch(DX2norm,norm_x_add,'K',1);
            % [TODO]
        else
            if feasibilityRule || ~feasibilityCurrent
                % The situation where no feasible solution is found is same to feasibilityRule
                [~, IDCompare]  = max(CV2);
                replace   = (CV_add == CV2(IDCompare,:)) & y_add(:,1) <= DY2(IDCompare,1);
                replace   = replace | (CV_add < CV2(IDCompare,:));
            else % Proposed method
                IDBetter = DY2(:,1) < bestObjCVCurrent;
                if any(IDBetter)
                    [~, IDCompare] = max(CV2(:,1));
                    replace = (CV_add == CV2(IDCompare,:) ) & y_add(:,1) <= DY2(IDCompare,1);
                    replace = replace | CV_add < CV2(IDCompare,:);
                else
                    [~, IDCompare] = max(DY2(:,1));
                    replace1       = (CV_add == 0) && y_add(:,1) <= bestObjCVCurrent;
                    replace2       = (y_add(:,1) >= bestObjCVCurrent) && (y_add(:,1)<= DY2(IDCompare,1));
                    replace        = replace1 || replace2;
                end
            end
        end
        if replace
            DX2(IDCompare,:) = x_add;
            DY2(IDCompare,:) = y_add;
            CV2(IDCompare,:) = CV_add;
            DX2norm(IDCompare,:) = norm_x_add;
        end
        MaxCV2Log = [MaxCV2Log;max(CV2)];
        MaxDY2Log = [MaxDY2Log;max(DY2(:,1))];
        if FEs >= maxFEs
            break;
        end
    end
    if FEs >= maxFEs
        break;
    end

    %% Exploit: by Local model
    if feasibilityCurrent
        IDBetterObj   = DATA.y(1:FEs,1) < bestObjCVCurrent;
        IDWorseObj    = ~IDBetterObj;
        NBetterObj    = sum(IDBetterObj);
        NWorseObj     = sum(IDWorseObj);
        RowBetter     = find(IDBetterObj);
        RowWorse      = find(IDWorseObj);
        [~,RankBetter]   = sort(DATA.CVsum(RowBetter,1));
        [~,RankWorse]    = sort(DATA.y(RowWorse,1));

        NBetterLocal  = min(NBetterObj, ceil(NP * BetterRatio));
        NWorseLocal   = min(NWorseObj,NP-NBetterLocal);
        NBetterLocal  = NP-NWorseLocal;

        Row_Select    = [RowBetter(RankBetter(1:NBetterLocal)); RowWorse(RankWorse(1:NWorseLocal))];


    else
        [~,RankCVs]   = sort(DATA.CVsum(1:FEs,:));
        
        Row_Select    = RankCVs(1:NP);

    end
    POPx  = DATA.x(Row_Select,:);
    POPy  = DATA.y(Row_Select,:);
    POPCV = DATA.CVsum(Row_Select,:);
    POPxnorm = DATA.normx(Row_Select,:);
    
    % local Search
    DATA_ADD    = [];
    CVs_ADD     = [];
    norm_xs_ADD = [];
    NReplace    = 0;
    rewardX     = [];
    for ii = 1:NP
        xii         = POPx(ii,:);
        xiinorm     = POPxnorm(ii,:);
        IDTrain     = knnsearch(DATA.normx(1:FEs,:),xiinorm,'K',Knearest + 1);
        xTrain      = DATA.x(IDTrain,:);
        yTrain      = DATA.y(IDTrain,:);
        CVTrain     = DATA.CVsum(IDTrain,:);
        lowerBxii   = min(xTrain,[],1);
        upperBxii   = max(xTrain,[],1);
        Rangexii    = upperBxii - lowerBxii;
        IDSmall     = Rangexii < minLocalRange;
        lowerBxii(IDSmall) = lowerBxii(IDSmall) - minLocalRange/2;
        upperBxii(IDSmall) = upperBxii(IDSmall) + minLocalRange/2;
        lowerBxii          = max(lowerBxii,lowerB);
        upperBxii          = min(upperBxii,upperB);
        Rangexii           = upperBxii - lowerBxii;
        NExtendLocalTemp   = 0;
        while NExtendLocalTemp <= NExtendLimit
            % Add points into xTrain?
            modelii             = RBFCreate(xTrain, yTrain, kernel,lowerBxii,upperBxii);
%             DATA.Models{FEs,1}  =  modelii;
            if NExtendLocalTemp == 0
%                 DATA.Models{FEs,2}  = 'Local_Exploit';
                InfillMethod        = 'Local_Exploit';
            else
%                 DATA.Models{FEs,2}  = 'Local_Exploit_Extend';
                InfillMethod        = 'Local_Exploit_Extend';
            end
            % SQP local search
            LocalObjFun0  = @(x)LocalObjFun1(x,modelii);
            LocalConFun0  = @(x)LocalConFun1(x,modelii,0,num_g,num_h,toleranceG,toleranceH,CVType);
            xStart0       = xii;

            options              = optimset('Algorithm', algorithmLocalSearch, 'MaxFunEvals', maxFEsLocal, 'Display', 'off');
            
            if ~feasibilityCurrent || (feasibilityCurrent && sum(DATA.y(:,1) < bestObjCVCurrent) > 0)
                [xTemp,objValLocal0] = fmincon(LocalObjFun0,xStart0,[],[],[],[],lowerBxii,upperBxii,LocalConFun0,options);
            else
                [xTemp,objValLocal0] = fmincon(LocalObjFun0,xStart0,[],[],[],[],lowerBxii,upperBxii,[],options);
            end

            if any(xTemp< lowerBxii) || any(xTemp > upperBxii) %如果越界
                xTemp(xTemp < lowerBxii) = lowerBxii(xTemp <lowerBxii);
                xTemp(xTemp > upperBxii) = upperBxii(xTemp > upperBxii);
                objValLocal0 = LocalObjFun0(xTemp);
            end
            if ExtendLocalRegion && NExtendLocalTemp < NExtendLimit
                % Adaptively extend the local region
                xFRBest     = xTemp;
                LowerBDist  = abs(lowerBxii - xFRBest);
                UppberBDist = upperBxii - xFRBest;
                BoundaryTolerance = (upperBxii-lowerBxii)*BoundaryTolerRatio;
                DimExtendLower    = LowerBDist < BoundaryTolerance;
                DimExtendUpper    = UppberBDist < BoundaryTolerance;
                if any(DimExtendLower) || any(DimExtendUpper)
                    NExtendLocalRegion = NExtendLocalRegion + 1;
                    lowerBxii(DimExtendLower) = max(lowerBxii(DimExtendLower)-ExtendRatio*(upperBxii(DimExtendLower)-lowerBxii(DimExtendLower)),...
                        lowerB(DimExtendLower));
                    upperBxii(DimExtendUpper) = min(upperBxii(DimExtendUpper)+ExtendRatio*(upperBxii(DimExtendUpper)-lowerBxii(DimExtendUpper)),...
                        upperB(DimExtendUpper));
                    NExtendLocalTemp = NExtendLocalTemp + 1;
                else
                    NExtendLocalTemp = NExtendLimit + 1;
                end
            else
                NExtendLocalTemp = NExtendLimit + 1;
            end
        end

        x_add       = xTemp;
        dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
        if dist_add <= 0
            TypeLocalOffspring = [1,4,6];
            [~, RankObj]       = sort(yTrain(:,1));
            XBest_Local        = xTrain(RankObj(1),:);
            XTopPBest_Local    = xTrain(RankObj(1: ceil(Knearest*0.1)),:);
            xCandidate         = generateOFF(xTrain,NPresceen,F,CR,TypeLocalOffspring, TypeNOFF, {XBest_Local,XTopPBest_Local});
            xCandidate         = Repair(xCandidate, lowerBxii, upperBxii);
            [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                    = predictCal(xCandidate,modelii,num_g,num_h,toleranceG,toleranceH,CVType);

            
            if rand < -1
                xCandidateNorm      = normalizeVar(xCandidate,lowerB,upperB);
                dist_OFFxii         = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1);
                [dist_add,IDSelect] = max(dist_OFFxii);
            elseif rand < 0.5 || ~feasibilityCurrent
                [~, IDSelect] = sortrows([CV_hat, y_hat(:,1)],[1,2]);
            else
                [~, IDSelect] = min(y_hat(:,1));
            end

            x_add       = xCandidate(IDSelect(1),:);
            dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
            if dist_add <= 0
                if ClusterCriterion == 1
                    xCandidateNorm      = normalizeVar(xCandidate,lowerB,upperB);
                    dist_OFFxii         = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1);
                    [dist_add,IDSelect] = max(dist_OFFxii);
                    x_add               = xCandidate(IDSelect(1),:);
                    if dist_add <= 0
                        while true
                            x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                            IDSelect    = 1;
                            dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                            if dist_add > 0
                                break;
                            end
                        end
                    end
                else
                    dist_OFFxii         = pdist2(DATA.x(1:FEs,:),xCandidate,'euclidean','Smallest',1);
                    IDDifferent         = find(dist_OFFxii > 0);
                    if isempty(IDDifferent)
                        while true
                            x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                            IDSelect    = 1;
                            dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                            if dist_add > 0
                                break;
                            end
                        end
                    else
                        [~, IDSelect]       = min(yCandidate(IDDifferent,1));
                        IDSelect            = IDDifferent(IDSelect(1));
                        x_add               = xCandidate(IDSelect(1),:);
                    end
                end
            end        
        end
        
        norm_x_add = normalizeVar(x_add,lowerB,upperB);
        [objVal_add,consGVal_add,consHVal_add]  =   problem(x_add,fnum);
        [consGVal_add,consHVal_add]             =   corrConVal(consGVal_add,consHVal_add,num_g,num_h);
        CV_add                                  =   CVCal0(consGVal_add, consHVal_add, toleranceG,toleranceH,CVType);
        FEs                                     =   FEs + 1;
        y_add                                   =   [objVal_add,consGVal_add,consHVal_add];

        DATA_ADD                                =   [DATA_ADD;[x_add,y_add]];
        CVs_ADD                                 =   [CVs_ADD; CV_add];
        norm_xs_ADD                             =   [norm_xs_ADD; norm_x_add];
        ExploitType                             =   max(ExploreType) + 1;
        DATAInfill{ExploitType,1} = [DATAInfill{ExploitType,1}; [x_add,y_add]];
        DATAInfill{ExploitType,2} = [DATAInfill{ExploitType,2}; {InfillMethod}];
        % ============================ Update Database ====================
        [bestIndCurrent, bestObjCVCurrent,feasibilityCurrent]  = updateBest(bestIndCurrent,bestObjCVCurrent,feasibilityCurrent,x_add,objVal_add,CV_add);
        bestPointer                                            = bestPointer + 1;
        UpdateDATA.bestSitesLog(bestPointer,:)                 = bestIndCurrent;
        UpdateDATA.bestValLog(bestPointer,:)                   = [bestObjCVCurrent,feasibilityCurrent];
        
        % 检查是否找到最优解，如果是则直接结束
        if checkOptimalSolution(fnum, bestObjCVCurrent, feasibilityCurrent)
            FEs = maxFEs;  % 直接设置FEs为最大值以结束算法
            fprintf('找到最优解！FEs设置为%d，算法结束。\n', maxFEs);
        end
        DATA.x(FEs,:)                                          = x_add;
        DATA.y(FEs,:)                                          = y_add;
        DATA.CVsum(FEs,:)                                      = CV_add;
        DATA.normx(FEs,:)                                      = norm_x_add;
        
        newDist                     = pdist2(DATA.normx(1:FEs-1,:),norm_x_add);
        replace                     = newDist < DATA.normDist(1:FEs-1,:);
        DATA.normDist(replace,:)    = newDist(replace,:);
        DATA.normDist(FEs,:)        = min(newDist);
        if ~isempty(f_best) && feasibilityCurrent
            FuncERROR = bestObjCVCurrent - f_best;
        else
            FuncERROR = inf;
        end
        fprintf('FEs: %6d; bestObjCV: %.15e; fbest: %5.2e; funcERROR: %5.2e; Feasibility: %d; Infill(%s): %s\n',...
            FEs,bestObjCVCurrent,f_best, FuncERROR, feasibilityCurrent, 'Exploit',InfillMethod);

%         fprintf('FEs: %6d; bestObjCV: %5.2e; Feasibility: %d; Infill(%s): %s\n',...
%             FEs,bestObjCVCurrent,feasibilityCurrent, 'Exploit',InfillMethod);
        
        %=========Local: Update the Population DX1 and DX2================
        % DX1
        if EnvSelNearest
            IDCompare = knnsearch(DX1norm,norm_x_add,'K',1);
        else
            [~, IDCompare] = max(DY1(:,1));
        end
        if y_add(1,1) < DY1(IDCompare,1)
            DX1(IDCompare,:) = x_add;
            DY1(IDCompare,:) = y_add;
            CV1(IDCompare,:) = CV_add;
            DX1norm(IDCompare,:) = norm_x_add;
        end
        
        % DX2
        if EnvSelNearest
            IDCompare       = knnsearch(DX2norm,norm_x_add,'K',1);
            % [TODO]
        else
            if feasibilityRule || ~feasibilityCurrent
                % The situation where no feasible solution is found is same to feasibilityRule
                % Select the nearest point to compare
                [~, IDCompare]  = max(CV2);
%                 IDCompare = knnsearch(DX2norm,norm_x_add,'K',1);
                replace   = (CV_add == CV2(IDCompare,:)) & y_add(:,1) <= DY2(IDCompare,1);
                replace   = replace | (CV_add < CV2(IDCompare,:));
            else % Proposed method
                IDBetter = DY2(:,1) < bestObjCVCurrent;
                if any(IDBetter)
                    [~, IDCompare] = max(CV2(:,1));
                    replace = (CV_add == CV2(IDCompare,:) ) & y_add(:,1) <= DY2(IDCompare,1);
                    replace = replace | CV_add < CV2(IDCompare,:);
                else
                    [~, IDCompare] = max(DY2(:,1));
                    replace1       = (CV_add == 0) && y_add(:,1) <= bestObjCVCurrent;
                    replace2       = (y_add(:,1) >= bestObjCVCurrent) && (y_add(:,1)<= DY2(IDCompare,1));
                    replace        = replace1 || replace2;
                end
            end
        end
        if replace
            DX2(IDCompare,:) = x_add;
            DY2(IDCompare,:) = y_add;
            CV2(IDCompare,:) = CV_add;
            DX2norm(IDCompare,:) = norm_x_add;
        end
         MaxCV2Log = [MaxCV2Log;max(CV2)];
         MaxDY2Log = [MaxDY2Log;max(DY2(:,1))];
        if FEs >= maxFEs
            break;
        end
        if RewardSearch
            %% Reward infill(Boundary detection)
            if (feasibilityCurrent && y_add(1) <= bestObjCVCurrent) 
                    % Local modelling
                    IDTrain     = knnsearch(DATA.normx(1:FEs,:),norm_x_add,'K',Knearest + 1);
                    xTrain      = DATA.x(IDTrain,:);
                    yTrain      = DATA.y(IDTrain,:);
                    CVTrain     = DATA.CVsum(IDTrain,:);
                    lowerBxii   = min(xTrain,[],1);
                    upperBxii   = max(xTrain,[],1);
                    Rangexii    = upperBxii - lowerBxii;
                    IDSmall     = Rangexii < minLocalRange;
                    lowerBxii(IDSmall) = lowerBxii(IDSmall) - minLocalRange/2;
                    upperBxii(IDSmall) = upperBxii(IDSmall) + minLocalRange/2;
                    lowerBxii          = max(lowerBxii,lowerB);
                    upperBxii          = min(upperBxii,upperB);
                    Rangexii           = upperBxii - lowerBxii;
                    NExtendLocalTemp   = 0;
                    while NExtendLocalTemp <= NExtendLimit
                        % Add points into xTrain?
                        modelii             = RBFCreate(xTrain, yTrain, kernel,lowerBxii,upperBxii);
                        %                     DATA.Models{FEs,1}  =  modelii;
                        if NExtendLocalTemp == 0
                            %                         DATA.Models{FEs,2}  = 'Local_Reward';
                            InfillMethod        = 'Local_Reward';
                        else
                            %                         DATA.Models{FEs,2}  = 'Local_Reward_Extend';
                            InfillMethod        = 'Local_Reward_Extend';
                        end
                        % Generate Offspring as candidates
                        Parentsii           = xTrain;
                        TypeLocalOffspring  = [1,4,6];
                        if any(ismember(TypeLocalOffspring,[5,6,7,8,9]))
                            [~,RankCVObj]    = sortrows([CVTrain,yTrain(:,1)],[1,2]);
                            Parentsii        = xTrain(RankCVObj,:);
                            xBestii          = Parentsii(1,:);
                            xTopPBestii      = xBestii;
                        end
                        OFFxii  = generateOFF(Parentsii,NPresceen,F,CR,TypeLocalOffspring,TypeNOFF,{xBestii,xTopPBestii});
                        OFFxii  = Repair(OFFxii, lowerBxii, upperBxii);
                        % Prescreen individual for expensive evaluating
                        [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] ...
                            = predictCal(OFFxii,modelii,num_g,num_h,toleranceG,toleranceH,CVType);
                        [~, IDSelect] = sortrows([CV_hat,y_hat(:,1)],[1 2]);

                        if ExtendLocalRegion && NExtendLocalTemp < NExtendLimit
                            % Adaptively extend the local region
                            xFRBest     = OFFxii(IDSelect(1),:);
                            LowerBDist  = abs(lowerBxii - xFRBest);
                            UppberBDist = upperBxii - xFRBest;
                            BoundaryTolerance = (upperBxii-lowerBxii)*BoundaryTolerRatio;
                            DimExtendLower    = LowerBDist < BoundaryTolerance;
                            DimExtendUpper    = UppberBDist < BoundaryTolerance;
                            if any(DimExtendLower) || any(DimExtendUpper)
                                NExtendLocalRegion = NExtendLocalRegion + 1;
                                lowerBxii(DimExtendLower) = max(lowerBxii(DimExtendLower)-ExtendRatio*(upperBxii(DimExtendLower)-lowerBxii(DimExtendLower)),...
                                    lowerB(DimExtendLower));
                                upperBxii(DimExtendUpper) = min(upperBxii(DimExtendUpper)+ExtendRatio*(upperBxii(DimExtendUpper)-lowerBxii(DimExtendUpper)),...
                                    upperB(DimExtendUpper));
                                NExtendLocalTemp = NExtendLocalTemp + 1;
                                %                             ID1 = all(DATA.x(1:FEs,:) <= upperBxii,2);
                                %                             ID2 = all(lowerBxii <= DATA.x(1:FEs,:),2);
                                %                             IDTrain     = ID1 & ID2;
                                %                             xTrain      = DATA.x(IDTrain,:);
                                %                             yTrain      = DATA.y(IDTrain,:);
                                %                             CVTrain     = DATA.CVsum(IDTrain,:);
                            else
                                NExtendLocalTemp = NExtendLimit + 1;
                            end
                        else
                            NExtendLocalTemp = NExtendLimit + 1;
                        end
                    end
                    if feasibilityRule
                        IDSelect      = IDSelect(1);
                    else % Proposed method
                        % Heterogeneously select points for evaluation
                        IDBetterObj   = y_hat(:,1) <= bestObjCVCurrent;
                        if ~any(IDBetterObj)
                            [~,IDSelect]          = min(y_hat(:,1));
                        else
                            RowBetterObj        = find(IDBetterObj);
                            y_hatBetterObj      = y_hat(RowBetterObj,:);
                            CV_hatBetterObj     = CV_hat(RowBetterObj,:);

                            IDFeasibleBetter    = CV_hatBetterObj <= 0;
                            if sum(IDFeasibleBetter) == 0
                                [~,IDminCV]  = min(CV_hatBetterObj);
                                IDSelect     = RowBetterObj(IDminCV);
                            elseif sum(IDFeasibleBetter) == sum(IDBetterObj)
                                [~,IDminObj]  = min(y_hatBetterObj(:,1));
                                IDSelect      = RowBetterObj(IDminObj);
                            else
                                if CV_add > 0
                                    % Better predicted feasible solution
                                    RowBetterObjFeasible = find(IDFeasibleBetter);
                                    [~,IDFeasibleBest]   = min(y_hatBetterObj(IDFeasibleBetter,1));
                                    IDSelect             = RowBetterObj(RowBetterObjFeasible(IDFeasibleBest));
                                else
                                    % Predicted infeasible solution with better objective and the minimum CV_hat
                                    RowBetterObjInfeasible  = find(~IDFeasibleBetter);
                                    [~,IDminCV]             = min(CV_hatBetterObj(RowBetterObjInfeasible,1));
                                    IDSelect                = RowBetterObj(RowBetterObjInfeasible(IDminCV));
                                end
                            end
                        end
                    end
                    % Expensive evaluation
                    x_add       = OFFxii(IDSelect(1),:);
                    dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                    xCandidate  = OFFxii;
                    xCandidateNorm = normalizeVar(xCandidate,lowerB,upperB);
                    if dist_add <= 0
                        if ClusterCriterion == 1
                            dist_OFFxii         = pdist2(DATA.normx(1:FEs,:),xCandidateNorm,'euclidean','Smallest',1);
                            [dist_add,IDSelect] = max(dist_OFFxii);
                            x_add               = xCandidate(IDSelect(1),:);
                            if dist_add <= 0
                                while true
                                    x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                                    IDSelect    = 1;
                                    dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                                    if dist_add > 0
                                        break;
                                    end
                                end
                            end
                        else
                            dist_OFFxii         = pdist2(DATA.x(1:FEs,:),xCandidate,'euclidean','Smallest',1);
                            IDDifferent         = find(dist_OFFxii > 0);
                            if isempty(IDDifferent)
                                while true
                                    x_add       = lowerB+(upperB-lowerB).*rand(1,Dim);
                                    IDSelect    = 1;
                                    dist_add    = pdist2(DATA.x(1:FEs,:),x_add,'euclidean','Smallest',1);
                                    if dist_add > 0
                                        break;
                                    end
                                end
                            else
                                [~, IDSelect]       = min(yCandidate(IDDifferent,1));
                                IDSelect            = IDDifferent(IDSelect(1));
                                x_add               = xCandidate(IDSelect(1),:);
                            end
                        end
                    end
                    norm_x_add = normalizeVar(x_add,lowerB,upperB);

                    [objVal_add,consGVal_add,consHVal_add]  =   problem(x_add,fnum);
                    [consGVal_add,consHVal_add]             =   corrConVal(consGVal_add,consHVal_add,num_g,num_h);
                    CV_add                                  =   CVCal0(consGVal_add, consHVal_add, toleranceG,toleranceH,CVType);
                    FEs                                     =   FEs + 1;
                    y_add                                   =   [objVal_add,consGVal_add,consHVal_add];

                    DATA_ADD                                =   [DATA_ADD;[x_add,y_add]];
                    CVs_ADD                                 =   [CVs_ADD; CV_add];
                    norm_xs_ADD                             =   [norm_xs_ADD; norm_x_add];
                    ExploitType                             =   max(ExploreType) + 2;
                    DATAInfill{ExploitType,1} = [DATAInfill{ExploitType,1}; [x_add,y_add]];
                    DATAInfill{ExploitType,2} = [DATAInfill{ExploitType,2}; {InfillMethod}];
                    % =================== Update Database ====================
                    [bestIndCurrent, bestObjCVCurrent,feasibilityCurrent]  = updateBest(bestIndCurrent,bestObjCVCurrent,feasibilityCurrent,x_add,objVal_add,CV_add);
                    bestPointer                                            = bestPointer + 1;
                    UpdateDATA.bestSitesLog(bestPointer,:)                 = bestIndCurrent;
                    UpdateDATA.bestValLog(bestPointer,:)                   = [bestObjCVCurrent,feasibilityCurrent];
                    
                    % 检查是否找到最优解，如果是则直接结束
                    if checkOptimalSolution(fnum, bestObjCVCurrent, feasibilityCurrent)
                        FEs = maxFEs;  % 直接设置FEs为最大值以结束算法
                        fprintf('找到最优解！FEs设置为%d，算法结束。\n', maxFEs);
                    end
                    DATA.x(FEs,:)                                          = x_add;
                    DATA.y(FEs,:)                                          = y_add;
                    DATA.CVsum(FEs,:)                                      = CV_add;
                    DATA.normx(FEs,:)                                      = norm_x_add;

                    newDist                     = pdist2(DATA.normx(1:FEs-1,:),norm_x_add);
                    replace                     = newDist < DATA.normDist(1:FEs-1,:);
                    DATA.normDist(replace,:)    = newDist(replace,:);
                    DATA.normDist(FEs,:)        = min(newDist);
                    if ~isempty(f_best) && feasibilityCurrent
                        FuncERROR = bestObjCVCurrent - f_best;
                    else
                        FuncERROR = inf;
                    end
                    fprintf('FEs: %6d; bestObjCV: %.15e; fbest: %5.2e; funcERROR: %5.2e; Feasibility: %d; Infill(%s): %s\n',...
                         FEs,bestObjCVCurrent,f_best, FuncERROR, feasibilityCurrent, 'Exploit',InfillMethod);
                    %=========Local: Update the Population DX1 and DX2================
                    % DX1
                    if EnvSelNearest
                        IDCompare = knnsearch(DX1norm,norm_x_add,'K',1);
                    else
                        [~, IDCompare] = max(DY1(:,1));
                    end
                    if y_add(1,1) < DY1(IDCompare,1)
                        DX1(IDCompare,:) = x_add;
                        DY1(IDCompare,:) = y_add;
                        CV1(IDCompare,:) = CV_add;
                        DX1norm(IDCompare,:) = norm_x_add;
                    end
                    % DX2
                    if EnvSelNearest
                        IDCompare       = knnsearch(DX2norm,norm_x_add,'K',1);
                        % [TODO]
                    else
                        if feasibilityRule || ~feasibilityCurrent
                            % The situation where no feasible solution is found is same to feasibilityRule
                            [~, IDCompare]  = max(CV2);
                            replace   = (CV_add == CV2(IDCompare,:)) & y_add(:,1) <= DY2(IDCompare,1);
                            replace   = replace | (CV_add < CV2(IDCompare,:));
                        else % Proposed method
                            IDBetter = DY2(:,1) < bestObjCVCurrent;
                            if any(IDBetter)
                                [~, IDCompare] = max(CV2(:,1));
                                replace = (CV_add == CV2(IDCompare,:) ) & y_add(:,1) <= DY2(IDCompare,1);
                                replace = replace | CV_add < CV2(IDCompare,:);
                            else
                                [~, IDCompare] = max(DY2(:,1));
                                replace1       = (CV_add == 0) && y_add(:,1) <= bestObjCVCurrent;
                                replace2       = (y_add(:,1) >= bestObjCVCurrent) && (y_add(:,1)<= DY2(IDCompare,1));
                                replace        = replace1 || replace2;
                            end
                        end
                    end
                    if replace
                        DX2(IDCompare,:) = x_add;
                        DY2(IDCompare,:) = y_add;
                        CV2(IDCompare,:) = CV_add;
                        DX2norm(IDCompare,:) = norm_x_add;
                    end
                    MaxCV2Log = [MaxCV2Log;max(CV2)];
                    MaxDY2Log = [MaxDY2Log;max(DY2(:,1))];
                
            end
            if FEs >= maxFEs
                break;
            end
        end
    end
    if FEs >= maxFEs
        break;
    end
end
timeConsumed=toc;
DATA.DATAInfill_6part = DATAInfill;
end

function f = LocalObjFun1(x,modelLocal)
y       = RBFInterp(x, modelLocal);
f       = y(:,1);
end

function f = LocalObjFun2(x,modelLocal,normDATAx,lowerB,upperB)
y               = RBFInterp(x, modelLocal);
f               = y(:,1);
normlized_x     = normalizeVar(x,lowerB,upperB);
minDist         = pdist2(normDATAx,normlized_x,"euclidean",'Smallest',1);
end


function [g,h] = LocalConFun1(x,modelLocal,epsilon,num_g,num_h,toleranceG,toleranceH,CVType)
try
    y = RBFInterp(x, modelLocal);
    
    % 检查RBF预测结果是否有效
    if any(~isfinite(y(:)))
        % 如果预测值无效，返回大的约束违反值
        if num_g > 0
            g = ones(size(x,1), num_g) * 1e6;
        else
            g = zeros(size(x,1), 1);
        end
        if num_h > 0
            h = ones(size(x,1), num_h) * 1e6;
        else
            h = zeros(size(x,1), 1);
        end
        return;
    end
    
    g = y(:,2:1+num_g);
    h = y(:,2+num_g:end);
    [g,h] = corrConVal(g,h,num_g,num_h);
    
    % 检查约束值是否有效
    if any(~isfinite(g(:))) || any(~isfinite(h(:)))
        if num_g > 0
            g = ones(size(x,1), num_g) * 1e6;
        else
            g = zeros(size(x,1), 1);
        end
        if num_h > 0
            h = ones(size(x,1), num_h) * 1e6;
        else
            h = zeros(size(x,1), 1);
        end
        return;
    end
    
    CV = CVCal0(g, h, toleranceG,toleranceH,CVType);
    Feasible = CV <= epsilon;
    g(Feasible,:) = 0;
    h(Feasible,:) = 0;

catch ME
    % 如果出现任何错误，返回安全的约束值
    if num_g > 0
        g = ones(size(x,1), num_g) * 1e6;
    else
        g = zeros(size(x,1), 1);
    end
    if num_h > 0
        h = ones(size(x,1), num_h) * 1e6;
    else
        h = zeros(size(x,1), 1);
    end
end

% 确保返回值的维度正确
if num_g == 0
    g = zeros(size(x,1), 1);
end
if num_h == 0
    h = zeros(size(x,1), 1);
end
end

