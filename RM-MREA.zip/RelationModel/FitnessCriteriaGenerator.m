function varargout = FitnessCriteriaGenerator(varargin)
if nargin == 3 % only fitness
    decs = varargin{1};         % x
    y = varargin{2};
    fitness  =   y(:,1);        % y
    exploretype  =   varargin{3};% type
    
    switch exploretype
        case 4
            % Calculate the length of the input vectors
            len_decs = size(decs, 1);
            % Generate all possible index combinations
            ind1 = combvec(1:len_decs, 1:len_decs);
            % Identify the indices where both elements are equal
            equind = ind1(1, :) == ind1(2, :);

            % Generate all possible combinations of decs and fitness
            decsCombinations = combvec(decs', decs')';
            
            % Initialize the label array
            labels = zeros(size(decsCombinations, 1), 1);

            % Assign labels based on the comparison result
            for i = 1:size(decsCombinations, 1)
                x1_fitness=fitness(ind1(1,i));
                x2_fitness=fitness(ind1(2,i));

                % 对比 x1 和 x2 的fitness
                if x1_fitness <  x2_fitness    
                    labels(i) = 1;
                else
                    labels(i) = -1;                    
                end
            end
            % 删除相等的索引组合
            decsCombinations(equind, :) = [];
            labels(equind) = [];

            % 设置输出变量
            varargout = {decsCombinations,labels};
    end
elseif nargin == 4 % FR
    decs = varargin{1};         % x
    y = varargin{2};
    fitness  =   y(:,1);        % y
    cv  =   varargin{3};        %cv
    exploretype = varargin{4};  % type
    switch exploretype
        case 4
            % Calculate the length of the input vectors
            len_decs = size(decs, 1);
            % Generate all possible index combinations
            ind1 = combvec(1:len_decs, 1:len_decs);
            % Identify the indices where both elements are equal
            equind = ind1(1, :) == ind1(2, :);

            % Generate all possible combinations of decs and fitness
            decsCombinations = combvec(decs', decs')';
            cvCombinations = combvec(cv', cv')';
            % Initialize the label array
            labels = zeros(size(cvCombinations, 1), 1);

            % Assign labels based on the comparison result
            for i = 1:size(cvCombinations, 1)
                x1_cv = cvCombinations(i, 1);
                x2_cv = cvCombinations(i, 2);

                %用id，找到对应的fitness
                x1_fitness=fitness(ind1(1,i));
                x2_fitness=fitness(ind1(2,i));

                % 对比 x1 和 x2 的约束和距离
                if x1_cv <= 0 && x2_cv > 0      % x1 可行 x2 不可行
                    labels(i) = 1;
                elseif x1_cv > 0 && x2_cv <= 0  % x2 可行 x1 不可行
                    labels(i) = -1;
                elseif x1_cv <= 0 && x2_cv <= 0 % x1 和 x2 都可行
                    if x1_fitness < x2_fitness
                        labels(i) = 1;              %  x1 更稀疏
                    else
                        labels(i) = -1;             %  x2 更稀疏
                    end
                elseif x1_cv > 0 && x2_cv > 0   % x1 和 x2 都不可行
                    if x1_cv < x2_cv
                        labels(i) = 1;              % x1 的 cv 更小
                    else
                        labels(i) = -1;             % x2 的 cv 更小
                    end
                end
            end
            % 删除相等的索引组合
            decsCombinations(equind, :) = [];
            labels(equind) = [];

            % 设置输出变量
            varargout = {decsCombinations,labels};
    end
elseif nargin == 5
    decs = varargin{1};         % x
    y = varargin{2};
    fitness  =   y(:,1);        % y
    cv  =   varargin{3};        %cv
    exploretype = varargin{4};  % type
    dist =varargin{5};
    switch exploretype
        case 2
            % Calculate the length of the input vectors
            len_decs = size(decs, 1);
            % Generate all possible index combinations
            ind1 = combvec(1:len_decs, 1:len_decs);
            % Identify the indices where both elements are equal
            equind = ind1(1, :) == ind1(2, :);

            % Generate all possible combinations of decs and fitness
            decsCombinations = combvec(decs', decs')';
            cvCombinations = combvec(cv', cv')';
            % Initialize the label array
            labels = zeros(size(cvCombinations, 1), 1);

            % Assign labels based on the comparison result
            for i = 1:size(cvCombinations, 1)
                x1_cv = cvCombinations(i, 1);
                x2_cv = cvCombinations(i, 2);

                %用id，找到对应的dist(对应的稀疏度)
                x1_dist = dist(ind1(1,i));
                x2_dist = dist(ind1(2,i));

                % 对比 x1 和 x2 的约束和距离
                if x1_cv <= 0 && x2_cv > 0      % x1 可行 x2 不可行
                    labels(i) = 1;
                elseif x1_cv > 0 && x2_cv <= 0  % x2 可行 x1 不可行
                    labels(i) = -1;
                elseif x1_cv <= 0 && x2_cv <= 0 % x1 和 x2 都可行
                    if x1_dist >= x2_dist
                        labels(i) = 1;              %  x1 更稀疏
                    else
                        labels(i) = -1;             %  x2 更稀疏
                    end
                elseif x1_cv > 0 && x2_cv > 0   % x1 和 x2 都不可行
                    if x1_cv < x2_cv
                        labels(i) = 1;              % x1 的 cv 更小
                    else
                        labels(i) = -1;             % x2 的 cv 更小
                    end
                end
            end
            % 删除相等的索引组合
            decsCombinations(equind, :) = [];
            labels(equind) = [];

            % 设置输出变量
            varargout = {decsCombinations,labels};
    end
elseif nargin == 6
    decs = varargin{1};         % x
    y = varargin{2};
    fitness  =   y(:,1);        % y
    cv  =   varargin{3};        %cv
    exploretype = varargin{4};  % type
    dist =varargin{5};
    IDBetter = varargin{6};
    switch exploretype
        case 3
            % Calculate the length of the input vectors
            len_decs = size(decs, 1);
            % Generate all possible index combinations
            ind1 = combvec(1:len_decs, 1:len_decs);
            % Identify the indices where both elements are equal
            equind = ind1(1, :) == ind1(2, :);

            % Generate all possible combinations of decs and fitness
            decsCombinations = combvec(decs', decs')';
            cvCombinations = combvec(cv', cv')';
            % Initialize the label array
            labels = zeros(size(cvCombinations, 1), 1);

            % Assign labels based on the comparison result
            for i = 1:size(cvCombinations, 1)
                x1_better = IDBetter(ind1(1,i));
                x2_better = IDBetter(ind1(2,i));
                %用id，找到对应的dist(对应的稀疏度)
                x1_dist = dist(ind1(1,i));
                x2_dist = dist(ind1(2,i));
                
                x1_fitness=fitness(ind1(1,i));
                x2_fitness=fitness(ind1(2,i));

                % 对比 x1 和 x2 的约束和距离
                if x1_better == 1 && x2_better == 0      % x1 better， x2 non-better
                    labels(i) = 1;
                elseif x1_better == 0 && x2_better == 1  % x2 better x1 non-better
                    labels(i) = -1;
                elseif x1_better == 1 && x2_better == 1 % x1 和 x2 都better
                    if x1_dist >= x2_dist
                        labels(i) = 1;              %  x1 更稀疏
                    else
                        labels(i) = -1;             %  x2 更稀疏
                    end
                elseif x1_better == 0 && x2_better == 0   % x1 和 x2 都不better
                    if x1_fitness < x2_fitness
                        labels(i) = 1;              % y1 < y2
                    else
                        labels(i) = -1;             
                    end
                end
            end
            % 删除相等的索引组合
            decsCombinations(equind, :) = [];
            labels(equind) = [];

            % 设置输出变量
            varargout = {decsCombinations,labels};
    end
end
    
end

