function [ind, scores] = FitnessCriteriaUser(surrogate, Us, Xs)
    % FitnessCriteriaUser evaluates and ranks unlabelled samples based on their classification criteria scores.
    %
    % Inputs:
    %   surrogate - A struct representing the surrogate model used for prediction.
    %   Us - A matrix where each row represents an unlabelled decision vector.
    %   Xs - A matrix where each row represents a labelled decision vector.
    %
    % Outputs:
    %   ind - Indices of the unlabelled samples in Us, sorted by their scores in descending order.
    %   scores - A vector of scores for each unlabelled sample in Us.

    % 统计数量
    Xs_num = size(Xs, 1);
    Us_num = size(Us, 1);
    dim = size(Xs, 2); % 维度
    
    % 初始化 scores 向量
    scores = zeros(Us_num, 1);
    
    % 预分配存储预测数据
    pre_data = zeros(2 * Xs_num * Us_num, 2 * dim);
    
    % 构建预测数据
    for i = 1:Us_num
        original = (i - 1) * 2 * Xs_num;
        
        % 复制 Us(i, :) 以匹配 Xs 的大小
        Ui = repmat(Us(i, :), Xs_num, 1);
        
        % 组合数据
        pre_data(original + 1:original + Xs_num, :) = [Xs, Ui]; % Xs_Ui
        pre_data(original + Xs_num + 1:original + 2 * Xs_num, :) = [Ui, Xs]; % Ui_Xs
    end
    % 调用 surrogate 进行预测
    if strcmpi(surrogate.model_name, 'NN')
        % Normalize the data using the normalization structure from the surrogate model
        pre_data_nor = mapminmax('apply', pre_data', surrogate.nor_struct)';
    
        % Predict the outcomes using the surrogate model
        pre_out = surrogate.model(pre_data_nor')';
    elseif strcmpi(surrogate.model_name, 'CNN')
        pre_data = Convert2CNNInput(pre_data);
        pre_out  = classify(surrogate.model,pre_data);
        pre_out  = OneHotConvert(str2double(cellstr(pre_out)),1);
    else

    end
    % 计算每个未标记样本的得分
    for i = 1:Us_num
        C_SCORE = zeros(1, 2);
        original = (i - 1) * 2 * Xs_num;
    
        % 计算 Us(i, :) 与 Xs 组合的预测得分
        pre_XsUi = sum(pre_out(original + 1:original + Xs_num, :), 1) ./ Xs_num;
        C_SCORE(1) = C_SCORE(1) + pre_XsUi(2); 
        C_SCORE(2) = C_SCORE(2) + pre_XsUi(1);
    
        pre_UiXs = sum(pre_out(original + Xs_num + 1:original + 2 * Xs_num, :), 1) ./ Xs_num;
        C_SCORE(1) = C_SCORE(1) + pre_UiXs(1); 
        C_SCORE(2) = C_SCORE(2) + pre_UiXs(2);
    
        % 计算最终得分
        scores(i) = C_SCORE(1) - C_SCORE(2);
    end


    % 返回变量
     % Sort the unlabelled samples based on their scores in descending order
    [sc, ind] = sort(scores, 'descend');
    

end

