function [Row_Select, improvement, haveaward_out] = IfImprovement(strategyType, feasibilityCurrent, DATA, FEs, bestObjCVCurrent, haveaward_in)
% selectImprovementStrategy - 根据不同策略判断当前评估是否为改进
%
% 输入:
%   strategyType       - (integer) 策略类型:
%                          1: 未注释的原始策略
%                          2: 注释掉的策略 (基于0.01的改进阈值和奖励机制)
%   feasibilityCurrent - (logical) 当前解是否可行
%   DATA               - (struct) 包含评估数据的结构体，至少需要:
%                          DATA.y    : (matrix) 目标函数值历史，每行对应一次评估
%                          DATA.CVsum: (matrix) 约束违反总和历史，每行对应一次评估
%   FEs                - (integer) 当前的函数评估次数 (current function evaluations)
%   bestObjCVCurrent   - (double) 当前为止最佳的约束违反总和 (用于不可行解的比较)
%   haveaward_in       - (logical) (仅用于策略2) 是否已经给予过“奖励”
%
% 输出:
%   Row_Select         - (integer or NaN) 如果有改进，则为当前 FEs；否则为 NaN
%   improvement        - (logical) 是否有改进
%   haveaward_out      - (logical) (仅用于策略2后) 更新后的 haveaward 状态

% 初始化输出
Row_Select = NaN; % 使用 NaN 表示未选择，可以根据需要改成 FEs 或其他默认值
improvement = false;
if nargin < 6 % 如果未提供 haveaward_in (例如策略1不需要它)
    haveaward_in = false; % 提供一个默认值
end
haveaward_out = haveaward_in; % 默认情况下，输出的 haveaward 与输入相同

switch strategyType
    case 1
        if feasibilityCurrent
            if DATA.y(FEs,1) < bestObjCVCurrent
                Row_Select = FEs;
                improvement = true;
            end
        else % 无可行解
            if DATA.CVsum(FEs,1) < bestObjCVCurrent % CVsum通常是标量，所以使用 DATA.CVsum(FEs,1)
                Row_Select = FEs;
                improvement = true;
            end
        end
    case 2 
        if feasibilityCurrent
            previous_objectives = DATA.y(1:FEs-1,1);
            bestObj = min(previous_objectives);
            if DATA.y(FEs,1) < bestObj
                Row_Select = FEs;
                improvement = true;
            end
        else % 无可行解
            if DATA.CVsum(FEs,1) < bestObjCVCurrent % CVsum通常是标量，所以使用 DATA.CVsum(FEs,1)
                Row_Select = FEs;
                improvement = true;
            end
        end
    
    case 3
        if feasibilityCurrent
            previous_objectives = DATA.y(1:FEs-1,1);
            bestObj = min(previous_objectives);
            if DATA.y(FEs,1) < bestObj
                yimp = bestObj - DATA.y(FEs,1);
                % 避免 bestObj 为 0 或非常小时 yimp_relative 除以0或过大
                if bestObj ~= 0 % 或者 abs(bestObj) > eps
                    yimp_relative = yimp / abs(bestObj); % 使用 abs(bestObj) 避免负目标值问题
                elseif yimp > 0 % bestObj is 0, current is better (negative)
                    yimp_relative = Inf;
                else
                    yimp_relative = 0;
                end

                if ~haveaward_in
                    Row_Select = FEs;
                    improvement = true;
                    haveaward_out = true;
                elseif yimp_relative > 0.01
                    Row_Select = FEs;
                    improvement = true;
                    % haveaward_out 保持不变 (如果之前是 true，则仍是 true)
                    % 如果希望每次显著改进都重置/重新授予“奖励”，则需调整haveaward_out的逻辑
                end
            end
        else % 不可行
            if DATA.CVsum(FEs,1) < bestObjCVCurrent % CVsum通常是标量
                yimp = bestObjCVCurrent - DATA.CVsum(FEs,1);
                if bestObjCVCurrent ~= 0 % 或者 abs(bestObjCVCurrent) > eps
                    yimp_relative = yimp / abs(bestObjCVCurrent);
                elseif yimp > 0 % bestObjCVCurrent is 0, current CV is better (negative, though unusual for CV)
                    yimp_relative = Inf;
                else
                    yimp_relative = 0;
                end

                if ~haveaward_in
                    Row_Select = FEs;
                    improvement = true;
                    haveaward_out = true;
                elseif yimp_relative > 0.01
                    Row_Select = FEs;
                    improvement = true;
                    % haveaward_out 保持不变
                end
            end
        end

    otherwise
        warning('未知的策略类型。');
end

end