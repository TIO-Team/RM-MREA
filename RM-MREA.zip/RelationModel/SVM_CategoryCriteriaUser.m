    function [ind, scores] = SVM_CategoryCriteriaUser(surrogate, Us, Xs, catalog,UsDist)
    % CategoryCriteriaUser Evaluates and ranks unlabelled samples based on their classification criteria scores.
    %
    % Inputs:
    %   surrogate - A struct representing the surrogate model used for prediction.
    %   Us - A matrix where each row represents an unlabelled decision vector.
    %   Xs - A matrix where each row represents a labelled decision vector.
    %   catalog - A vector indicating the category of each decision vector in Xs.
    %
    % Outputs:
    %   ind - Indices of the unlabelled samples in Us, sorted by their scores in descending order.
    %   scores - A vector of scores for each unlabelled sample in Us.

    % Separate positive and negative samples based on the catalog
    Xp = Xs(catalog == 1, :);
    Xn = Xs(catalog ~= 1, :);

    % Count the number of positive and negative samples
    Xp_num = size(Xp, 1);
    Xn_num = size(Xn, 1);
    Us_num = size(Us, 1);

    % Initialize the scores vector for unlabelled samples
    scores = zeros(Us_num, 1);

    % Pre-allocate memory for the data to be predicted
    pre_data = zeros(2 * (Xp_num + Xn_num) * Us_num, 2 * size(Xp, 2));

    % Construct the data for prediction by combining Us with Xp and Xn in all possible ways
    for i = 1:Us_num
        original = (i - 1) * 2 * (Xp_num + Xn_num);

        % Combine Us with Xp
        Ui = repmat(Us(i, :), Xp_num, 1);
        pre_data(original + 1:original + Xp_num, :) = [Xp, Ui]; % Xp_Ui
        pre_data(original + 1 + Xp_num:original + Xp_num * 2, :) = [Ui, Xp]; % Ui_Xp

        % Combine Us with Xn
        Ui = repmat(Us(i, :), Xn_num, 1);
        pre_data(original + 1 + Xp_num * 2:original + Xp_num * 2 + Xn_num, :) = [Xn, Ui]; % Xn_Ui
        pre_data(original + 1 + Xn_num + Xp_num * 2:original + Xn_num * 2 + Xp_num * 2, :) = [Ui, Xn]; % Ui_Xn
    end

    [score,~] = predict(surrogate, pre_data);
    % [~, score] = predict(surrogate.model, pre_data);
    % score is typically a matrix with the second column being the decision values
    pre_out = score(:, 1);  % Assuming the second column corresponds to class 1 or the positive class score
    pre_out = OneHotConvert(pre_out, 1);


    % Calculate scores for each unlabelled sample by aggregating the predictions
    for i = 1:Us_num
        C_SCORE = zeros(1, 2);
        original = (i - 1) * 2 * (Xp_num + Xn_num);
        
        % Aggregate predictions for combinations with Xp
        pre_XpUi = sum(pre_out(original + 1:original + Xp_num, :), 1) ./ Xp_num;
        C_SCORE(1) = C_SCORE(1) + pre_XpUi(2) + pre_XpUi(3);
        C_SCORE(2) = C_SCORE(2) + pre_XpUi(1);

        pre_UiXp = sum(pre_out(original + 1 + Xp_num:original + Xp_num * 2, :), 1) ./ Xp_num;
        C_SCORE(1) = C_SCORE(1) + pre_UiXp(2) + pre_UiXp(1);
        C_SCORE(2) = C_SCORE(2) + pre_UiXp(3);

        % Aggregate predictions for combinations with Xn
        pre_XnUi = sum(pre_out(original + 1 + Xp_num * 2:original + Xp_num * 2 + Xn_num, :), 1) ./ Xn_num;
        C_SCORE(1) = C_SCORE(1) + pre_XnUi(3);
        C_SCORE(2) = C_SCORE(2) + pre_XnUi(2) + pre_XnUi(1);

        pre_UiXn = sum(pre_out(original + 1 + Xn_num + Xp_num * 2:original + Xn_num * 2 + Xp_num * 2, :), 1) ./ Xn_num;
        C_SCORE(1) = C_SCORE(1) + pre_UiXn(1);
        C_SCORE(2) = C_SCORE(2) + pre_UiXn(2) + pre_UiXn(3);

        % Calculate the final score for each unlabelled sample
        scores(i) = C_SCORE(1) - C_SCORE(2);
    end

    % Sort the unlabelled samples based on their scores in descending order
    [sc, ind] = sort(scores, 'descend');
     

    
    n_total = length(sc);
    min_required = max(1, ceil(n_total * 0.01));  % 至少1个，确保数量达到 1%
    thresholds = [4, 3, 2, 1];  % 阈值列表
    selected = false;  % 标记是否已选中解
    
    for thresh = thresholds
        valid_idx = find(sc >= thresh);
        if length(valid_idx) >= min_required
            % 如果符合当前阈值的解数量达到 n_total 的 1%，按稀疏度排序并返回
            selected_sc = sc(valid_idx);
            selected_ind = ind(valid_idx);
            selected_dist = UsDist(valid_idx);  % 获取对应样本的稀疏度
            
            % 根据稀疏度排序（假设更大的 UsDist 值表示更稀疏）
            [~, sparse_order] = sort(selected_dist, 'descend');
            sc = selected_sc(sparse_order);
            ind = selected_ind(sparse_order);
            selected = true;
            break;  % 找到后退出循环
        end
    end
    
    if ~selected
        
    end
    
    scores = sc;  % 更新scores输出为筛选后的值
    
end
