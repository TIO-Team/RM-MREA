function [y_hat, objVal_hat, consGVal_hat, consHVal_hat, consGHVal_hat, CV_hat] = predictCal_CNN(X, Model, num_g, num_h, toleranceG, toleranceH, CVType)

    % **Step 1:** 通过 CNN 进行预测
    y_hat = classify(Model.model, X);

    % **Step 2:** 拆分 CNN 输出
    objVal_hat    = y_hat(:,1);                  % 目标值
    consGVal_hat  = y_hat(:,2:1+num_g);          % 不等式约束值
    consHVal_hat  = y_hat(:,1+num_g+1:end);      % 等式约束值

    % **Step 3:** 校正约束值
    [consGVal_hat, consHVal_hat] = corrConVal(consGVal_hat, consHVal_hat, num_g, num_h);

    % **Step 4:** 计算约束值向量
    consGHVal_hat = [consGVal_hat, consHVal_hat];

    % **Step 5:** 计算 CV (约束违背度)
    CV_hat = CVCal0(consGVal_hat, consHVal_hat, toleranceG, toleranceH, CVType);

    
end
