% --------------- 新的辅助函数：visualizeProblemAndSamples ---------------
function visualizeProblemAndSamples(problem, fnum, Dim, lowerB, upperB, num_g, num_h, DATA, num_samples_to_plot, toleranceG, toleranceH, CVType)
    % problem: 函数句柄
    % fnum: 问题编号
    % Dim: 维度
    % lowerB, upperB: 变量边界 (Dim x 1 或 1 x Dim)
    % num_g, num_h: 不等式和等式约束的数量
    % DATA: 包含已评估点信息的结构体 (DATA.x, DATA.y, DATA.CVsum)
    % num_samples_to_plot: 要在图上绘制的初始样本数量
    % toleranceG, toleranceH, CVType: 用于计算可行性的参数 (可选，用于点着色)

    fprintf('正在尝试可视化问题和初始样本...\n');

    if Dim > 2
        fprintf('警告: 维度 (%d) 大于2，无法直接可视化函数曲面。\n', Dim);
        fprintf('将仅绘制初始样本的目标值和总约束违反。\n');

        figure;
        subplot(2,1,1);
        plot(1:num_samples_to_plot, DATA.y(1:num_samples_to_plot,1), 'bo-');
        title(['初始样本的目标函数值 (前 ', num2str(num_samples_to_plot), ' 个)']);
        xlabel('样本索引');
        ylabel('目标值');
        grid on;

        subplot(2,1,2);
        plot(1:num_samples_to_plot, DATA.CVsum(1:num_samples_to_plot,1), 'ro-');
        title(['初始样本的总约束违反 (前 ', num2str(num_samples_to_plot), ' 个)']);
        xlabel('样本索引');
        ylabel('总约束违反 (CVsum)');
        grid on;
        return;
    end

    % --- 为1D或2D问题生成网格 ---
    n_grid_points_per_dim = 50; % 网格密度，可调整
    if Dim == 1
        x_grid = linspace(lowerB(1), upperB(1), n_grid_points_per_dim)';
        plot_grid_points = x_grid;
    else % Dim == 2
        x1_range = linspace(lowerB(1), upperB(1), n_grid_points_per_dim);
        x2_range = linspace(lowerB(2), upperB(2), n_grid_points_per_dim);
        [X1_grid, X2_grid] = meshgrid(x1_range, x2_range);
        plot_grid_points = [X1_grid(:), X2_grid(:)];
    end

    % --- 评估网格上的函数 ---
    % 确保 problem 函数可以处理 fnum
    try
        [obj_grid, g_grid, h_grid] = problem(plot_grid_points, fnum);
        [g_grid, h_grid] = corrConVal(g_grid, h_grid, num_g, num_h); % 校正约束值
    catch ME
        fprintf('错误：在评估网格点时调用 problem 函数失败: %s\n', ME.message);
        fprintf('请确保 problem 函数句柄正确，并且 fnum (%d) 是有效的。\n', fnum);
        return;
    end


    % --- 绘制目标函数 ---
    figure;
    if Dim == 1
        subplot(1 + num_g + num_h, 1, 1); % 为目标和每个约束创建子图
        plot(x_grid, obj_grid, 'k-', 'LineWidth', 1.5);
        hold on;
        % 绘制初始样本点
        feasible_idx = DATA.CVsum(1:num_samples_to_plot,1) == 0; % 简单可行性判断
        infeasible_idx = ~feasible_idx;

        if any(feasible_idx)
            plot(DATA.x(find(feasible_idx, num_samples_to_plot), 1), DATA.y(find(feasible_idx, num_samples_to_plot), 1), 'go', 'MarkerFaceColor', 'g', 'DisplayName', '可行初始点');
        end
        if any(infeasible_idx)
             plot(DATA.x(find(infeasible_idx, num_samples_to_plot), 1), DATA.y(find(infeasible_idx, num_samples_to_plot), 1), 'ro', 'MarkerFaceColor', 'r', 'DisplayName', '不可行初始点');
        end
        title(['目标函数 (f', num2str(fnum), ')']); xlabel('x1'); ylabel('f(x)');
        legend show;
        grid on;
        hold off;
    else % Dim == 2
        obj_surf = reshape(obj_grid, size(X1_grid));
        subplot(1, 1 + num_g + num_h, 1);
        surf(X1_grid, X2_grid, obj_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
        colorbar;
        hold on;
        % 绘制初始样本点
        feasible_idx = DATA.CVsum(1:num_samples_to_plot,1) == 0;
        infeasible_idx = ~feasible_idx;

        if any(feasible_idx)
            plot3(DATA.x(find(feasible_idx, num_samples_to_plot), 1), DATA.x(find(feasible_idx, num_samples_to_plot), 2), DATA.y(find(feasible_idx, num_samples_to_plot), 1), 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g', 'DisplayName', '可行初始点');
        end
        if any(infeasible_idx)
             plot3(DATA.x(find(infeasible_idx, num_samples_to_plot), 1), DATA.x(find(infeasible_idx, num_samples_to_plot), 2), DATA.y(find(infeasible_idx, num_samples_to_plot), 1), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'DisplayName', '不可行初始点');
        end
        title(['目标函数 (f', num2str(fnum), ')']); xlabel('x1'); ylabel('x2'); zlabel('f(x)');
        legend show;
        view(3); % 3D视角
        grid on;
        hold off;
    end

    % --- 绘制约束函数 (g) ---
    for i = 1:num_g
        if Dim == 1
            subplot(1 + num_g + num_h, 1, 1+i);
            plot(x_grid, g_grid(:,i), 'b-', 'LineWidth', 1.5);
            hold on;
            yline(toleranceG, 'r--', 'LineWidth', 1, 'DisplayName', ['g <= ', num2str(toleranceG)]); % 约束边界线
            % 绘制初始样本点对应的约束值
            plot(DATA.x(1:num_samples_to_plot, 1), DATA.y(1:num_samples_to_plot, 1+i), 'mo', 'DisplayName', '初始点约束值');
            title(['不等式约束 g', num2str(i), '(x)']); xlabel('x1'); ylabel(['g', num2str(i)]);
            legend show;
            grid on;
            hold off;
        else % Dim == 2
            g_surf = reshape(g_grid(:,i), size(X1_grid));
            subplot(1, 1 + num_g + num_h, 1+i);
            surf(X1_grid, X2_grid, g_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
            colorbar;
            hold on;
            % 可选：绘制 g(x) = toleranceG 的等高线
            contour3(X1_grid, X2_grid, g_surf, [toleranceG toleranceG], 'r--', 'LineWidth', 2, 'DisplayName', ['g <= ', num2str(toleranceG)]);
             % 绘制初始样本点对应的约束值 (可能需要调整Z轴使其可见)
            % plot3(DATA.x(1:num_samples_to_plot,1), DATA.x(1:num_samples_to_plot,2), DATA.y(1:num_samples_to_plot, 1+i), 'mo', 'MarkerSize', 8, 'DisplayName', '初始点约束值');
            title(['不等式约束 g', num2str(i), '(x)']); xlabel('x1'); ylabel('x2'); zlabel(['g', num2str(i)]);
            legend show;
            view(3);
            grid on;
            hold off;
        end
    end

    % --- 绘制约束函数 (h) ---
    for i = 1:num_h
        if Dim == 1
            subplot(1 + num_g + num_h, 1, 1+num_g+i);
            plot(x_grid, h_grid(:,i), 'm-', 'LineWidth', 1.5);
            hold on;
            yline(toleranceH, 'r--', 'LineWidth', 1, 'DisplayName', ['|h| <= ', num2str(toleranceH)]); % 上边界
            yline(-toleranceH, 'r--', 'LineWidth', 1); % 下边界
            plot(DATA.x(1:num_samples_to_plot, 1), DATA.y(1:num_samples_to_plot, 1+num_g+i), 'co', 'DisplayName', '初始点约束值');
            title(['等式约束 h', num2str(i), '(x) (目标: |h| <= tol)']); xlabel('x1'); ylabel(['h', num2str(i)]);
            legend show;
            grid on;
            hold off;
        else % Dim == 2
            h_surf = reshape(h_grid(:,i), size(X1_grid));
            subplot(1, 1 + num_g + num_h, 1+num_g+i);
            surf(X1_grid, X2_grid, h_surf, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
            colorbar;
            hold on;
            % 可选：绘制 |h(x)| = toleranceH 的等高线 (这会是两条线 h=tol 和 h=-tol)
            contour3(X1_grid, X2_grid, h_surf, [toleranceH toleranceH], 'r--', 'LineWidth', 2, 'DisplayName', ['|h| <= ', num2str(toleranceH)]);
            contour3(X1_grid, X2_grid, h_surf, [-toleranceH -toleranceH], 'r--', 'LineWidth', 2);
            % plot3(DATA.x(1:num_samples_to_plot,1), DATA.x(1:num_samples_to_plot,2), DATA.y(1:num_samples_to_plot, 1+num_g+i), 'co', 'MarkerSize', 8, 'DisplayName', '初始点约束值');
            title(['等式约束 h', num2str(i), '(x) (目标: |h| <= tol)']); xlabel('x1'); ylabel('x2'); zlabel(['h', num2str(i)]);
            legend show;
            view(3);
            grid on;
            hold off;
        end
    end
    sgtitle(['问题 f', num2str(fnum), ' (Dim=', num2str(Dim), ') 函数和初始样本 (', num2str(num_samples_to_plot), ' 个)']);
    fprintf('可视化完成。\n');
end
