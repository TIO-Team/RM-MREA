function [CV,consGVal_virtual,consHVal_virtual]=CVCal(POP,obj,consG,consH,toleranceG,toleranceH,CVType)

if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end
[consGVal,consHVal]=consCal(POP,obj,consG,consH);
CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
% for setting CVCal as an objective function
consGVal_virtual=zeros(length(CV),0);
consHVal_virtual=zeros(length(CV),0);
end