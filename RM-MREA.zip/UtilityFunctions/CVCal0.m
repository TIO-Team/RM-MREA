function CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType)

if nargin<3 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<4 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<5 || isempty(CVType)
    CVType=1;
end

if isempty(consGVal)
    consGVal = 0;
end
if isempty(consHVal)
    consHVal = 0;
end


switch CVType
    case{1}
        CV = sum(max(consGVal,0),2)+sum(max(abs(consHVal)-toleranceH,0),2);
    case{2}
        CV = sum(max(consGVal-toleranceG,0),2)+sum(max(abs(consHVal)-toleranceH,0),2);
end
end