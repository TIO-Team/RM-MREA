function epsilon = EpsilonAdapt(epsilon0,Gen,MaxGen,p)
if nargin < 4 || isempty(p)
    p = 0.5;
end
if Gen/MaxGen < p
    % epsilon0 = max(CV) for the initial
    delta   = 6;
    cp      = - (log(epsilon0)+delta)/log(1-p);
    epsilon = epsilon0 * (1-Gen/MaxGen)^cp;
%     cp      = 1;
%     epsilon = epsilon0 * (1-Gen/(p*MaxGen))^cp;
else
    epsilon = 0; % 1e-3
end
