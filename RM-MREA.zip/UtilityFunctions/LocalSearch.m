function [xTemp,objVal,CV]=LocalSearch(x,obj,consG,consH,Lower,Upper,maxFunEva,toleranceG,toleranceH,algorithmLocalSeach,CVType)

if nargin<7 || isempty(maxFunEva)
    maxFunEva=300;
end
if nargin<8 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<9 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<10 || isempty(algorithmLocalSeach)
    algorithmLocalSeach='sqp'; % 'interior-point';  'sqp'; 'trust-region-reflective';
end
if nargin<11 || isempty(CVType)
    CVType=1;
end
nonlcons=@(x) consCal(x,obj,consG,consH,toleranceG,toleranceH,CVType);
options = optimset('Algorithm', algorithmLocalSeach, 'MaxFunEvals', maxFunEva, 'Display', 'off');
[xTemp,objVal]=fmincon(obj,x,[],[],[],[],Lower,Upper,nonlcons,options);
if any(xTemp< Lower) || any(xTemp > Upper)
    xTemp(xTemp < Lower) = Lower(xTemp <Lower);
    xTemp(xTemp > Upper) = Upper(xTemp > Upper);
    objVal = obj(xTemp);
end
CV=CVCal(xTemp,obj,consG,consH,toleranceG,toleranceH,CVType);
end