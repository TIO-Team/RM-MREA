function fitWeight = RankWeight(Rank1, Rank2, weights)
if max(size(weights)) == 1
   w1 = weights;
   w2 = weights;
else
    w1 = weights(1);
    w2 = weights(2);
end
fitWeight = w1*Rank1 + w2* Rank2;