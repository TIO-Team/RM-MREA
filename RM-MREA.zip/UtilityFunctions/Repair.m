function POP = Repair(POP, Lower, Upper, RepairType)
if nargin < 4
    RepairType = 3;
end
NP = size(POP,1);

LowerB=ones(NP,1)*Lower;
UpperB=ones(NP,1)*Upper;

switch RepairType
    case{1, 'BackReflect'}
        siteXLowerB= POP < LowerB;
        siteXUpperB= POP > UpperB;
        
        POP(siteXLowerB)= min( 2*LowerB(siteXLowerB)-POP(siteXLowerB),UpperB(siteXLowerB));
        POP(siteXUpperB)= max( 2*UpperB(siteXUpperB)-POP(siteXUpperB),LowerB(siteXUpperB));
        
    case{2, 'Absorb'}
        POP = min(max(POP,LowerB),UpperB);
        
    case{3, 'Random'}
        if rand <= 0.9
            POP = Repair(POP, Lower, Upper, 'BackReflect');
        else
            POP = Repair(POP, Lower, Upper, 'Absorb');
        end
end