function Offspring=ReproduceDE(Parent,Lower,Upper, MuteType,FPool,CRPool, RepairType, ParentBest)


% PreProcess
[NP, Dim]=size(Parent);

% default F and CR
sameF_2Term     = true; % Whether F is same in the two term
sameF_AllDim    = true; % Whether F is same dimension-wise
sameCR_AllDim   = true; % Whether CR is same dimension-wise
selectFInFPool  = true; % Whether F in a given F pool
selectCRInCRPool= true; % Whether CR in a given CR pool

FPool0=[0.6,0.8,1];     % Default F pool
CRPool0=[0.1,0.2,1];    % Default CR pool
if nargin<4|| isempty(MuteType)
    MuteType=5;
end

if nargin<5 || isempty(FPool)
    FPool=FPool0;
end

if nargin<6 || isempty(CRPool)
    CRPool=CRPool0;
end

if nargin<7 || isempty(RepairType)
    RepairType=1;
end

% Generate F, CR, rand random individual index for operaton
%---F
FLength= length(FPool);
if selectFInFPool
    if FLength==1
        F1=FPool;
        F2=FPool;
    else
        if sameF_AllDim
            F1Site=randi(FLength, NP, 1)*ones(1,Dim);
            F2Site=randi(FLength, NP, 1)*ones(1,Dim);
        else
            F1Site=randi(FLength, NP, Dim);
            F2Site=randi(FLength, NP, Dim);
        end
        F1=FPool(F1Site);
        if sameF_2Term
            F2=F1;
        else
            F2=FPool(F2Site);
        end
        
    end
else
    if sameF_AllDim
        F1=0.5+rand(NP,1)*ones(1,Dim);
        F2=0.5+rand(NP,1)*ones(1,Dim);
    else   
        F1=0.5+rand(NP,Dim);
        F2=0.5+rand(NP,Dim);
    end
    if sameF_2Term
        F2=F1;
    end
end
%---CR
CRLength= length(CRPool);
if selectCRInCRPool
    if CRLength==1
        CR=CRPool;
    else
        if sameCR_AllDim
            CRSite=randi(CRLength,NP,1)*ones(1,Dim);
        else
            CRSite=randi(CRLength,NP,Dim);
        end
        CR=CRPool(CRSite);
    end
else
    if sameCR_AllDim
        CR=0.5+0.5*rand(NP,1)*ones(1,Dim);
    else
        CR=0.5+0.5*rand(NP,Dim);
    end
end

randomSubscript=zeros(NP,5);
for ii=1:NP
    randomSubscript0=randperm(NP);
    indexEqualii= randomSubscript0(1:5)==ii;
    randomSubscript0(indexEqualii)=randomSubscript0(6);
    randomSubscript(ii,:)=randomSubscript0(1:5);
end
%---X sites
SiteX= rand(NP,Dim)< CR;
jRow=find(~any(SiteX,2));
njRow=length(jRow);
if njRow>0
    temp=reshape(randperm(njRow*Dim),njRow,Dim);
    SiteX(jRow,:)= temp>=max(temp,[],2);
end
%% Mutant
switch MuteType
    case {1, 'Current2Random1/1'}
        IsCrossOver=false;
              
        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent+F1.*(Parent(r1,:)-Parent)+F2.*(Parent(r2,:)-Parent(r3,:));        
    case {2, 'Current2Random2/1'}
        IsCrossOver=false;
        
        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent+rand(NP,Dim).*(Parent(r1,:)-Parent)+F2.*(Parent(r2,:)-Parent(r3,:)); 
    case {3, 'Random2PBest1/1' }
        IsCrossOver=true;

        nPbest = size(ParentBest,1);
        PbestTeach = ParentBest(randi(nPbest,NP,1),:);

        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent(r1,:)+rand(NP,Dim).*(PbestTeach-Parent(r1,:))+F2.*(Parent(r2,:)-Parent(r3,:));
    case {4, 'Random2PBest2/1'}
        IsCrossOver=true;

        nPbest = size(ParentBest,1);
        PbestTeach = ParentBest(randi(nPbest,NP,1),:);

        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent(r1,:)+F1.*(PbestTeach-Parent(r1,:))+F2.*(Parent(r2,:)-Parent(r3,:));
    case {5, 'Random/1'}
        IsCrossOver=true;
        
        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent(r1,:)+F1.*(Parent(r2,:)-Parent(r3,:));
    case {6, 'Random/2'}
        IsCrossOver=true;
        
        r1=randomSubscript(:,1);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        r4=randomSubscript(:,4);
        r5=randomSubscript(:,5);
        Offspring=Parent(r1,:)+F1.*(Parent(r2,:)-Parent(r3,:))+F2.*(Parent(r4,:)-Parent(r5,:));

    case {7,'Current2Pbest/1'}
        IsCrossOver=true;

        nPbest = size(ParentBest,1);
        PbestTeach = ParentBest(randi(nPbest,NP,1),:);
        r2=randomSubscript(:,2);
        r3=randomSubscript(:,3);
        Offspring=Parent + F1.*(PbestTeach-Parent)+F2.*(Parent(r2,:)-Parent(r3,:));
end
%% Crossover
if IsCrossOver
    Offspring(~SiteX)=Parent(~SiteX);
end
%% Repair
Lower=ones(NP,1)*Lower;
Upper=ones(NP,1)*Upper;

switch RepairType
    case{1, 'BackReflect'}
        siteXLower= Offspring < Lower;
        siteXUpper= Offspring > Upper;
        
        Offspring(siteXLower)= min( 2*Lower(siteXLower)-Offspring(siteXLower),Upper(siteXLower));
        Offspring(siteXUpper)= max( 2*Upper(siteXUpper)-Offspring(siteXUpper),Lower(siteXUpper));
        
    case{2, 'Absorb'}
        Offspring = min(max(Offspring,Lower),Upper);
end