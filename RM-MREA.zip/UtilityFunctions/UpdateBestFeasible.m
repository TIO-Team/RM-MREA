function [site,objVal_bestFeasible,feasibility]=UpdateBestFeasible(siteOld,objOld,sitesNew,objNew,consGNew,consHNew,toleranceG,toleranceH)
if nargin<7 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<8 || isempty(toleranceH)
    toleranceH=1e-5;
end
NP=size(sitesNew,1);
if isempty(consGNew)
    consGNew=zeros(NP,1);
end
if isempty(consHNew)
    consHNew=zeros(NP,1);
end
CV=sum(max(consGNew-toleranceG,0),2)+sum(max(abs(consHNew)-toleranceH,0),2);

feasible= CV==0;
if any(feasible)
    bestIndi= objNew== min(objNew(feasible));
    bestIndi(~feasible)=false;
    objNew_best=objNew(bestIndi);
    feasibility=true;
    
    if objNew_best(1)<objOld
        tempSite=sitesNew(bestIndi,:);
        site=tempSite(1,:);
        objVal_bestFeasible=objNew_best(1);
    else
        site=siteOld;
        objVal_bestFeasible=objOld;
    end
else
    feasibility=false;
    site=siteOld;
    objVal_bestFeasible=objOld;
end
end