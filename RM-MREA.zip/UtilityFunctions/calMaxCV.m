function CV = calMaxCV(GHValue,num_g,num_h,toleranceG, toleranceH)

if num_g == 0
    CV_G = [];
else
    GValue = GHValue(:,1:num_g);
    CV_G   = max(GValue-toleranceG,0);
end

if num_h == 0
    CV_H = [];
else
    HValue = GHValue(:,end-num_h+1:end);
    CV_H   = max(abs(HValue)-toleranceH,0);
end
CV = [CV_G,CV_H];

