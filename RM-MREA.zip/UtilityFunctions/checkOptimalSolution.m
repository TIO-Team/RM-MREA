function isOptimal = checkOptimalSolution(fnum, bestObjCVCurrent, feasibilityCurrent)
% 检查是否找到了已知的最优解
% 输入：
%   fnum - 问题编号
%   bestObjCVCurrent - 当前最优目标值或约束违反值
%   feasibilityCurrent - 当前解的可行性
% 输出：
%   isOptimal - 是否为最优解

% 定义容差
tolerance =1e-10;

% 定义已知最优解
optimal_solutions = containers.Map('KeyType', 'int32', 'ValueType', 'double');

% 问题1,3:33,45:57的最优解
optimal_solutions(1) = 189.3116297;%189.3116297
optimal_solutions(3) = -4529.11974;
optimal_solutions(4) = -0.388260436;
optimal_solutions(5) = -400.0056;
optimal_solutions(6) = 1.863830409;
optimal_solutions(7) = 1.5670451;
optimal_solutions(8) = 2;
optimal_solutions(9) = 2.557654574;
optimal_solutions(10) = 1.176543083;
optimal_solutions(11) = 99.23846365;
optimal_solutions(12) = 2.924830554;
optimal_solutions(13) = 26887;
optimal_solutions(14) = 53638.94272;
optimal_solutions(15) = 2994.4244658;
optimal_solutions(16) = 0.032213001;%0.032213001
optimal_solutions(17) = 0.012665232788;
optimal_solutions(18) = 5885.332774;
optimal_solutions(19) = 1.670217726;
optimal_solutions(20) = 263.8958434;
optimal_solutions(21) = 0.235242458;
optimal_solutions(22) = 0.525768707;
optimal_solutions(23) = -16.06986873;
optimal_solutions(24) = 2.528791842;
optimal_solutions(25) = 1616.119765;
optimal_solutions(26) = 35.35923197;
optimal_solutions(27) = 524.4507607;
optimal_solutions(28) = 14614.13572;%14614.13572
optimal_solutions(29) = 2964895.417;
optimal_solutions(30) = 2.613884058;
optimal_solutions(31) = 0;
optimal_solutions(32) = -30666.53867;
optimal_solutions(33) = 2.639346497;%2.639346497
optimal_solutions(45) = 0.03073936;
optimal_solutions(46) = 0.020240335;
optimal_solutions(47) = 0.012783068;
optimal_solutions(48) = 0.016787536;
optimal_solutions(49) = 0.009311874;
optimal_solutions(50) = 0.01505147;
optimal_solutions(51) = 4550.85115;
optimal_solutions(52) = 3348.982149;
optimal_solutions(53) = 4997.606929;
optimal_solutions(54) = 4240.548254;
optimal_solutions(55) = 6696.414513;
optimal_solutions(56) = 14746.58;
optimal_solutions(57) = 3213.291702;

% 检查是否为目标问题
if ~isKey(optimal_solutions, fnum)
    isOptimal = false;
    return;
end

% 获取目标最优值
target_optimal = optimal_solutions(fnum);

% 检查是否为可行解且目标值接近最优值
if feasibilityCurrent && abs(bestObjCVCurrent - target_optimal) <= tolerance
    isOptimal = true;
elseif feasibilityCurrent && bestObjCVCurrent < target_optimal
    isOptimal = true;
else
    isOptimal = false;
end

end
