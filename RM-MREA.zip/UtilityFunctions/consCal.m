function [consGVal,consHVal]=consCal(POP,obj,consG,consH,toleranceG,toleranceH,CVType)
if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end

NP=size(POP,1);
if isnumeric(consG) && isnumeric(consH)
    [~,consGVal,consHVal]=obj(POP);
    if isempty(consGVal)
        consGVal=zeros(NP,1);
    end
    if isempty(consHVal)
        consHVal=zeros(NP,1);
    end
else
    consGVal=funcAll(consG,POP);
    consHVal=funcAll(consH,POP);
end
consGVal(consGVal == -inf) = 0;
% No recomendation for the following
% if nargin>4
%     CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
%     consGVal(CV==0,:)=0;
%     consHVal(CV==0,:)=0;
% end
% if nargin>4 && CVType==2
%     consGVal=consGVal-toleranceG;
%     consHVal=sign(consHVal).*(abs(consHVal)-toleranceH);
% elseif nargin>4 && CVType==1% approximate
%     num_cons=length(consGVal(1,:))+length(consHVal(1,:));
%     consGVal=consGVal-toleranceG/num_cons;
%     consHVal=sign(consHVal).*(abs(consHVal)-toleranceG/num_cons);
% end
end