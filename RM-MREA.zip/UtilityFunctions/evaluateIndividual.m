function [objVal,consGVal,consHVal]=evaluateIndividual(POP,obj,consG,consH)
% consG and consH are cell of function handles or function handle
% If consG and consH are numerical, obj will encompass all the functions

NP=size(POP,1);
if isnumeric(consG) && isnumeric(consH)
    [objVal,consGVal,consHVal]=obj(POP);
    if isempty(consGVal)
        consGVal=zeros(NP,1);
    end
    if isempty(consHVal)
        consHVal=zeros(NP,1);
    end
else
    objVal=obj(POP);
    consGVal=funcAll(consG,POP);
    consHVal=funcAll(consH,POP);
end
end