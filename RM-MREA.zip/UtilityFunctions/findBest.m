function [bestIndOutput, bestObjCVOutput,bestIndIndexRow,feasibility,CV,minCV]=findBest(POP,objVal,consGVal,consHVal,toleranceG,toleranceH,CVType)
[NP,~]=size(POP);

if nargin<3 || isempty(consGVal)
    consGVal=zeros(NP,1);
end
if nargin<4 || isempty(consHVal)
    consHVal=zeros(NP,1);
end
if nargin<5 || isempty(toleranceG)
    toleranceG=0;
end
if nargin<6 || isempty(toleranceH)
    toleranceH=1e-5;
end
if nargin<7 || isempty(CVType)
    CVType=1;
end
CV=CVCal0(consGVal, consHVal, toleranceG,toleranceH,CVType);
feasible= CV==0;
% Record the best
if any(feasible)
    minObjValFeasible=min(objVal(feasible));
    minCV=0;
    bestIndIndex= objVal== minObjValFeasible;
    bestIndIndex(~feasible)=false;
    bestInd=POP(bestIndIndex,:);
    numBestIndIndex=sum(bestIndIndex);
    randBestIndex=randi(numBestIndIndex);
    bestIndOutput=bestInd(randBestIndex,:);% Best feasible individual
    bestObjCVOutput=minObjValFeasible;% Objective value of the best feasible individual
    feasibility=true;
else
    minCV=min(CV);
    bestIndIndex= CV== minCV;
    bestInd=POP(bestIndIndex,:);
    numBestIndIndex=sum(bestIndIndex);
    randBestIndex=randi(numBestIndIndex);
    bestIndOutput=bestInd(randBestIndex,:);% Best infeasible individual
    bestObjCVOutput=minCV;% Constraint violation value of the best infeasible individual
    feasibility=false;
end
bestIndIndexRowTemp=find(bestIndIndex);
bestIndIndexRow=bestIndIndexRowTemp(randBestIndex);
end