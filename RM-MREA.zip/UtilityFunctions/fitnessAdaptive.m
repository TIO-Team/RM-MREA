function [FitAdpat, sortfitAdapt,sortRowInd] = fitnessAdaptive(objVal, CV, epsilon, POPx,DATAx,LowerB,UpperB, FEs,MaxFEs,ExploreP)

% Three Types of Better solutions:
% #1 Unconstrained Better: Ranks based on objective values

% #2 Epsilon constraint violation relaxiation Better: Ranks based on relaxed
% contraint violation

% #3 Uncertainty Better: Ranks based on distance to the existed samples

% Adaptive fitness: weights adapted by: FEs/MaxFEs, Pfeasible

%% Three Types of Ranks
[~, IndexObjVal] = sort(objVal);
[~, RANK1]       = sort(IndexObjVal);

[~, ~,IndexFitEpsilon]  = fitnessEpsilon(objVal,CV,epsilon);
[~, RANK2]              = sort(IndexFitEpsilon);

[~, ~,IndexFitUncertain] = fitnessUncertain(POPx,DATAx,LowerB,UpperB);
[~, RANK3]               = sort(IndexFitUncertain);

%% Weighted
% if FEs/MaxFEs < ExploreP
% %     w1 = 0; %min(max(0.5 - FEs/MaxFEs,0),0.5);
% %     w2 = 0.5+0.5*FEs/MaxFEs;
% %     w3 = 1-w1-w2;
%     w1 = 0;
%     w2 = 0.1;
%     w3 = 0.9;
% %     w1 = 1-w2;
% 
% else
% %     w1 = 0;
% %     w2 = 0.5+0.5*FEs/MaxFEs;
% %     w3 = 0;
% %     w1 = 1-w2;
%     w1 = 0;
%     w2 = 0.9;
%     w3 = 0.1;
% end
w1 = 0;
w2 = min(0.5+ 0.5*(FEs/MaxFEs), 0.5) ;
w3 = 1-w2;
FitAdpat = w1*RANK1+w2*RANK2+w3*RANK3;
if nargout > 1
   [sortfitAdapt, sortRowInd] = sort(FitAdpat,'ascend');
end