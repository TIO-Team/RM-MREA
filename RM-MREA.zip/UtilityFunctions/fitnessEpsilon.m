function [fitEpsilon, sortFitEpsilon,sortRowInd] = fitnessEpsilon(objVal,CV,epsilon)

if nargin < 3 || isempty(epsilon)
    epsilon = inf;
end

NP              = length(objVal);
fitEpsilon      = inf(NP,1);
epsilonFeasible = CV <= epsilon;

if sum(epsilonFeasible) ~= 0
    fitEpsilon(epsilonFeasible)  = objVal(epsilonFeasible);
    objPenalty                   = max(objVal(epsilonFeasible));
    fitEpsilon(~epsilonFeasible) = CV(~epsilonFeasible) + objPenalty;
else
    fitEpsilon = CV;
end

if nargout > 1
   [sortFitEpsilon, sortRowInd] = sort(fitEpsilon,'ascend');
end