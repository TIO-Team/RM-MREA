function [fitUncertain, sortfitUncertain,sortRowInd] = fitnessUncertain(POPx,DATAx,LowerB,UpperB)

normalizedPOPx  = normalizeVar(POPx,LowerB,UpperB);
normalizedDATAx = normalizeVar(DATAx,LowerB,UpperB);
fitUncertain    = pdist2(normalizedDATAx,normalizedPOPx,'euclidean','Smallest',1);
fitUncertain    = -fitUncertain';
if nargout > 1
   [sortfitUncertain, sortRowInd] = sort(fitUncertain,'ascend');
end