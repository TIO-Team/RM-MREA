function [values ]=funcAll(functionHandles,x)

numFunc=length(functionHandles);
if numFunc==0
    values=zeros(size(x,1),1);
elseif numFunc==1 && ~isa(functionHandles,'cell')
    values=functionHandles(x);
else
    values=zeros(size(x,1),numFunc);
    parfor ii=1:numFunc
        values(:,ii)=functionHandles{ii}(x);
    end
end
end