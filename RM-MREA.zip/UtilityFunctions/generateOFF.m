function OFFx = generateOFF(Parents,NOFF,F,CR,TypeOffspring,TypeNOFF,XBestTopPBest)
if nargin <= 5 
    % Default: NOFF is the total number of offspring
    TypeNOFF = 1;
end
if nargin > 6 && ~isempty(XBestTopPBest)
    xBest       = XBestTopPBest{1};
    xTopPBest    = XBestTopPBest{2};
end

[NP,Dim]    = size(Parents);
NType       = length(TypeOffspring);
if TypeNOFF == 1
    NOFFii      = floor(NOFF/NType);
    NOFF        = NOFFii*NType;
else
    NOFFii      = NOFF;
    NOFF        = NOFFii*NType;
end
OFFx        = zeros(NOFF,Dim);
for ii = 1:NType
    Typeii = TypeOffspring(ii);
    switch Typeii
        case 1 % DE/rand/1/bin
            if NP < 3
                error('The number of parents shound not be smaller than 3');
            end
            IDRand      = zeros(NOFFii,3);
            for jj=1:NOFFii
                IDRand(jj,:)   = randsample(NP,3);
            end
            P0  = Parents(IDRand(:,end),:);
            P1  = Parents(IDRand(:,1),:);
            P2  = Parents(IDRand(:,2),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P2);
        case 2 % DE/rand/2/bin
            if NP < 5
                error('The number of parents shound not be smaller than 5');
            end
            IDRand      = zeros(NOFFii,5);
            for jj=1:NOFFii
                IDRand(jj,:)   = randsample(NP,5);
            end
            P0  = Parents(IDRand(:,end),:);
            P1  = Parents(IDRand(:,1),:);
            P2  = Parents(IDRand(:,2),:);
            P3  = Parents(IDRand(:,3),:);
            P4  = Parents(IDRand(:,4),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P2)+Fii.*(P3-P4);
        case 3 % DE/Current-to-rand/1
            NPii       = 2 : NP;
            R123       = zeros(NOFFii,3);
            for jj=1:NOFFii
                R123(jj,:) = randsample(NPii,3);
            end
            P0  = ones(NOFFii,1)*Parents(1,:);
            P1  = Parents(R123(:,1),:);
            P2  = Parents(R123(:,2),:);
            P3  = Parents(R123(:,3),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P0)+Fii.*(P2-P3);
        case 4 % DE/rand-to-rand/1
            IDRand=zeros(NOFFii,4);
            for jj = 1:NOFFii
                IDRand0             = randperm(NP);
                indexEqualii        = IDRand0(1:4)==jj;
                IDRand0(indexEqualii)   = IDRand0(5);
                IDRand(jj,:)            = IDRand0(1:4);
            end
            P0  = Parents(IDRand(:,end),:);
            P1  = Parents(IDRand(:,1),:);
            P2  = Parents(IDRand(:,2),:);
            P3  = Parents(IDRand(:,3),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P0)+Fii.*(P2-P3);
        case 5 % DE/rand-to-better/1
            IDRand=zeros(NOFFii,4);
            for jj = 1:NOFFii
                IDRand0             = randperm(NP);
                indexEqualii        = IDRand0(1:4)==jj;
                IDRand0(indexEqualii)   = IDRand0(5);
                IDRand(jj,:)            = IDRand0(1:4);
            end
            P0       = Parents(IDRand(:,end),:);
            r1Better = randi(NP-1, NOFFii, 1); % Better
            r2Worse  = r1Better + ceil((NP-r1Better).* rand(NOFFii,1)); % Worse
            P1       = Parents(r1Better,:);
            P2       = Parents(r2Worse,:);
            Fii      = randsample(F,NOFFii,true)';
            Fii      = Fii*ones(1,Dim);
            OFFxii   = P0+Fii.*(P1-P2);
        case 6 % DE/best/1/bin
            if NP < 2
                error('The number of parents shound not be smaller than 2');
            end
            IDRand      = zeros(NOFFii,2);
            for jj=1:NOFFii
                IDRand(jj,:)   = randsample(NP,2);
            end
            IDBest  = randsample(size(xBest,1),NOFFii,true);
            P0      = xBest(IDBest,:);
            P1      = Parents(IDRand(:,1),:);
            P2      = Parents(IDRand(:,2),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P2);
        case 7 % DE/best/2/bin
            if NP < 4
                error('The number of parents shound not be smaller than 4');
            end
            IDRand      = zeros(NOFFii,4);
            for jj=1:NOFFii
                IDRand(jj,:)   = randsample(NP,4);
            end
            IDBest  = randsample(size(xBest,1),NOFFii,true);
            P0      = xBest(IDBest,:);
            P1      = Parents(IDRand(:,1),:);
            P2      = Parents(IDRand(:,2),:);
            P3      = Parents(IDRand(:,3),:);
            P4      = Parents(IDRand(:,4),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P2)+Fii.*(P3-P4);
        case 8 % DE/Current-to-pbest/1
            if NP < 2
                error('The number of parents shound not be smaller than 4');
            end
            NTopBest    = size(xTopPBest,1);
            IDTopBest   = zeros(NOFFii,1);
            IDRand      = zeros(NOFFii,2);
            for jj=1:NOFFii
                IDTopBest(jj,:)     = randsample(NTopBest,1);
                IDRand(jj,:)        = randsample(NP,2);
            end
            P0  = ones(NOFFii,1)*Parents(1,:);
            P1  = xTopPBest(IDTopBest,:);
            P2  = Parents(IDRand(:,1),:);
            P3  = Parents(IDRand(:,2),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P0)+Fii.*(P2-P3);
        case 9 % DE/rand-to-pbest/1
            if NP < 3
                error('The number of parents shound not be smaller than 3');
            end
            NTopBest    = size(xTopPBest,1);
            IDTopBest   = zeros(NOFFii,1);
            IDRand      = zeros(NOFFii,3);
            for jj=1:NOFFii
                IDTopBest(jj,:)     = randsample(NTopBest,1);
                IDRand(jj,:)        = randsample(NP,3);
            end
            P0  = Parents(IDRand(:,1),:);
            P1  = xTopPBest(IDTopBest,:);
            P2  = Parents(IDRand(:,2),:);
            P3  = Parents(IDRand(:,3),:);
            Fii     = randsample(F,NOFFii,true)';
            Fii     = Fii*ones(1,Dim);
            OFFxii  = P0+Fii.*(P1-P0)+Fii.*(P2-P3);
        case 10
    end
    % Crossover
    if ismember(Typeii,[1,2,6,7])
        CRii    = randsample(CR,NOFFii,true)';
        CRii    = CRii*ones(1,Dim);
        SiteX   = rand(NOFFii,Dim) < CRii;
        jRow    = find(~any(SiteX,2));
        njRow   = length(jRow);
        if njRow>0
            temp            = reshape(randperm(njRow*Dim),njRow,Dim);
            SiteX(jRow,:)   = temp>=max(temp,[],2);
        end
        OFFxii(~SiteX)                          = P0(~SiteX);
    end
    % Save
    OFFx((ii-1)*NOFFii+1:ii*NOFFii,:)       = OFFxii;
end