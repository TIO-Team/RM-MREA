function [W1,W2] = generateWeights(evoArchiveType,AngleInterval,NP)
if nargin < 2
    AngleInterval = [0,pi/2];
end
if nargin < 3
    NP = 100;
end

switch evoArchiveType
    case 1
        % CV
        W1            = sin(linspace(AngleInterval(1),AngleInterval(2),NP))';
        % Obj
        W2            = sqrt(1-W1.^2); % 1-W1;
    case 2
        % CV
        W1            = linspace(AngleInterval(1),AngleInterval(2),NP)';
        % Obj
        W2            = 1-W1; % 1-W1;   
    case 3
end
W1 = max(W1,1e-6);
W2 = max(W2,1e-6);

