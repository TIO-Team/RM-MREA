function pop=initialize_pop(popSize,dim,lowerB,upperB,Plan)
% initialize the population using a specified sample plan
% Plan:        - 1 : latin hypercube sample

% latin hypercube sample is set as the default plan
if nargin==4 || isempty(Plan)
    Plan='lhs';
end
Xrange=upperB-lowerB;
% add a self-setting sampling plan
switch Plan
    case {'lhs',1}
        pop=ones(popSize,1)*lowerB+(ones(popSize,1)*Xrange).*lhsdesign(popSize,dim,'criterion','maximin','iterations',1000);
    case 'rand'
    case 'orthogonal'
end