function fgh_hat = normFGH(fgh,normBase,type)
if nargin < 3
    type = 1;
end

switch type
    case 1 % MaxMin normalize
        minV    = normBase{1};
        maxV    = normBase{2};
        idEqual = maxV == minV;
        maxV(idEqual)   = minV(idEqual) + 1;
        [np,~]          = size(fgh);
        minVm           = ones(np, 1) * minV;
        maxVm           = ones(np, 1) * maxV;
        fgh_hat         = (fgh - minVm)./ (maxVm - minVm);
    case 2 % distribution normalize
        muV     = normBase{1};
        sigmaV  = normBase{2};
        sigmaV(sigmaV == 0) = 1; % avoid zero denominator
        [np,~]  = size(fgh);
        muVm    = ones(np, 1) * muV;
        sigmaVm = ones(np, 1) * sigmaV;
        fgh_hat  = (fgh - muVm)./ sigmaVm;
end