function [NormY,Parameter] = normY(OY,type)
if nargin < 2 || isempty(type)
    type = 1;
end
[NP, ~] = size(OY);
switch type
    case 1 % (OY - mu) / sigma
        Sigma0               = std(OY,[],1);
        Sigma0(Sigma0 == 0)  =  1e-3;
        Sigma                = ones(NP,1)*Sigma0;
        Mu0                  = mean(OY,1);
        Mu                   = ones(NP,1)*Mu0;
        NormY                = (OY - Mu)./ Sigma;
    case 2 % (OY- min)/ (max -min)
        minY0                = min(OY,[],1);
        MaxY0                = max(OY,[],1);
        Range0               = MaxY0 - minY0;
        Range0(Range0 ==0)   = 1e-3;
        Range                = ones(NP,1)*Range0;
        minY                 = ones(NP,1)*minY0;
        NormY               = (OY - minY)./ Range;
    case 3 % OY / Sigma
        Sigma0               = std(OY,[],1);
        Sigma0(Sigma0 == 0)  =  1e-3;
        Sigma                = ones(NP,1)*Sigma0;
        NormY                = (OY)./ Sigma;


end
if nargout > 1
    switch type
        case 1
            Parameter.type     = 'SigmaMu';
            Parameter.SigRange = Sigma0;
            Parameter.MuMin    = Mu0;
        case 2
            Parameter.type     = 'MaxMin';
            Parameter.SigRange = Range0;
            Parameter.MuMin    = minY0;
        case 3
            Parameter.type     = 'Sigma';
            Parameter.SigRange = Sigma0;
            Parameter.MuMin    = [];

    end
end
