function NormY = normY2(OY,Parameter)


SigRange = Parameter.SigRange;
MuMin    = Parameter.MuMin;
[NP, ~]  = size(OY);
switch Parameter.type
    case {'SigmaMu'}
        Sigma0 = SigRange;
        Mu0    = MuMin;
        Sigma  = ones(NP,1)*Sigma0;
        Mu     = ones(NP,1)*Mu0;
        NormY  = (OY-Mu)./Sigma;
    case {'MaxMin'}
        Range0 = SigRange;
        minY0  = MuMin;
        Range  = ones(NP,1)*Range0;
        minY   = ones(NP,1)*minY0;
        NormY  = (OY - minY)./ Range;
    case {'Sigma'}
        Sigma0 = SigRange;
        Sigma  = ones(NP,1)*Sigma0;
        NormY  = (OY)./ Sigma;
end