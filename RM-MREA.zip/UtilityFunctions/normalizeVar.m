function normalizedDATA=normalizeVar(DATA,LB,UB)
if nargin<2 || isempty(LB)
    LB=min(DATA,[],1);
end
if nargin<3 || isempty(UB)
    UB=max(DATA,[],1);
end
if length(LB) ~= length(UB)
    error('Inconsistent Data dimension');
end
if any(LB>UB)
    error('Lower bounds shoud be less than Upper ones');
end
RANGE=UB-LB;
RANGE(RANGE==0)=1;
[NP,Dim]=size(DATA);
if Dim~=length(RANGE)
    error('Inconsistent Data dimension');
end

oneVector=ones(NP,1);
normalizedDATA=(DATA-oneVector*LB)./(oneVector*RANGE);