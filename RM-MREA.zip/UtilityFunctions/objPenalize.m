function objPenalty = objPenalize(objVal,CV,epsilon)

if nargin < 3 || isempty(epsilon)
    epsilon = inf;
end

epsilonFeasible = CV <= epsilon;

if sum(epsilonFeasible) ~= 0
    objPenalty                   = max(objVal(epsilonFeasible));
else
    objPenalty = 0;
end