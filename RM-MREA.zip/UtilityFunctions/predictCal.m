function [y_hat,objVal_hat, consGVal_hat,consHVal_hat,consGHVal_hat,CV_hat] = predictCal(X,Model,num_g,num_h,toleranceG,toleranceH,CVType)

y_hat                   = RBFInterp(X, Model);
objVal_hat              = y_hat(:,1);
consGVal_hat            = y_hat(:,2:1+num_g);
consHVal_hat            = y_hat(:,1+num_g+1:end);
[consGVal_hat,consHVal_hat]     =  corrConVal(consGVal_hat,consHVal_hat,num_g,num_h);
consGHVal_hat                   =  [consGVal_hat,consHVal_hat];
CV_hat                          =  CVCal0(consGVal_hat, consHVal_hat, toleranceG,toleranceH,CVType);
