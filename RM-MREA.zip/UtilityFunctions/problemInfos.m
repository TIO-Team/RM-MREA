function ProblemInfos = problemInfos(fnum,Dim,suite)
numProblem              = length(fnum);
ProblemInfos.suite      = suite;
ProblemInfos.numProblem = numProblem;
ProblemInfos.fnum       = zeros(numProblem,1);
ProblemInfos.Dim        = zeros(numProblem,1);
ProblemInfos.num_g      = zeros(numProblem,1);
ProblemInfos.num_h      = zeros(numProblem,1);
ProblemInfos.lowerB     = cell(numProblem,1);
ProblemInfos.upperB     = cell(numProblem,1);
ProblemInfos.x_best     = cell(numProblem,1);
ProblemInfos.f_best     = cell(numProblem,1);
ProblemInfos.problem    = cell(numProblem,1);

for ii = 1 : numProblem
    fnum(ii)
    ProblemInfos.fnum(ii) = fnum(ii);
    [ProblemInfos.Dim(ii),ProblemInfos.num_g(ii),ProblemInfos.num_h(ii),...
        ProblemInfos.upperB{ii},ProblemInfos.lowerB{ii},ProblemInfos.x_best{ii},...
        ProblemInfos.f_best{ii},ProblemInfos.problem{ii}] = get_ProblemInfo(fnum(ii),Dim,suite);
end