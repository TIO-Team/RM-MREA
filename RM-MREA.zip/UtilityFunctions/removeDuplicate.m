function [DATAxKeep,RowKeep] = removeDuplicate(DATAx,LowerB,UpperB,fitness)

normalizedDATAx     = normalizeVar(DATAx,LowerB,UpperB);
normalizedDist      = pdist2(normalizedDATAx,normalizedDATAx,'euclidean');
NP                  = size(DATAx,1);
normalizedDist      = normalizedDist + diag(inf(NP,1));
RowKeep             = true(NP,1);
thresholdDist       = 1e-4;

Remove              = normalizedDist < thresholdDist;
RowRemove           = any(Remove,2);

% Keep as more points as possible
while any(RowRemove)
    if nargin < 4
        numNear             = sum(Remove,2);
        [~,indexDel]        = max(numNear);
        RowKeep(indexDel)   = false;
        Remove(:,indexDel)  = false;
        Remove(indexDel,:)  = false;
        RowRemove           = any(Remove,2);
    else
        % ==== TO DO
        tempKeep = fitness == min(fitness(RowRemove));
        RowKeep(Remove(tempKeep,:)) = false;
        Remove(tempKeep,:)          = false;
        Remove(:,tempKeep)          = false;
    end
end

DATAxKeep = DATAx(RowKeep,:);
end