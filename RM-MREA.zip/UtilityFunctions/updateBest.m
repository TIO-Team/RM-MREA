function [bestIndNew, bestObjCVNew,feasibility]=updateBest(bestIndOld,bestObjCVOld,feasibilityOld,POPNew,objValNew,CVNew)

feasible= CVNew==0;
if feasibilityOld % Best to date is feasible
    feasibility=true;
    if any(feasible)
        minObjValFeasible=min(objValNew(feasible));
        if minObjValFeasible<bestObjCVOld
            bestIndIndex= objValNew== minObjValFeasible;
            bestIndIndex(~feasible)=false;
            bestInd=POPNew(bestIndIndex,:);
            numBestIndIndex=sum(bestIndIndex);
            randBestIndex=randi(numBestIndIndex);
            bestIndNew=bestInd(randBestIndex,:);% Best feasible individual
            bestObjCVNew=minObjValFeasible;% Objective value of the best feasible individual
        else
            bestIndNew=bestIndOld;
            bestObjCVNew=bestObjCVOld;
        end
    else
        bestIndNew=bestIndOld;
        bestObjCVNew=bestObjCVOld;
    end
else % Best to date is infeasible
    if any(feasible)
        feasibility=true;
        minObjValFeasible=min(objValNew(feasible));
        bestIndIndex= objValNew== minObjValFeasible;
        bestIndIndex(~feasible)=false;
        bestInd=POPNew(bestIndIndex,:);
        numBestIndIndex=sum(bestIndIndex);
        randBestIndex=randi(numBestIndIndex);
        bestIndNew=bestInd(randBestIndex,:);% Best feasible individual
        bestObjCVNew=minObjValFeasible;% Objective value of the best feasible individual
    else
        feasibility=false;
        minCVNew=min(CVNew);
        if minCVNew < bestObjCVOld
            bestIndIndex= CVNew== minCVNew;
            bestInd=POPNew(bestIndIndex,:);
            numBestIndIndex=sum(bestIndIndex);
            randBestIndex=randi(numBestIndIndex);
            bestIndNew=bestInd(randBestIndex,:);% Best infeasible individual
            bestObjCVNew=minCVNew;% Constraint violation value of the best infeasible individual
        else
            bestIndNew=bestIndOld;
            bestObjCVNew=bestObjCVOld;
        end
    end
end
end