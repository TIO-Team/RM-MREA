% Find the contour
clear;close;clc;
addpath(genpath('.'));
suite           = @ExampleProblem; % ExampleProblem CEC2006
fnum            = 1; %fnum = [3 5 11 13 14 15 17 21 23  ]
Dim             = 0;
isShowInfill    = true;

[Dim,num_g,num_h,upperB,lowerB,x_best,f_best,problem]   =  get_ProblemInfo(fnum,Dim,suite);

CVType          = 2;
toleranceG      = 1e-50;
toleranceH      = 1e-4;
num_initSample  = max(5*Dim,0); % ===========================================================
maxFEs          = max(50*Dim,0);% ===========================================================

FEs             = num_initSample;
NP              = num_initSample;
init_samplePlan = 'lhs';
kernel          = 'cubic';
Knearest        = max(5*Dim,0);% ===========================================================
minLocalRange   = 2e-8;
maxFEsLocal     = 300;
algorithmLocalSeach = 'SQP'; % 'interior-point'
PrescreenLambda = min(50*Dim,1000); % ======================================================
% ProblemInfos = problemInfos(fnum,Dim,suite)
warning off;
%% Initialize
DATA.x                      = inf(maxFEs,Dim);
DATA.y                      = inf(maxFEs,num_g+num_h+1);

POPx                        =   initialize_pop(num_initSample,Dim,lowerB,upperB,init_samplePlan);
[objVal,consGVal,consHVal]  =   problem(POPx,fnum);
[consGVal,consHVal]         =   corrConVal(consGVal,consHVal,num_g,num_h);
POPy                        =   [objVal,consGVal,consHVal];
convergeDATA.bestSitesLog   =   inf(maxFEs-num_initSample+1,Dim);
convergeDATA.bestValLog     =   inf(maxFEs-num_initSample+1,2);
DATA.x(1:num_initSample,:)  =   POPx;
DATA.y(1:num_initSample,:)  =   POPy;

[bestIndCurrent, bestObjCVCurrent,bestIndRowCurrent,feasibilityCurrent,CV,minCVCurrent] = findBest(POPx,objVal,consGVal,consHVal,toleranceG,toleranceH,CVType);
bestPointer                    = 1;
convergeDATA.bestSitesLog(1,:) = bestIndCurrent;
convergeDATA.bestValLog(1,:)   = [bestObjCVCurrent,feasibilityCurrent];
%%---------------
MaxRatioExploreFEs  = 0.0;
epsilon0            = max(CV);
epsilon             = epsilon0;
% [fitEpsilon, sortFitEpsilon,RankFit]        = fitnessEpsilon(objVal,CV,epsilon);
% [fit, sortFit,sortRowFit]                             = fitnessEpsilon(objVal,CV,0);
strategyOff         = 2;
strategyPrescreen   = 1;
strategyEnvironment = 1;
strategyLocal       = 1;
%% Optimize
[f1,pp{1}]=showExample(fnum,Dim,suite);
hold on;
plot(DATA.x(1:FEs,1), DATA.x(1:FEs,2),'ro')
gMax = 500;
%% Shade
NP_Shade = 100;
H        = NP_Shade;
pRange   = [2/NP_Shade, 0.2];
while FEs < maxFEs
    
    [DATAxTrain,RowTrain] = removeDuplicate(DATA.x(1:FEs,:),lowerB,upperB);
    DATAyTrain            = DATA.y(RowTrain,:);
    model                 = RBFCreate(DATAxTrain, DATAyTrain, kernel);
    %normBase{1}           = zeros(1,size(DATA.y(1:FEs,:),2));    %min(abs(DATA.y(1:FEs,:))); % zeros()
    %normBase{2}           = max(abs(DATA.y(1:FEs,:)));
    
    %% SHADE
    POPTemp  =  initialize_pop(NP_Shade,Dim,lowerB,upperB,init_samplePlan);
    FGHTemp  =  RBFInterp(POPTemp, model);
    %FGHTemp_norm = normFGH(abs(FGHTemp),normBase,1);
    % boundary
    fitnessCurrent     = fitness(FGHTemp);
    % distance
    MF       = 0.5 .* ones(H, 1);
    MCR      = 0.5 .* ones(H, 1);
    k_H      = 1;
    Archive  = [];
    for g =1: gmax
        % Generate F, CR
        H_select = randi([1,H],1,NP_Shade);
        F_Shade  = MF(H_select);
        CR_Shade = MCR(H_select);

        F_Shade  = F_Shade + 0.1 * tan(pi * (rand(NP_Shade,1) - 0.5)); % Cauchy distribution: 0.1
        while any(F_Shade <= 0)
            id_lessThan0 = F_Shade <= 0;
            F_Shade(id_lessThan0) = MF(H_select(id_lessThan0))  + 0.1 * tan(pi * (rand(sum(id_lessThan0),1) - 0.5)); % Cauchy distribution
        end
        F_Shade(F_Shade > 1) = 1;

        CR_Shade =  normrnd(CR_Shade, 0.1); % normal distribution: 0.1
        CR_Shade(CR_Shade>1) = 1;
        CR_Shade(CR_Shade<0) = 0;

        % Generate offspring
        % current-to-pbest
        % pbest
        pbest           = floor((pRange(1) + rand(NP_Shade,1)*(pRange(2)-pRange(1)))*NP_Shade);
        pbest(pbest<1)  = 1;

        currentID       = (1:NP_Shade)';
        idEqual         = currentID == pbest;
        while any(idEqual)
            pbest(idEqual) = floor((pRange(1) + rand(sum(idEqual),1)*(pRange(2)-pRange(1)))*NP_Shade);
            idEqual        = currentID == pbest;
        end
        % r1
        r1      = randi(NP_Shade,NP_Shade,1);
        idEqual = pbest == r1;
        while any(idEqual)
            r1(idEqual) =  randi(NP_Shade,sum(idEqual),1);
            idEqual     = pbest == r1;
        end
        % r2
        randomPool      = [POPTemp; Archive];
        NPPool          = length(randomPool(:,1));
        r2      = randi(NPPool,NP_Shade,1);
        idEqual = (r2 == r1) | (r2 == pbest);
        while any(idEqual)
            r2(idEqual) =  randi(NPPool,sum(idEqual),1);
            idEqual     = (r2 == r1) | (r2 == pbest);
        end

        offspring       = POPTemp + F_Shade.*(POPTemp(pbest,:)-POPTemp) + F_Shade.*(POPTemp(r1,:)-randomPool(r2,:));
        % crossover
        SiteX= rand(NP_Shade,Dim)< CR;
        jRow=find(~any(SiteX,2));
        njRow=length(jRow);
        if njRow>0
            temp=reshape(randperm(njRow*Dim),njRow,Dim);
            SiteX(jRow,:)= temp>=max(temp,[],2);
        end
        offspring(~SiteX) = POPTemp(~SiteX);

        FGHTempOff      = RBFInterp(offspring, model);
        fitnessOff      = fitness(FGHTempOff);
        
        % Update Archive
        replace         = fitnessOff < fitnessCurrent;
        Archive         = [Archive; POPTemp(replace,:)];
        NP_Archive      = length(Archive(:,1));
        if NP_Archive > NP_Shade
            idSave      = randperm(NP_Archive,NP_Shade);
            Archive     = Archive(idSave,:);
        end

        % Update MF and MCR
        SF  = F_Shade(replace);
        SCR = CR_Shade(replace);
        Improvement = fitnessCurrent(replace) - fitnessOff(replace);
        weights     = Improvement./sum(Improvement);
        if ~isempty(SF)
            MF(k_H)     = sum(weights .* (SF.^2)) / sum(weights .* SF);
            MCR(k_H)    = sum(weights .* SCR);
        else
            MF(k_H)     = MF(mod(k_H + H - 2, H)+1);
            MCR(k_H)    = MCR(mod(k_H + H - 2, H)+1);
        end
        k_H = mod(k_H, H) + 1;
        % Environment selection
        POPTemp(replace,:) = offspring(replace,:);
        fitnessCurrent     = fitnessOff(replace,:);
    end
end